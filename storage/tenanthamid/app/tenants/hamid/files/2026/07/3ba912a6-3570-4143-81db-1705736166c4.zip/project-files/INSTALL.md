# AI Support SaaS Platform — Complete Installation Guide

## System Requirements

| Component  | Version      |
|------------|--------------|
| PHP        | 8.3+         |
| MySQL      | 8.0+         |
| Redis      | 7.0+         |
| Node.js    | 20+          |
| Composer   | 2.6+         |
| Git        | 2.x          |

---

## Step 1 — Clone & Enter Project

```bash
git clone https://github.com/your-org/ai-support-saas.git
cd ai-support-saas
```

---

## Step 2 — Install PHP Dependencies

```bash
composer install --no-dev --optimize-autoloader
```

> For development:
```bash
composer install
```

---

## Step 3 — Install Node.js Dependencies

```bash
npm install
```

---

## Step 4 — Environment Configuration

```bash
cp .env.example .env
php artisan key:generate
```

Now edit `.env` with your values:

```bash
nano .env
```

### Required `.env` values:

```env
APP_NAME="AI Support Platform"
APP_URL=http://localhost

# Central database
DB_DATABASE=ai_support_central
DB_USERNAME=root
DB_PASSWORD=your_password

# Redis
REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

# Session & Cache on Redis
SESSION_DRIVER=redis
CACHE_STORE=redis
QUEUE_CONNECTION=redis
BROADCAST_CONNECTION=reverb

# Central domain(s)
CENTRAL_DOMAIN=yourdomain.com
CENTRAL_DOMAINS=yourdomain.com

# Reverb WebSocket
REVERB_APP_ID=ai-support
REVERB_APP_KEY=your-reverb-key-here
REVERB_APP_SECRET=your-reverb-secret-here
REVERB_HOST=localhost
REVERB_PORT=8080
REVERB_SCHEME=http

VITE_REVERB_APP_KEY="${REVERB_APP_KEY}"
VITE_REVERB_HOST="${REVERB_HOST}"
VITE_REVERB_PORT="${REVERB_PORT}"
VITE_REVERB_SCHEME="${REVERB_SCHEME}"

# AI - Set at least one
AI_DEFAULT_PROVIDER=gemini
GEMINI_API_KEY=your_gemini_api_key

# Stripe
STRIPE_KEY=pk_test_xxx
STRIPE_SECRET=sk_test_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx

# Mail
MAIL_MAILER=smtp
MAIL_HOST=smtp.mailtrap.io
MAIL_PORT=587
MAIL_USERNAME=your_username
MAIL_PASSWORD=your_password
MAIL_FROM_ADDRESS=support@yourdomain.com
```

---

## Step 5 — Database Setup

### Create central database:
```bash
mysql -u root -p -e "CREATE DATABASE ai_support_central CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
```

### Run central migrations:
```bash
php artisan migrate --path=database/migrations/central
```

### Seed central database:
```bash
php artisan db:seed --class=SuperAdminSeeder
```

---

## Step 6 — Storage & Permissions

```bash
php artisan storage:link
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

---

## Step 7 — Build Frontend Assets

```bash
# Development
npm run dev

# Production
npm run build
```

---

## Step 8 — Create First Tenant

```bash
php artisan tinker
```

Inside tinker:
```php
use App\Models\Tenant;
use Illuminate\Support\Str;

$tenant = Tenant::create([
    'id'    => Str::uuid()->toString(),
    'name'  => 'My Company',
    'slug'  => 'mycompany',
    'email' => 'admin@mycompany.com',
    'plan'  => 'professional',
]);

$tenant->domains()->create(['domain' => 'mycompany.yourdomain.com']);

// Run tenant migrations + seed
tenancy()->initialize($tenant);
Artisan::call('migrate', ['--path' => 'database/migrations/tenant', '--force' => true]);
Artisan::call('db:seed', ['--class' => 'TenantDatabaseSeeder', '--force' => true]);
tenancy()->end();

echo "Tenant created! Login at: mycompany.yourdomain.com\n";
echo "Email: owner@example.com | Password: password\n";
```

---

## Step 9 — Configure Laravel Reverb

```bash
php artisan reverb:install
```

Start Reverb (development):
```bash
php artisan reverb:start --debug
```

---

## Step 10 — Configure Laravel Horizon

```bash
php artisan horizon:install
php artisan horizon:publish
```

Start Horizon (development):
```bash
php artisan horizon
```

---

## Step 11 — Queue Workers (Development)

```bash
# Default + notifications queue
php artisan queue:work redis --queue=default,notifications,mail

# AI queue (separate terminal)
php artisan queue:work redis --queue=ai --timeout=90
```

---

## Step 12 — Task Scheduler

Add to crontab:
```bash
crontab -e
```

Add this line:
```
* * * * * cd /path/to/ai-support && php artisan schedule:run >> /dev/null 2>&1
```

---

## Step 13 — Stripe Webhook (Development)

Install Stripe CLI and forward webhooks:
```bash
stripe listen --forward-to localhost/stripe/webhook
```

Copy the webhook secret to `.env`:
```env
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxx
```

---

## Step 14 — Verify Installation

```bash
# Check application
php artisan about

# Check queue connection
php artisan queue:monitor redis:default,redis:ai

# Clear all caches
php artisan optimize:clear

# Test email
php artisan tinker
Mail::raw('Test', fn($m) => $m->to('test@example.com')->subject('Test'));
```

---

## Step 15 — First Login

Visit `http://mycompany.yourdomain.com` and login with:
- **Email:** `owner@example.com`
- **Password:** `password`

> Change password immediately after first login!

---

## Stripe Plans Setup

In your Stripe dashboard, create these products and prices, then add to `.env`:

| Plan         | Monthly Price | Yearly Price |
|--------------|---------------|--------------|
| Free         | $0            | $0           |
| Starter      | $29           | $290         |
| Professional | $99           | $990         |
| Enterprise   | $299          | $2990        |

```env
STRIPE_PLAN_FREE=price_xxxx
STRIPE_PLAN_STARTER=price_xxxx
STRIPE_PLAN_PROFESSIONAL=price_xxxx
STRIPE_PLAN_ENTERPRISE=price_xxxx
```

---

## AI Provider Configuration

### Google Gemini (Recommended — Free tier available)
1. Go to https://aistudio.google.com/apikey
2. Create API key
3. Add to `.env`: `GEMINI_API_KEY=your_key`

### OpenAI
1. Go to https://platform.openai.com/api-keys
2. Create API key
3. Add to `.env`: `OPENAI_API_KEY=your_key`

### Anthropic Claude
1. Go to https://console.anthropic.com
2. Create API key
3. Add to `.env`: `CLAUDE_API_KEY=your_key`

### Ollama (Local, Free)
```bash
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull llama3
ollama serve  # Runs on http://localhost:11434
```
Add to `.env`: `OLLAMA_HOST=http://localhost:11434`

---

## Troubleshooting

### Permission errors:
```bash
sudo chown -R $USER:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
```

### Cache issues:
```bash
php artisan optimize:clear
php artisan config:clear
php artisan view:clear
php artisan route:clear
```

### Queue not processing:
```bash
php artisan queue:restart
php artisan horizon:terminate
```

### Tenant DB connection error:
```bash
php artisan tenants:migrate
```

### 404 on tenant subdomain:
- Check DNS: `*.yourdomain.com` → server IP
- Check Nginx `server_name *.yourdomain.com`
- Check `.env` `CENTRAL_DOMAINS=yourdomain.com`
