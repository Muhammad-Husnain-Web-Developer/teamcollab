<template>
  <form @submit.prevent="submit" class="space-y-4">
    <div>
      <label class="label">Subject *</label>
      <input v-model="form.subject" class="input" placeholder="Brief issue description" required />
    </div>
    <div>
      <label class="label">Customer *</label>
      <input v-model="cs" @input="searchC" class="input" placeholder="Search by email or name..." />
      <div v-if="cr.length" class="mt-1 border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden shadow-md">
        <button type="button" v-for="c in cr" :key="c.id" @click="pick(c)"
                class="w-full flex items-center gap-3 px-3 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-gray-800 text-left">
          <span class="font-medium text-gray-900 dark:text-white">{{ c.name }}</span>
          <span class="text-gray-500 text-xs">{{ c.email }}</span>
        </button>
      </div>
      <p v-if="form.customer_id" class="text-xs text-emerald-600 dark:text-emerald-400 mt-1">✓ Customer selected</p>
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="label">Priority</label>
        <select v-model="form.priority" class="input">
          <option v-for="p in ['low','normal','high','urgent','critical']" :key="p" :value="p">{{ capitalize(p) }}</option>
        </select>
      </div>
      <div>
        <label class="label">Category</label>
        <select v-model="form.category_id" class="input">
          <option value="">No category</option>
          <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
        </select>
      </div>
    </div>
    <div>
      <label class="label">Assign To</label>
      <select v-model="form.assigned_to" class="input">
        <option value="">Unassigned</option>
        <option v-for="a in agents" :key="a.id" :value="a.id">{{ a.name }}</option>
      </select>
    </div>
    <div>
      <label class="label">Description *</label>
      <textarea v-model="form.description" rows="4" class="input resize-none" placeholder="Detailed description of the issue..." required />
    </div>
    <div class="flex justify-end gap-2">
      <button type="submit" :disabled="sub || !form.customer_id" class="btn-primary btn-sm">
        Create Ticket
      </button>
    </div>
  </form>
</template>
<script setup lang="ts">
import { ref, reactive } from 'vue';
import axios from 'axios';
import { useDebounceFn } from '@vueuse/core';
const props = defineProps<{ categories: any[]; agents: any[] }>();
const emit = defineEmits<{ created: [] }>();
const sub = ref(false); const cs = ref(''); const cr = ref<any[]>([]);
const form = reactive({ subject:'', description:'', customer_id:'', category_id:'', priority:'normal', assigned_to:'' });
const searchC = useDebounceFn(async () => {
  if (cs.value.length < 2) { cr.value = []; return; }
  const { data } = await axios.get('/api/customers/search', { params: { q: cs.value } });
  cr.value = data.customers ?? [];
}, 300);
function pick(c: any) { form.customer_id = c.id; cs.value = `${c.name} (${c.email})`; cr.value = []; }
function capitalize(s: string) { return s.charAt(0).toUpperCase() + s.slice(1); }
async function submit() {
  sub.value = true;
  try { await axios.post(route('tenant.tickets.store'), form); emit('created'); }
  finally { sub.value = false; }
}
</script>
