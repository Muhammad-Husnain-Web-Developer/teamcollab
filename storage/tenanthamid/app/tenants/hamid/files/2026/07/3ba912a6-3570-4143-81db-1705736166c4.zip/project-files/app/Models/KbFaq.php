<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class KbFaq extends Model {
    protected $table = 'kb_faqs';
    protected $fillable = ['category_id','question','answer','tags','is_public','is_active','order','views'];
    protected $casts = ['tags'=>'array','is_public'=>'boolean','is_active'=>'boolean'];
    public function category(): BelongsTo { return $this->belongsTo(KbCategory::class,'category_id'); }
    public function incrementViews(): void { $this->increment('views'); }
}
