<?php

namespace App\Services\AI;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class OpenAIProvider implements AIProviderInterface
{
    private string $apiKey;
    private string $model;
    private ?string $organization;
    private int $maxTokens;
    private float $temperature;

    public function __construct(array $config)
    {
        $this->apiKey = $config['api_key'] ?? '';
        $this->model = $config['model'] ?? 'gpt-4o';
        $this->organization = $config['organization'] ?? null;
        $this->maxTokens = $config['max_tokens'] ?? 2048;
        $this->temperature = $config['temperature'] ?? 0.7;
    }

    public function generateResponse(array $messages, ?string $systemPrompt = null, array $options = []): AIResponse
    {
        $formattedMessages = [];
        if ($systemPrompt) {
            $formattedMessages[] = ['role' => 'system', 'content' => $systemPrompt];
        }
        foreach ($messages as $message) {
            $formattedMessages[] = [
                'role' => $message['role'],
                'content' => $message['content'],
            ];
        }

        $headers = [
            'Authorization' => "Bearer {$this->apiKey}",
            'Content-Type' => 'application/json',
        ];
        if ($this->organization) {
            $headers['OpenAI-Organization'] = $this->organization;
        }

        try {
            $response = Http::withHeaders($headers)
                ->timeout(30)
                ->post('https://api.openai.com/v1/chat/completions', [
                    'model' => $options['model'] ?? $this->model,
                    'messages' => $formattedMessages,
                    'max_tokens' => $options['max_tokens'] ?? $this->maxTokens,
                    'temperature' => $options['temperature'] ?? $this->temperature,
                ]);

            if ($response->failed()) {
                Log::error('OpenAI API error', ['status' => $response->status(), 'body' => $response->body()]);
                throw new \RuntimeException("OpenAI API error: " . $response->body());
            }

            $data = $response->json();
            $content = $data['choices'][0]['message']['content'] ?? '';
            $usage = $data['usage'] ?? [];

            $shouldEscalate = str_contains($content, '[ESCALATE]');

            return new AIResponse(
                content: $content,
                provider: 'openai',
                model: $this->model,
                promptTokens: $usage['prompt_tokens'] ?? 0,
                completionTokens: $usage['completion_tokens'] ?? 0,
                confidenceScore: $shouldEscalate ? 0.3 : 0.9,
                shouldEscalate: $shouldEscalate,
                meta: ['finish_reason' => $data['choices'][0]['finish_reason'] ?? ''],
            );
        } catch (\Exception $e) {
            Log::error('OpenAI provider error', ['error' => $e->getMessage()]);
            throw $e;
        }
    }

    public function complete(string $prompt, array $options = []): AIResponse
    {
        return $this->generateResponse([
            ['role' => 'user', 'content' => $prompt],
        ], null, $options);
    }

    public function isAvailable(): bool
    {
        return ! empty($this->apiKey);
    }

    public function getName(): string
    {
        return 'openai';
    }

    public function getModel(): string
    {
        return $this->model;
    }
}
