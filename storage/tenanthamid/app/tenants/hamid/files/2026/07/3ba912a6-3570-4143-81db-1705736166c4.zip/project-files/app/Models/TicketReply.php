<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
class TicketReply extends Model {
    use SoftDeletes;
    protected $fillable = ['ticket_id','user_id','customer_id','content','is_internal','attachments'];
    protected $casts = ['is_internal'=>'boolean','attachments'=>'array'];
    public function ticket(): BelongsTo { return $this->belongsTo(Ticket::class); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
}
