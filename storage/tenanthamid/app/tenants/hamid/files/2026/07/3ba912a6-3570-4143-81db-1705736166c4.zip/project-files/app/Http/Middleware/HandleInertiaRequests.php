<?php

namespace App\Http\Middleware;

use App\Models\Conversation;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Inertia\Middleware;
use Tighten\Ziggy\Ziggy;

class HandleInertiaRequests extends Middleware
{
    protected $rootView = 'app';

    public function version(Request $request): string|null
    {
        return parent::version($request);
    }

    public function share(Request $request): array
    {
        $user = $request->user();

        $shared = [
            ...parent::share($request),
            'auth' => [
                'user' => $user ? [
                    'id'         => $user->id,
                    'name'       => $user->name,
                    'email'      => $user->email,
                    'avatar_url' => $user->avatar_url,
                    'status'     => $user->status,
                    'roles'      => $user->getRoleNames(),
                    'permissions'=> $user->getAllPermissions()->pluck('name'),
                ] : null,
            ],
            'ziggy' => fn () => [
                ...(new Ziggy)->toArray(),
                'location' => $request->url(),
            ],
            'flash' => [
                'success' => fn () => $request->session()->get('success'),
                'error'   => fn () => $request->session()->get('error'),
            ],
        ];

        // Tenant-specific shared data
        if (tenancy()->initialized && $user) {
            $shared['open_conversations'] = fn () => Conversation::where('status', 'open')->count();
            $shared['open_tickets']       = fn () => Ticket::where('status', 'open')->count();
            $shared['tenant']             = fn () => [
                'id'              => tenant('id'),
                'name'            => tenant('name'),
                'logo'            => tenant('logo'),
                'primary_color'   => tenant('primary_color', '#6366f1'),
                'secondary_color' => tenant('secondary_color', '#8b5cf6'),
                'plan'            => tenant('plan'),
            ];
        }

        return $shared;
    }
}
