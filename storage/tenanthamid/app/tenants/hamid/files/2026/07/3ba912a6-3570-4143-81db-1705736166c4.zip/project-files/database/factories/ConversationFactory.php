<?php

namespace Database\Factories;

use App\Models\Conversation;
use App\Models\Customer;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class ConversationFactory extends Factory
{
    protected $model = Conversation::class;

    public function definition(): array
    {
        return [
            'uuid'             => Str::uuid()->toString(),
            'customer_id'      => Customer::factory(),
            'status'           => fake()->randomElement(['open', 'open', 'resolved', 'waiting']),
            'type'             => fake()->randomElement(['ai', 'ai', 'human']),
            'channel'          => fake()->randomElement(['web', 'widget', 'api']),
            'priority'         => fake()->randomElement(['low', 'normal', 'normal', 'high']),
            'message_count'    => fake()->numberBetween(1, 20),
            'is_read'          => fake()->boolean(70),
            'last_activity_at' => fake()->dateTimeBetween('-7 days', 'now'),
        ];
    }

    public function open(): static
    {
        return $this->state(fn () => ['status' => 'open']);
    }

    public function aiHandled(): static
    {
        return $this->state(fn () => ['type' => 'ai']);
    }
}
