<?php

use App\Http\Controllers\Tenant\ConversationController;
use App\Http\Controllers\Tenant\CustomerController;
use App\Http\Controllers\Tenant\DashboardController;
use App\Http\Controllers\Tenant\KnowledgeBaseController;
use App\Http\Controllers\Tenant\SettingsController;
use App\Http\Controllers\Tenant\SubscriptionController;
use App\Http\Controllers\Tenant\TeamController;
use App\Http\Controllers\Tenant\TicketController;
use App\Http\Controllers\Api\WidgetController;
use Illuminate\Support\Facades\Route;

// ─── Tenant-scoped web routes ────────────────────────────────────────────────
Route::middleware(['web', 'auth', 'verified'])->name('tenant.')->group(function () {

    // Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/analytics', [DashboardController::class, 'analytics'])->name('analytics');

    // Conversations / Live Chat
    Route::prefix('conversations')->name('conversations.')->group(function () {
        Route::get('/', [ConversationController::class, 'index'])->name('index');
        Route::get('/{conversation}', [ConversationController::class, 'show'])->name('show');
        Route::post('/{conversation}/messages', [ConversationController::class, 'sendMessage'])->name('messages.send');
        Route::post('/{conversation}/assign', [ConversationController::class, 'assign'])->name('assign');
        Route::post('/{conversation}/transfer', [ConversationController::class, 'transfer'])->name('transfer');
        Route::post('/{conversation}/resolve', [ConversationController::class, 'resolve'])->name('resolve');
        Route::post('/{conversation}/escalate', [ConversationController::class, 'escalate'])->name('escalate');
        Route::post('/{conversation}/typing', [ConversationController::class, 'typing'])->name('typing');
        Route::post('/{conversation}/messages/{message}/reactions', [ConversationController::class, 'addReaction'])->name('reactions');
        Route::get('/{conversation}/suggestions', [ConversationController::class, 'suggestions'])->name('suggestions');
        Route::get('/{conversation}/summarize', [ConversationController::class, 'summarize'])->name('summarize');
    });

    // Tickets
    Route::prefix('tickets')->name('tickets.')->group(function () {
        Route::get('/', [TicketController::class, 'index'])->name('index');
        Route::post('/', [TicketController::class, 'store'])->name('store');
        Route::get('/{ticket}', [TicketController::class, 'show'])->name('show');
        Route::put('/{ticket}', [TicketController::class, 'update'])->name('update');
        Route::delete('/{ticket}', [TicketController::class, 'destroy'])->name('destroy');
        Route::post('/{ticket}/replies', [TicketController::class, 'reply'])->name('reply');
        Route::post('/{ticket}/escalate', [TicketController::class, 'escalate'])->name('escalate');
    });

    // Customers
    Route::prefix('customers')->name('customers.')->group(function () {
        Route::get('/', [CustomerController::class, 'index'])->name('index');
        Route::post('/', [CustomerController::class, 'store'])->name('store');
        Route::get('/{customer}', [CustomerController::class, 'show'])->name('show');
        Route::put('/{customer}', [CustomerController::class, 'update'])->name('update');
        Route::delete('/{customer}', [CustomerController::class, 'destroy'])->name('destroy');
        Route::post('/{customer}/notes', [CustomerController::class, 'addNote'])->name('notes.store');
        Route::delete('/{customer}/notes/{note}', [CustomerController::class, 'deleteNote'])->name('notes.destroy');
    });

    // Knowledge Base
    Route::prefix('kb')->name('kb.')->group(function () {
        Route::get('/', [KnowledgeBaseController::class, 'index'])->name('index');
        Route::get('/articles/create', [KnowledgeBaseController::class, 'create'])->name('articles.create');
        Route::post('/articles', [KnowledgeBaseController::class, 'store'])->name('articles.store');
        Route::get('/articles/{article}', [KnowledgeBaseController::class, 'show'])->name('articles.show');
        Route::get('/articles/{article}/edit', [KnowledgeBaseController::class, 'edit'])->name('articles.edit');
        Route::put('/articles/{article}', [KnowledgeBaseController::class, 'update'])->name('articles.update');
        Route::delete('/articles/{article}', [KnowledgeBaseController::class, 'destroy'])->name('articles.destroy');
        Route::post('/articles/{article}/feedback', [KnowledgeBaseController::class, 'feedback'])->name('articles.feedback');
        Route::get('/search', [KnowledgeBaseController::class, 'search'])->name('search');
        Route::get('/ai-search', [KnowledgeBaseController::class, 'aiSearch'])->name('ai-search');
        Route::get('/categories', [KnowledgeBaseController::class, 'categories'])->name('categories');
        Route::post('/categories', [KnowledgeBaseController::class, 'storeCategory'])->name('categories.store');
        Route::get('/faqs', [KnowledgeBaseController::class, 'faqs'])->name('faqs');
        Route::post('/faqs', [KnowledgeBaseController::class, 'storeFaq'])->name('faqs.store');
    });

    // Team
    Route::prefix('team')->name('team.')->group(function () {
        Route::get('/', [TeamController::class, 'index'])->name('index');
        Route::post('/', [TeamController::class, 'store'])->name('store');
        Route::get('/{user}', [TeamController::class, 'show'])->name('show');
        Route::put('/{user}', [TeamController::class, 'update'])->name('update');
        Route::delete('/{user}', [TeamController::class, 'destroy'])->name('destroy');
        Route::post('/status', [TeamController::class, 'updateStatus'])->name('status');
    });

    // Settings
    Route::prefix('settings')->name('settings.')->group(function () {
        Route::get('/', [SettingsController::class, 'index'])->name('index');
        Route::post('/', [SettingsController::class, 'update'])->name('update');
        Route::post('/branding', [SettingsController::class, 'updateBranding'])->name('branding');
        Route::post('/ai-provider', [SettingsController::class, 'updateAiProvider'])->name('ai-provider');
        Route::post('/working-hours', [SettingsController::class, 'updateWorkingHours'])->name('working-hours');
    });

    // Subscription
    Route::prefix('subscription')->name('subscription.')->group(function () {
        Route::get('/', [SubscriptionController::class, 'index'])->name('index');
        Route::post('/checkout', [SubscriptionController::class, 'checkout'])->name('checkout');
        Route::get('/success', [SubscriptionController::class, 'success'])->name('success');
        Route::post('/cancel', [SubscriptionController::class, 'cancel'])->name('cancel');
        Route::post('/resume', [SubscriptionController::class, 'resume'])->name('resume');
        Route::get('/portal', [SubscriptionController::class, 'portal'])->name('portal');
    });
});

// ─── Public Widget API (no auth required) ────────────────────────────────────
Route::prefix('api/widget')->name('api.widget.')->middleware(['api', 'throttle:60,1'])->group(function () {
    Route::post('/identify', [WidgetController::class, 'identify'])->name('identify');
    Route::post('/conversations', [WidgetController::class, 'startConversation'])->name('conversations.start');
    Route::get('/conversations/{uuid}/messages', [WidgetController::class, 'getMessages'])->name('messages');
    Route::post('/conversations/{uuid}/messages', [WidgetController::class, 'sendMessage'])->name('messages.send');
    Route::post('/conversations/{uuid}/rate', [WidgetController::class, 'rate'])->name('rate');
});

// Stripe webhook
Route::post('/stripe/webhook', [SubscriptionController::class, 'webhook'])->name('cashier.webhook');
