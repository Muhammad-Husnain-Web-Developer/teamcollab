<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class KbArticle extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'kb_articles';

    protected $fillable = [
        'category_id',
        'author_id',
        'title',
        'slug',
        'excerpt',
        'content',
        'content_text',
        'tags',
        'status',
        'is_public',
        'views',
        'helpful_count',
        'not_helpful_count',
        'order',
        'meta',
        'published_at',
    ];

    protected $casts = [
        'tags' => 'array',
        'meta' => 'array',
        'is_public' => 'boolean',
        'published_at' => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::saving(function (self $model) {
            if (empty($model->slug)) {
                $model->slug = Str::slug($model->title);
            }
            if ($model->content) {
                $model->content_text = strip_tags($model->content);
            }
        });
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(KbCategory::class, 'category_id');
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(User::class, 'author_id');
    }

    public function feedback(): HasMany
    {
        return $this->hasMany(KbArticleFeedback::class, 'article_id');
    }

    public function scopePublished($query)
    {
        return $query->where('status', 'published')->where('is_public', true);
    }

    public function scopeSearch($query, string $term)
    {
        return $query->whereFullText(['title', 'content_text'], $term)
            ->orWhere('title', 'LIKE', "%{$term}%");
    }

    public function publish(): void
    {
        $this->update([
            'status' => 'published',
            'published_at' => now(),
        ]);
    }

    public function incrementViews(): void
    {
        $this->increment('views');
    }

    public function getHelpfulRatioAttribute(): float
    {
        $total = $this->helpful_count + $this->not_helpful_count;
        if ($total === 0) return 0;
        return round($this->helpful_count / $total * 100, 1);
    }

    public function getRelevanceScore(string $query): float
    {
        $score = 0;
        $queryWords = explode(' ', strtolower($query));
        $titleLower = strtolower($this->title);
        $contentLower = strtolower($this->content_text ?? '');

        foreach ($queryWords as $word) {
            if (str_contains($titleLower, $word)) $score += 3;
            if (str_contains($contentLower, $word)) $score += 1;
        }

        $score += min($this->views / 100, 2);
        $score += ($this->helpful_ratio / 100) * 2;

        return $score;
    }
}
