<template>
  <span :class="['badge', colors[status] ?? 'badge-gray']">{{ labels[status] ?? status }}</span>
</template>
<script setup lang="ts">
defineProps<{ status: string }>();
const labels: Record<string,string> = { open:'Open', in_progress:'In Progress', waiting:'Waiting', resolved:'Resolved', closed:'Closed' };
const colors: Record<string,string> = {
  open:'badge-blue',
  in_progress:'badge-yellow',
  waiting:'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400',
  resolved:'badge-green',
  closed:'badge-gray'
};
</script>
