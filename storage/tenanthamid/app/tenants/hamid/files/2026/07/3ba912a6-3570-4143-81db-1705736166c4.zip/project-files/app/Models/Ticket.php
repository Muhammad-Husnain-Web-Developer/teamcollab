<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

class Ticket extends Model
{
    use HasFactory, SoftDeletes, LogsActivity;

    protected $fillable = [
        'ticket_number',
        'subject',
        'description',
        'customer_id',
        'assigned_to',
        'category_id',
        'conversation_id',
        'status',
        'priority',
        'tags',
        'due_at',
        'first_response_at',
        'resolved_at',
        'closed_at',
        'response_time',
        'resolution_time',
        'sla_data',
        'meta',
    ];

    protected $casts = [
        'tags' => 'array',
        'sla_data' => 'array',
        'meta' => 'array',
        'due_at' => 'datetime',
        'first_response_at' => 'datetime',
        'resolved_at' => 'datetime',
        'closed_at' => 'datetime',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(function (self $model) {
            if (empty($model->ticket_number)) {
                $model->ticket_number = static::generateTicketNumber();
            }
        });
    }

    public static function generateTicketNumber(): string
    {
        $prefix = 'TKT';
        $number = str_pad((string)(static::withTrashed()->count() + 1), 6, '0', STR_PAD_LEFT);
        return "{$prefix}-{$number}";
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['status', 'assigned_to', 'priority'])
            ->logOnlyDirty();
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function assignedTo(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(TicketCategory::class, 'category_id');
    }

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(Conversation::class);
    }

    public function replies(): HasMany
    {
        return $this->hasMany(TicketReply::class);
    }

    public function escalations(): HasMany
    {
        return $this->hasMany(TicketEscalation::class);
    }

    public function satisfactionRating(): HasOne
    {
        return $this->hasOne(SatisfactionRating::class);
    }

    public function scopeOpen($query)
    {
        return $query->where('status', 'open');
    }

    public function scopeByPriority($query, string $priority)
    {
        return $query->where('priority', $priority);
    }

    public function isOverdue(): bool
    {
        return $this->due_at && $this->due_at->isPast() && ! $this->isResolved();
    }

    public function isResolved(): bool
    {
        return in_array($this->status, ['resolved', 'closed']);
    }

    public function isBreachingSla(): bool
    {
        if (! $this->sla_data) {
            return false;
        }
        $sla = $this->sla_data;
        if (isset($sla['first_response_breach']) && $sla['first_response_breach'] && ! $this->first_response_at) {
            return true;
        }
        return false;
    }

    public function calculateResponseTime(): ?int
    {
        if ($this->first_response_at) {
            return $this->created_at->diffInSeconds($this->first_response_at);
        }
        return null;
    }

    public function calculateResolutionTime(): ?int
    {
        if ($this->resolved_at) {
            return $this->created_at->diffInSeconds($this->resolved_at);
        }
        return null;
    }

    public function getPriorityColorAttribute(): string
    {
        return match ($this->priority) {
            'urgent', 'critical' => 'red',
            'high' => 'orange',
            'normal' => 'blue',
            'low' => 'gray',
            default => 'blue',
        };
    }

    public function getStatusColorAttribute(): string
    {
        return match ($this->status) {
            'open' => 'blue',
            'in_progress' => 'yellow',
            'waiting' => 'orange',
            'resolved' => 'green',
            'closed' => 'gray',
            default => 'blue',
        };
    }
}
