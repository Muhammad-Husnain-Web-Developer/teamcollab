<template>
  <AppLayout>
    <template #header><h1 class="text-sm font-semibold text-gray-900 dark:text-white">Subscription</h1></template>
    <div class="p-6 max-w-5xl mx-auto space-y-6">

      <!-- Current plan banner -->
      <div class="card p-6 bg-gradient-to-br from-brand-600 to-violet-600 text-white border-0">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm opacity-80">Current Plan</p>
            <h2 class="text-3xl font-bold capitalize mt-1">{{ tenant.plan }}</h2>
            <p v-if="is_on_trial" class="text-sm opacity-80 mt-1">
              Trial ends {{ trial_ends_at }}
            </p>
          </div>
          <div class="text-right">
            <div class="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
              <Crown class="w-8 h-8 text-white" />
            </div>
          </div>
        </div>
        <div class="mt-4 flex gap-3">
          <button @click="openPortal" class="bg-white/20 hover:bg-white/30 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
            Manage Billing
          </button>
          <button v-if="tenant.plan !== 'free'" @click="cancelSub" class="bg-white/10 hover:bg-white/20 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
            Cancel Plan
          </button>
        </div>
      </div>

      <!-- Billing toggle -->
      <div class="flex items-center justify-center gap-4">
        <span :class="['text-sm font-medium', billing === 'monthly' ? 'text-gray-900 dark:text-white' : 'text-gray-500']">Monthly</span>
        <button @click="billing = billing === 'monthly' ? 'yearly' : 'monthly'"
                :class="['relative w-12 h-6 rounded-full transition-colors', billing === 'yearly' ? 'bg-brand-600' : 'bg-gray-300']">
          <span :class="['absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-transform', billing === 'yearly' ? 'translate-x-7' : 'translate-x-1']" />
        </button>
        <span :class="['text-sm font-medium', billing === 'yearly' ? 'text-gray-900 dark:text-white' : 'text-gray-500']">
          Yearly <span class="text-emerald-500 font-semibold">Save 17%</span>
        </span>
      </div>

      <!-- Plans -->
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <div v-for="(plan, key) in plans" :key="key"
             :class="['card p-6 relative transition-all duration-200',
                      key === 'professional' ? 'border-2 border-brand-500 shadow-lg shadow-brand-100 dark:shadow-brand-900/20 scale-105' : 'hover:shadow-md',
                      tenant.plan === key ? 'bg-brand-50 dark:bg-brand-900/10' : '']">
          <div v-if="key === 'professional'" class="absolute -top-3 left-1/2 -translate-x-1/2">
            <span class="bg-brand-600 text-white text-xs font-semibold px-3 py-1 rounded-full">Most Popular</span>
          </div>

          <div class="mb-4">
            <h3 class="text-base font-bold text-gray-900 dark:text-white">{{ plan.name }}</h3>
            <p class="text-xs text-gray-500 mt-0.5">{{ plan.description }}</p>
          </div>

          <div class="mb-5">
            <div class="flex items-end gap-1">
              <span class="text-3xl font-bold text-gray-900 dark:text-white">
                ${{ billing === 'yearly' ? plan.price_yearly / 12 : plan.price_monthly }}
              </span>
              <span class="text-sm text-gray-500 mb-1">/mo</span>
            </div>
            <p v-if="billing === 'yearly' && plan.price_yearly > 0" class="text-xs text-gray-500">
              Billed ${{ plan.price_yearly }}/year
            </p>
          </div>

          <ul class="space-y-2 mb-6">
            <li class="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
              <CheckCircle class="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
              {{ plan.features.agents === -1 ? 'Unlimited' : plan.features.agents }} agents
            </li>
            <li class="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
              <CheckCircle class="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
              {{ plan.features.chats_per_month === -1 ? 'Unlimited' : plan.features.chats_per_month.toLocaleString() }} chats/mo
            </li>
            <li class="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
              <CheckCircle class="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
              {{ plan.features.ai_responses_per_month === -1 ? 'Unlimited' : plan.features.ai_responses_per_month.toLocaleString() }} AI responses
            </li>
            <li class="flex items-center gap-2 text-xs" :class="plan.features.custom_branding ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300 dark:text-gray-600'">
              <component :is="plan.features.custom_branding ? CheckCircle : X" :class="['w-3.5 h-3.5 flex-shrink-0', plan.features.custom_branding ? 'text-emerald-500' : 'text-gray-300']" />
              Custom branding
            </li>
            <li class="flex items-center gap-2 text-xs" :class="plan.features.api_access ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300 dark:text-gray-600'">
              <component :is="plan.features.api_access ? CheckCircle : X" :class="['w-3.5 h-3.5 flex-shrink-0', plan.features.api_access ? 'text-emerald-500' : 'text-gray-300']" />
              API access
            </li>
            <li class="flex items-center gap-2 text-xs" :class="plan.features.advanced_analytics ? 'text-gray-600 dark:text-gray-400' : 'text-gray-300 dark:text-gray-600'">
              <component :is="plan.features.advanced_analytics ? CheckCircle : X" :class="['w-3.5 h-3.5 flex-shrink-0', plan.features.advanced_analytics ? 'text-emerald-500' : 'text-gray-300']" />
              Advanced analytics
            </li>
          </ul>

          <button @click="subscribe(key)"
                  :disabled="tenant.plan === key || subscribing === key"
                  :class="['w-full btn btn-sm justify-center',
                           tenant.plan === key ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-default' :
                           key === 'professional' ? 'btn-primary' : 'btn-secondary']">
            <Spinner v-if="subscribing === key" size="sm" />
            <span v-else>{{ tenant.plan === key ? 'Current Plan' : plan.price_monthly === 0 ? 'Get Started' : 'Upgrade' }}</span>
          </button>

          <p v-if="plan.trial_days > 0 && tenant.plan !== key" class="text-xs text-center text-gray-400 mt-2">
            {{ plan.trial_days }}-day free trial
          </p>
        </div>
      </div>

      <!-- Feature comparison note -->
      <div class="text-center text-xs text-gray-400">
        All plans include SSL, 24/7 uptime monitoring, and basic support. Enterprise plans include dedicated support.
      </div>
    </div>
  </AppLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { Crown, CheckCircle, X } from 'lucide-vue-next';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import Spinner from '@/Components/UI/Spinner.vue';
import { useToast } from '@/Composables/useToast';

const props = defineProps<{
  tenant: any; plans: any; current_plan: string;
  stripe_key: string; is_on_trial: boolean; trial_ends_at?: string;
}>();

const { toast } = useToast();
const billing = ref<'monthly' | 'yearly'>('monthly');
const subscribing = ref<string | null>(null);

async function subscribe(plan: string) {
  if (props.tenant.plan === plan) return;
  subscribing.value = plan;
  try {
    const { data } = await axios.post(route('tenant.subscription.checkout'), { plan, billing: billing.value });
    if (data.checkout_url) window.location.href = data.checkout_url;
    else if (data.redirect) window.location.href = data.redirect;
  } catch { toast.error('Failed to start checkout'); }
  finally { subscribing.value = null; }
}

async function cancelSub() {
  if (!confirm('Are you sure you want to cancel your subscription?')) return;
  await axios.post(route('tenant.subscription.cancel'));
  toast.success('Subscription cancelled. Access continues until billing period ends.');
  window.location.reload();
}

async function openPortal() {
  const { data } = await axios.get(route('tenant.subscription.portal'));
  window.location.href = data.url;
}
</script>
