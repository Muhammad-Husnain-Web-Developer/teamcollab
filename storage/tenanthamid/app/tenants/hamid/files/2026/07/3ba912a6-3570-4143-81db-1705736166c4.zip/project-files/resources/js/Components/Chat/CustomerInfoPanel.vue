<template>
  <div class="p-4 space-y-5">
    <!-- Customer -->
    <div class="text-center">
      <img :src="conversation.customer?.avatar_url" class="w-14 h-14 rounded-full mx-auto object-cover" />
      <h3 class="mt-2 text-sm font-semibold text-gray-900 dark:text-white">{{ conversation.customer?.name }}</h3>
      <p class="text-xs text-gray-500">{{ conversation.customer?.email }}</p>
      <div class="flex items-center justify-center gap-1.5 mt-1">
        <span class="text-xs text-gray-400">{{ conversation.customer?.company ?? 'No company' }}</span>
      </div>
    </div>

    <div class="border-t border-gray-100 dark:border-gray-800" />

    <!-- Conversation details -->
    <div class="space-y-2">
      <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Conversation</h4>
      <InfoRow label="Status"    :value="conversation.status" />
      <InfoRow label="Channel"   :value="conversation.channel" />
      <InfoRow label="Priority"  :value="conversation.priority" />
      <InfoRow label="Messages"  :value="conversation.message_count" />
      <InfoRow label="Started"   :value="formatDate(conversation.created_at)" />
      <InfoRow v-if="conversation.resolved_at" label="Resolved" :value="formatDate(conversation.resolved_at)" />
    </div>

    <div class="border-t border-gray-100 dark:border-gray-800" />

    <!-- Customer stats -->
    <div class="space-y-2">
      <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Customer Stats</h4>
      <InfoRow label="Total Conversations" :value="conversation.customer?.total_conversations ?? '—'" />
      <InfoRow label="Total Tickets"       :value="conversation.customer?.total_tickets ?? '—'" />
      <InfoRow label="Location"            :value="conversation.customer?.location ?? '—'" />
      <InfoRow label="Source"              :value="conversation.customer?.source ?? '—'" />
    </div>

    <div class="border-t border-gray-100 dark:border-gray-800" />

    <!-- Tags -->
    <div>
      <h4 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Tags</h4>
      <div class="flex flex-wrap gap-1">
        <span v-for="tag in (conversation.tags ?? [])" :key="tag"
              class="badge badge-purple text-xs">{{ tag }}</span>
        <span v-if="!conversation.tags?.length" class="text-xs text-gray-400">No tags</span>
      </div>
    </div>

    <!-- Actions -->
    <div class="space-y-2">
      <Link :href="route('tenant.customers.show', conversation.customer_id)"
            class="btn-secondary btn-sm w-full justify-center">
        <User class="w-3.5 h-3.5" /> View Profile
      </Link>
      <button @click="$emit('create-ticket')"
              class="btn-ghost btn-sm w-full justify-center">
        <Ticket class="w-3.5 h-3.5" /> Create Ticket
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Link } from '@inertiajs/vue3';
import { User, Ticket } from 'lucide-vue-next';
import InfoRow from '@/Components/Shared/InfoRow.vue';
import { formatDate } from '@/Utils/format';
defineProps<{ conversation: any }>();
defineEmits<{ 'create-ticket': [] }>();
</script>
