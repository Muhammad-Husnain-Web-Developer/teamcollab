<template>
  <div class="min-h-screen bg-gradient-to-br from-brand-50 via-white to-violet-50 flex items-center justify-center p-4">
    <div class="w-full max-w-sm">
      <div class="card card-body shadow-xl text-center space-y-4">
        <div class="w-16 h-16 bg-brand-100 rounded-2xl flex items-center justify-center mx-auto"><Mail class="w-8 h-8 text-brand-600"/></div>
        <h1 class="text-xl font-bold text-gray-900 dark:text-white">Verify your email</h1>
        <p class="text-sm text-gray-500">Please verify your email address by clicking the link we sent you.</p>
        <div v-if="status === 'verification-link-sent'" class="p-3 bg-emerald-50 text-emerald-700 text-sm rounded-lg">A new verification link has been sent!</div>
        <form @submit.prevent="submit">
          <button type="submit" :disabled="form.processing" class="btn-primary w-full justify-center">Resend Email</button>
        </form>
        <Link :href="route('logout')" method="post" as="button" class="text-sm text-gray-500 hover:text-red-500">Log Out</Link>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { Link, useForm } from '@inertiajs/vue3';
import { Mail } from 'lucide-vue-next';
defineProps<{ status?: string }>();
const form = useForm({});
function submit() { form.post(route('verification.send')); }
</script>
