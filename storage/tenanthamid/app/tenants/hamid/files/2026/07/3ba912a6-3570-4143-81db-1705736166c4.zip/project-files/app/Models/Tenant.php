<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Stancl\Tenancy\Database\Models\Tenant as BaseTenant;
use Stancl\Tenancy\Contracts\TenantWithDatabase;
use Stancl\Tenancy\Database\Concerns\HasDatabase;
use Stancl\Tenancy\Database\Concerns\HasDomains;
use Laravel\Cashier\Billable;

class Tenant extends BaseTenant implements TenantWithDatabase
{
    use HasDatabase, HasDomains, Billable;

    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'name',
        'slug',
        'email',
        'phone',
        'logo',
        'favicon',
        'primary_color',
        'secondary_color',
        'plan',
        'stripe_id',
        'stripe_status',
        'stripe_price',
        'quantity',
        'trial_ends_at',
        'data',
        'is_active',
    ];

    protected $casts = [
        'data' => 'array',
        'trial_ends_at' => 'datetime',
        'is_active' => 'boolean',
    ];

    public static function getCustomColumns(): array
    {
        return [
            'id',
            'name',
            'slug',
            'email',
            'phone',
            'logo',
            'favicon',
            'primary_color',
            'secondary_color',
            'plan',
            'stripe_id',
            'stripe_status',
            'stripe_price',
            'quantity',
            'trial_ends_at',
            'data',
            'is_active',
        ];
    }

    public function getPlanFeatures(): array
    {
        return config("plans.plans.{$this->plan}.features", []);
    }

    public function canUseFeature(string $feature): bool
    {
        $features = $this->getPlanFeatures();
        if (! isset($features[$feature])) {
            return false;
        }
        $value = $features[$feature];
        if (is_bool($value)) {
            return $value;
        }
        if ($value === -1) {
            return true;
        }
        return $value > 0;
    }

    public function getFeatureLimit(string $feature): int
    {
        return $this->getPlanFeatures()[$feature] ?? 0;
    }

    public function isOnTrial(): bool
    {
        return $this->trial_ends_at !== null && $this->trial_ends_at->isFuture();
    }

    public function hasActiveSubscription(): bool
    {
        return in_array($this->stripe_status, ['active', 'trialing']) || $this->isOnTrial();
    }
}
