<template>
    <div class="flex items-end gap-2" :class="isAgent ? 'flex-row-reverse' : 'flex-row'">
        <!-- Avatar -->
        <img v-if="!isAgent"
             :src="senderAvatar"
             :alt="senderName"
             class="w-7 h-7 rounded-full object-cover flex-shrink-0" />
        <div v-else-if="isAI"
             class="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center flex-shrink-0">
            <Zap class="w-3.5 h-3.5 text-white" />
        </div>

        <!-- Message -->
        <div class="max-w-md" :class="{ 'items-end': isAgent }">
            <!-- Sender name + time -->
            <div class="flex items-center gap-2 mb-1" :class="isAgent ? 'flex-row-reverse' : ''">
                <span class="text-xs font-medium text-gray-500 dark:text-gray-400">{{ senderName }}</span>
                <span class="text-xs text-gray-400">{{ formatTime(message.created_at) }}</span>
                <span v-if="isAI" class="text-xs text-violet-500 dark:text-violet-400 flex items-center gap-0.5">
                    <Sparkles class="w-3 h-3" /> AI
                </span>
                <span v-if="message.is_internal"
                      class="text-xs bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 px-1.5 rounded-full flex items-center gap-0.5">
                    <Lock class="w-2.5 h-2.5" /> Internal
                </span>
            </div>

            <!-- Bubble -->
            <div class="relative group">
                <div v-if="message.type === 'system'"
                     class="text-xs text-center text-gray-400 dark:text-gray-500 py-1 px-3 bg-gray-100 dark:bg-gray-800 rounded-full">
                    {{ message.content }}
                </div>
                <div v-else
                     :class="bubbleClass"
                     class="whitespace-pre-wrap break-words leading-relaxed">
                    {{ message.content }}

                    <!-- Attachments -->
                    <div v-if="message.attachments?.length" class="mt-2 space-y-1">
                        <a v-for="att in message.attachments" :key="att.path"
                           :href="att.url" target="_blank"
                           class="flex items-center gap-2 text-xs underline opacity-80 hover:opacity-100">
                            <Paperclip class="w-3 h-3" />
                            {{ att.name }}
                        </a>
                    </div>
                </div>

                <!-- Reaction button -->
                <div v-if="message.type !== 'system'"
                     class="absolute -bottom-2 opacity-0 group-hover:opacity-100 transition-opacity"
                     :class="isAgent ? 'left-0' : 'right-0'">
                    <div class="flex gap-1 bg-white dark:bg-gray-800 rounded-full shadow-lg border border-gray-100 dark:border-gray-700 px-2 py-1">
                        <button v-for="emoji in quickEmojis" :key="emoji"
                                @click="$emit('react', emoji)"
                                class="text-sm hover:scale-125 transition-transform">
                            {{ emoji }}
                        </button>
                    </div>
                </div>

                <!-- Existing reactions -->
                <div v-if="hasReactions" class="flex flex-wrap gap-1 mt-1">
                    <div v-for="(users, emoji) in message.reactions" :key="emoji"
                         v-show="users?.length > 0"
                         class="flex items-center gap-1 text-xs bg-white dark:bg-gray-800 rounded-full px-2 py-0.5 border border-gray-100 dark:border-gray-700 shadow-sm cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700"
                         @click="$emit('react', emoji)">
                        <span>{{ emoji }}</span>
                        <span class="text-gray-500">{{ users?.length }}</span>
                    </div>
                </div>
            </div>

            <!-- Message status (agent only) -->
            <div v-if="isAgent && message.type !== 'system'" class="flex justify-end mt-1">
                <span class="text-xs text-gray-400 flex items-center gap-1">
                    <CheckCheck v-if="message.status === 'seen'" class="w-3 h-3 text-brand-500" />
                    <CheckCheck v-else-if="message.status === 'delivered'" class="w-3 h-3" />
                    <Check v-else class="w-3 h-3" />
                    {{ message.status }}
                </span>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { Zap, Sparkles, Lock, Paperclip, Check, CheckCheck } from 'lucide-vue-next';
import { usePage } from '@inertiajs/vue3';
import { formatTime } from '@/Utils/format';

const props = defineProps<{ message: any }>();
defineEmits<{ react: [emoji: string] }>();

const page = usePage();
const quickEmojis = ['👍', '❤️', '😊', '😂', '👎'];

const isAI = computed(() => props.message.is_ai_generated || props.message.sender_type === 'ai');
const isAgent = computed(() => {
    if (props.message.sender_type === 'system') return false;
    if (isAI.value) return true;
    return props.message.sender_type === 'App\\Models\\User';
});

const senderName = computed(() => {
    if (isAI.value) return 'AI Assistant';
    if (props.message.sender_type === 'system') return 'System';
    return props.message.sender_name ?? props.message.sender?.name ?? 'Unknown';
});

const senderAvatar = computed(() => {
    if (isAI.value) return null;
    const sender = props.message.sender;
    if (sender?.avatar_url) return sender.avatar_url;
    const name = encodeURIComponent(senderName.value);
    return `https://ui-avatars.com/api/?name=${name}&background=10b981&color=fff&size=64`;
});

const hasReactions = computed(() =>
    props.message.reactions && Object.values(props.message.reactions).some((u: any) => u?.length > 0)
);

const bubbleClass = computed(() => {
    if (isAI.value) return 'message-bubble-ai';
    if (isAgent.value) return 'message-bubble-agent';
    if (props.message.is_internal) return 'bg-amber-50 dark:bg-amber-900/20 text-amber-800 dark:text-amber-200 border border-amber-200 dark:border-amber-800 rounded-2xl px-4 py-2.5 text-sm';
    return 'message-bubble-customer';
});
</script>
