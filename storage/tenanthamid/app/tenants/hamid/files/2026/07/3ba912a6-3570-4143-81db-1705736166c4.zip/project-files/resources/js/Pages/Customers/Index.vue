<template>
  <AppLayout>
    <template #header><h1 class="text-sm font-semibold text-gray-900 dark:text-white">Customers</h1></template>
    <div class="p-6 space-y-5">
      <!-- Stats -->
      <div class="grid grid-cols-3 gap-4">
        <StatCard title="Total Customers"    :value="stats.total"          :icon="Users"    color="indigo" />
        <StatCard title="Active"             :value="stats.active"         :icon="UserCheck" color="emerald" />
        <StatCard title="New This Month"     :value="stats.new_this_month" :icon="UserPlus" color="violet" />
      </div>

      <!-- Toolbar -->
      <div class="card card-body py-3 flex gap-3">
        <div class="relative flex-1">
          <Search class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input v-model="search" @input="debSearch" placeholder="Search by name or email..." class="input pl-9" />
        </div>
        <select v-model="statusFilter" @change="applyFilters" class="input w-40 text-sm">
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="blocked">Blocked</option>
        </select>
        <button @click="showCreate = true" class="btn-primary btn-sm"><Plus class="w-4 h-4" />Add Customer</button>
      </div>

      <!-- Table -->
      <div class="table-wrapper">
        <table class="table">
          <thead><tr><th>Customer</th><th>Company</th><th>Conversations</th><th>Tickets</th><th>Status</th><th>Last Seen</th><th></th></tr></thead>
          <tbody>
            <tr v-if="!customers.data.length"><td colspan="7"><EmptyState :icon="Users" title="No customers found" /></td></tr>
            <tr v-for="c in customers.data" :key="c.id" class="cursor-pointer" @click="router.visit(route('tenant.customers.show', c.id))">
              <td>
                <div class="flex items-center gap-3">
                  <img :src="c.avatar_url" class="w-8 h-8 rounded-full object-cover" />
                  <div>
                    <p class="font-medium text-gray-900 dark:text-white text-sm">{{ c.name }}</p>
                    <p class="text-xs text-gray-500">{{ c.email }}</p>
                  </div>
                </div>
              </td>
              <td class="text-sm text-gray-600 dark:text-gray-400">{{ c.company ?? '—' }}</td>
              <td class="text-sm text-center">{{ c.conversations_count }}</td>
              <td class="text-sm text-center">{{ c.tickets_count }}</td>
              <td><span :class="c.status === 'active' ? 'badge-green' : 'badge-red'" class="badge">{{ c.status }}</span></td>
              <td class="text-xs text-gray-500">{{ formatTime(c.last_seen_at) }}</td>
              <td @click.stop>
                <button @click="router.visit(route('tenant.customers.show', c.id))" class="btn-ghost btn-sm p-1.5"><Eye class="w-4 h-4" /></button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <Pagination :links="customers.links" :meta="customers" />
    </div>

    <Modal :show="showCreate" title="Add Customer" @close="showCreate = false">
      <form @submit.prevent="createCustomer" class="space-y-4">
        <div class="grid grid-cols-2 gap-3">
          <div><label class="label">Name *</label><input v-model="form.name" class="input" required /></div>
          <div><label class="label">Email *</label><input v-model="form.email" type="email" class="input" required /></div>
          <div><label class="label">Phone</label><input v-model="form.phone" class="input" /></div>
          <div><label class="label">Company</label><input v-model="form.company" class="input" /></div>
        </div>
        <div class="flex justify-end gap-2">
          <button type="button" @click="showCreate=false" class="btn-secondary btn-sm">Cancel</button>
          <button type="submit" class="btn-primary btn-sm">Create</button>
        </div>
      </form>
    </Modal>
  </AppLayout>
</template>
<script setup lang="ts">
import { ref, reactive } from 'vue';
import { router } from '@inertiajs/vue3';
import { Users, UserCheck, UserPlus, Search, Plus, Eye } from 'lucide-vue-next';
import { useDebounceFn } from '@vueuse/core';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import StatCard from '@/Components/Dashboard/StatCard.vue';
import Modal from '@/Components/UI/Modal.vue';
import EmptyState from '@/Components/UI/EmptyState.vue';
import Pagination from '@/Components/Shared/Pagination.vue';
import { formatTime } from '@/Utils/format';
import { useToast } from '@/Composables/useToast';
const props = defineProps<{ customers: any; stats: any; filters: any }>();
const { toast } = useToast();
const showCreate = ref(false);
const search = ref(props.filters.search ?? '');
const statusFilter = ref(props.filters.status ?? '');
const form = reactive({ name:'', email:'', phone:'', company:'' });
const debSearch = useDebounceFn(() => applyFilters(), 400);
function applyFilters() { router.get(route('tenant.customers.index'), { search: search.value||undefined, status: statusFilter.value||undefined }, { preserveState: true }); }
async function createCustomer() {
  try { await axios.post(route('tenant.customers.store'), form); showCreate.value = false; router.reload(); toast.success('Customer created!'); }
  catch { toast.error('Failed to create customer'); }
}
</script>
