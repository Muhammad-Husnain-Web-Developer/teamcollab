<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class MessageAttachment extends Model {
    protected $fillable = ['message_id','type','name','path','disk','mime_type','size','meta'];
    protected $casts = ['meta'=>'array'];
    public function message(): BelongsTo { return $this->belongsTo(Message::class); }
    public function getUrlAttribute(): string { return \Storage::disk($this->disk)->url($this->path); }
}
