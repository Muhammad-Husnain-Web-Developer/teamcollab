<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\CustomerNote;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class CustomerController extends Controller
{
    public function index(Request $request): Response
    {
        $customers = Customer::withCount(['conversations', 'tickets'])
            ->when($request->search, fn($q, $s) => $q->where('name', 'LIKE', "%{$s}%")->orWhere('email', 'LIKE', "%{$s}%"))
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->orderByDesc('created_at')
            ->paginate(25)
            ->withQueryString();

        $stats = [
            'total' => Customer::count(),
            'active' => Customer::where('status', 'active')->count(),
            'new_this_month' => Customer::where('created_at', '>=', now()->startOfMonth())->count(),
        ];

        return Inertia::render('Customers/Index', [
            'customers' => $customers,
            'stats' => $stats,
            'filters' => $request->only(['search', 'status']),
        ]);
    }

    public function show(Customer $customer): Response
    {
        $customer->loadMissing([
            'conversations.lastMessage',
            'tickets.category',
            'notes.user',
        ]);

        $timeline = collect()
            ->merge($customer->conversations->map(fn($c) => ['type' => 'conversation', 'data' => $c, 'date' => $c->created_at]))
            ->merge($customer->tickets->map(fn($t) => ['type' => 'ticket', 'data' => $t, 'date' => $t->created_at]))
            ->sortByDesc('date')
            ->values();

        return Inertia::render('Customers/Show', [
            'customer' => $customer,
            'timeline' => $timeline,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:customers,email',
            'phone' => 'nullable|string|max:30',
            'company' => 'nullable|string|max:255',
            'location' => 'nullable|string|max:255',
            'tags' => 'nullable|array',
            'notes' => 'nullable|string',
        ]);

        $customer = Customer::create($validated);
        return response()->json(['success' => true, 'customer' => $customer], 201);
    }

    public function update(Request $request, Customer $customer): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|email|unique:customers,email,' . $customer->id,
            'phone' => 'nullable|string|max:30',
            'company' => 'nullable|string|max:255',
            'location' => 'nullable|string|max:255',
            'status' => 'sometimes|in:active,blocked',
            'tags' => 'nullable|array',
            'notes' => 'nullable|string',
            'custom_attributes' => 'nullable|array',
        ]);

        $customer->update($validated);
        return response()->json(['success' => true, 'customer' => $customer->fresh()]);
    }

    public function destroy(Customer $customer): JsonResponse
    {
        $customer->delete();
        return response()->json(['success' => true]);
    }

    public function addNote(Request $request, Customer $customer): JsonResponse
    {
        $validated = $request->validate(['content' => 'required|string|max:2000']);
        $note = $customer->notes()->create([...$validated, 'user_id' => auth()->id()]);
        return response()->json(['success' => true, 'note' => $note->load('user')], 201);
    }

    public function deleteNote(Customer $customer, CustomerNote $note): JsonResponse
    {
        abort_if($note->customer_id !== $customer->id, 404);
        $note->delete();
        return response()->json(['success' => true]);
    }
}
