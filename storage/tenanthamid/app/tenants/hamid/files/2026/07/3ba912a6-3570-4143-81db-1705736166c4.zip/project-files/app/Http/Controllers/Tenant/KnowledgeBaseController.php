<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\KbArticle;
use App\Models\KbCategory;
use App\Models\KbFaq;
use App\Services\AI\AIService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class KnowledgeBaseController extends Controller
{
    public function __construct(private readonly AIService $aiService) {}

    public function index(Request $request): Response
    {
        $articles = KbArticle::with(['category', 'author'])
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->when($request->category_id, fn($q, $c) => $q->where('category_id', $c))
            ->when($request->search, fn($q, $s) => $q->where('title', 'LIKE', "%{$s}%"))
            ->orderByDesc('updated_at')
            ->paginate(20)
            ->withQueryString();

        $categories = KbCategory::withCount('articles')->get();

        $stats = [
            'total_articles' => KbArticle::count(),
            'published' => KbArticle::where('status', 'published')->count(),
            'draft' => KbArticle::where('status', 'draft')->count(),
            'total_views' => KbArticle::sum('views'),
            'total_faqs' => KbFaq::where('is_active', true)->count(),
        ];

        return Inertia::render('KB/Index', [
            'articles' => $articles,
            'categories' => $categories,
            'stats' => $stats,
            'filters' => $request->only(['status', 'category_id', 'search']),
        ]);
    }

    public function create(): Response
    {
        $categories = KbCategory::where('is_active', true)->get();
        return Inertia::render('KB/ArticleForm', ['categories' => $categories]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'excerpt' => 'nullable|string|max:500',
            'category_id' => 'nullable|exists:kb_categories,id',
            'tags' => 'nullable|array',
            'status' => 'required|in:draft,published',
            'is_public' => 'boolean',
        ]);

        $article = KbArticle::create([
            ...$validated,
            'author_id' => auth()->id(),
            'published_at' => $validated['status'] === 'published' ? now() : null,
        ]);

        return response()->json(['success' => true, 'article' => $article], 201);
    }

    public function show(KbArticle $article): Response
    {
        $article->loadMissing(['category', 'author', 'feedback']);
        $article->incrementViews();

        $relatedArticles = KbArticle::published()
            ->where('category_id', $article->category_id)
            ->where('id', '!=', $article->id)
            ->limit(5)
            ->get();

        return Inertia::render('KB/ArticleShow', [
            'article' => $article,
            'related_articles' => $relatedArticles,
        ]);
    }

    public function edit(KbArticle $article): Response
    {
        $categories = KbCategory::where('is_active', true)->get();
        return Inertia::render('KB/ArticleForm', ['article' => $article, 'categories' => $categories]);
    }

    public function update(Request $request, KbArticle $article): JsonResponse
    {
        $validated = $request->validate([
            'title' => 'sometimes|string|max:255',
            'content' => 'sometimes|string',
            'excerpt' => 'nullable|string|max:500',
            'category_id' => 'nullable|exists:kb_categories,id',
            'tags' => 'nullable|array',
            'status' => 'sometimes|in:draft,published,archived',
            'is_public' => 'boolean',
        ]);

        if (isset($validated['status']) && $validated['status'] === 'published' && ! $article->published_at) {
            $validated['published_at'] = now();
        }

        $article->update($validated);

        return response()->json(['success' => true, 'article' => $article->fresh()]);
    }

    public function destroy(KbArticle $article): JsonResponse
    {
        $article->delete();
        return response()->json(['success' => true]);
    }

    public function search(Request $request): JsonResponse
    {
        $request->validate(['query' => 'required|string|min:2']);
        $query = $request->query;

        $articles = KbArticle::published()->search($query)->limit(10)->get();
        $faqs = KbFaq::where('is_active', true)
            ->whereFullText(['question', 'answer'], $query)
            ->limit(5)
            ->get();

        return response()->json([
            'articles' => $articles->map(fn($a) => [
                'id' => $a->id,
                'title' => $a->title,
                'excerpt' => $a->excerpt,
                'slug' => $a->slug,
                'category' => $a->category?->name,
            ]),
            'faqs' => $faqs,
        ]);
    }

    public function aiSearch(Request $request): JsonResponse
    {
        $request->validate(['query' => 'required|string|min:3']);

        $results = $this->aiService->searchKnowledgeBase($request->query);

        return response()->json([
            'results' => collect($results)->map(fn($item) => [
                'article' => [
                    'id' => $item['article']->id,
                    'title' => $item['article']->title,
                    'excerpt' => $item['article']->excerpt,
                    'slug' => $item['article']->slug,
                ],
                'score' => $item['score'],
            ]),
        ]);
    }

    public function feedback(Request $request, KbArticle $article): JsonResponse
    {
        $request->validate(['is_helpful' => 'required|boolean', 'feedback' => 'nullable|string|max:500']);

        $article->feedback()->create([
            'customer_id' => auth()->guard('customer')->id(),
            'is_helpful' => $request->boolean('is_helpful'),
            'feedback' => $request->feedback,
            'ip_address' => $request->ip(),
        ]);

        $field = $request->boolean('is_helpful') ? 'helpful_count' : 'not_helpful_count';
        $article->increment($field);

        return response()->json(['success' => true]);
    }

    // Categories
    public function categories(): Response
    {
        $categories = KbCategory::withCount(['articles' => fn($q) => $q->where('status', 'published')])->get();
        return Inertia::render('KB/Categories', ['categories' => $categories]);
    }

    public function storeCategory(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'description' => 'nullable|string',
            'icon' => 'nullable|string',
            'color' => 'nullable|string',
            'parent_id' => 'nullable|exists:kb_categories,id',
            'is_public' => 'boolean',
        ]);

        $category = KbCategory::create($validated);
        return response()->json(['success' => true, 'category' => $category], 201);
    }

    // FAQs
    public function faqs(Request $request): Response
    {
        $faqs = KbFaq::with('category')
            ->when($request->category_id, fn($q, $c) => $q->where('category_id', $c))
            ->where('is_active', true)
            ->orderBy('order')
            ->get();

        $categories = KbCategory::where('is_active', true)->get();

        return Inertia::render('KB/Faqs', ['faqs' => $faqs, 'categories' => $categories]);
    }

    public function storeFaq(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'question' => 'required|string|max:500',
            'answer' => 'required|string',
            'category_id' => 'nullable|exists:kb_categories,id',
            'tags' => 'nullable|array',
            'is_public' => 'boolean',
            'order' => 'integer',
        ]);

        $faq = KbFaq::create($validated);
        return response()->json(['success' => true, 'faq' => $faq], 201);
    }
}
