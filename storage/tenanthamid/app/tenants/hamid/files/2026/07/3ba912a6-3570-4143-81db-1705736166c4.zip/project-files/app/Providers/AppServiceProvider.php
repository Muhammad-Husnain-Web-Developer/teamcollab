<?php

namespace App\Providers;

use App\Services\AI\AIService;
use App\Services\Chat\ChatService;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(AIService::class, fn($app) => new AIService());
        $this->app->singleton(ChatService::class, fn($app) => new ChatService($app->make(AIService::class)));
    }

    public function boot(): void
    {
        \Illuminate\Support\Facades\URL::forceScheme(config('app.env') === 'production' ? 'https' : 'http');
    }
}
