import { onMounted, onUnmounted } from 'vue';

export function useConversationChannel(conversationId: number, handlers: Record<string, (data: any) => void>) {
    let channel: any;

    onMounted(() => {
        channel = window.Echo.join(`conversation.${conversationId}`);
        Object.entries(handlers).forEach(([event, handler]) => {
            channel.listen(`.${event}`, handler);
        });
    });

    onUnmounted(() => {
        window.Echo?.leave(`conversation.${conversationId}`);
    });

    return { channel };
}

export function useConversationsChannel(handlers: Record<string, (data: any) => void>) {
    let channel: any;

    onMounted(() => {
        channel = window.Echo.channel('conversations');
        Object.entries(handlers).forEach(([event, handler]) => {
            channel.listen(`.${event}`, handler);
        });
    });

    onUnmounted(() => {
        window.Echo?.leave('conversations');
    });
}

export function useAgentsChannel(handlers: Record<string, (data: any) => void>) {
    let channel: any;

    onMounted(() => {
        channel = window.Echo.channel('agents');
        Object.entries(handlers).forEach(([event, handler]) => {
            channel.listen(`.${event}`, handler);
        });
    });

    onUnmounted(() => {
        window.Echo?.leave('agents');
    });
}
