<?php

use App\Http\Controllers\Admin\AdminController;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

// Central domain routes
Route::middleware(['web'])->group(function () {
    // Landing / Marketing
    Route::get('/', fn() => Inertia::render('Landing'))->name('home');

    // Admin routes (super admin)
    Route::prefix('admin')->name('admin.')->middleware(['auth', 'role:super_admin'])->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
        Route::get('/tenants', [AdminController::class, 'tenants'])->name('tenants');
        Route::post('/tenants', [AdminController::class, 'createTenant'])->name('tenants.store');
        Route::put('/tenants/{tenant}', [AdminController::class, 'updateTenant'])->name('tenants.update');
        Route::delete('/tenants/{tenant}', [AdminController::class, 'deleteTenant'])->name('tenants.delete');
    });

    // Auth routes (Breeze handles these)
    require __DIR__ . '/auth.php';
});
