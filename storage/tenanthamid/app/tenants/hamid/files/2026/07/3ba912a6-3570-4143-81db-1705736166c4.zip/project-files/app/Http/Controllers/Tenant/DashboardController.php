<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Customer;
use App\Models\Message;
use App\Models\SatisfactionRating;
use App\Models\Ticket;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;
use Inertia\Response;

class DashboardController extends Controller
{
    public function index(): Response
    {
        $now = now();
        $startOfMonth = $now->copy()->startOfMonth();
        $startOfWeek = $now->copy()->startOfWeek();
        $today = $now->copy()->startOfDay();

        $stats = [
            'customers' => [
                'total' => Customer::count(),
                'new_this_month' => Customer::where('created_at', '>=', $startOfMonth)->count(),
                'active' => Customer::where('status', 'active')->count(),
            ],
            'conversations' => [
                'total' => Conversation::count(),
                'open' => Conversation::where('status', 'open')->count(),
                'ai_handled' => Conversation::where('type', 'ai')->count(),
                'human_handled' => Conversation::where('type', 'human')->count(),
                'resolved_today' => Conversation::where('status', 'resolved')->whereDate('resolved_at', $today)->count(),
            ],
            'tickets' => [
                'total' => Ticket::count(),
                'open' => Ticket::where('status', 'open')->count(),
                'in_progress' => Ticket::where('status', 'in_progress')->count(),
                'overdue' => Ticket::whereNotNull('due_at')->where('due_at', '<', $now)->whereNotIn('status', ['resolved', 'closed'])->count(),
                'resolved_today' => Ticket::where('status', 'resolved')->whereDate('resolved_at', $today)->count(),
            ],
            'agents' => [
                'total' => User::role(['agent', 'manager'])->count(),
                'online' => User::role(['agent', 'manager'])->where('status', 'online')->count(),
                'busy' => User::role(['agent', 'manager'])->where('status', 'busy')->count(),
            ],
            'response_time' => [
                'average' => Ticket::whereNotNull('response_time')->avg('response_time') ?? 0,
                'this_week' => Ticket::whereNotNull('response_time')->where('created_at', '>=', $startOfWeek)->avg('response_time') ?? 0,
            ],
            'satisfaction' => [
                'average' => SatisfactionRating::avg('rating') ?? 0,
                'total' => SatisfactionRating::count(),
            ],
        ];

        // Conversation trend (last 7 days)
        $conversationTrend = Conversation::select(
            DB::raw('DATE(created_at) as date'),
            DB::raw('COUNT(*) as total'),
            DB::raw('SUM(CASE WHEN type = "ai" THEN 1 ELSE 0 END) as ai_count'),
            DB::raw('SUM(CASE WHEN type = "human" THEN 1 ELSE 0 END) as human_count'),
        )
            ->where('created_at', '>=', $now->copy()->subDays(7))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Top agents this week
        $topAgents = User::role(['agent', 'manager'])
            ->withCount([
                'tickets as resolved_tickets' => fn($q) => $q->where('status', 'resolved')->where('updated_at', '>=', $startOfWeek),
            ])
            ->withCount([
                'conversations as active_conversations' => fn($q) => $q->where('status', 'open'),
            ])
            ->orderByDesc('resolved_tickets')
            ->limit(5)
            ->get();

        // Recent activities
        $recentConversations = Conversation::with(['customer', 'lastMessage'])
            ->latest('last_activity_at')
            ->limit(5)
            ->get();

        return Inertia::render('Dashboard/Index', [
            'stats' => $stats,
            'conversation_trend' => $conversationTrend,
            'top_agents' => $topAgents,
            'recent_conversations' => $recentConversations,
        ]);
    }

    public function analytics(Request $request): Response
    {
        $period = $request->get('period', '30');
        $startDate = now()->subDays((int)$period);

        // Conversations by day
        $conversationsByDay = Conversation::select(
            DB::raw('DATE(created_at) as date'),
            DB::raw('COUNT(*) as count'),
        )
            ->where('created_at', '>=', $startDate)
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // Ticket stats by status
        $ticketsByStatus = Ticket::select('status', DB::raw('COUNT(*) as count'))
            ->where('created_at', '>=', $startDate)
            ->groupBy('status')
            ->get();

        // Agent performance
        $agentPerformance = User::role(['agent', 'manager'])
            ->withCount([
                'tickets as total_tickets' => fn($q) => $q->where('created_at', '>=', $startDate),
                'tickets as resolved_tickets' => fn($q) => $q->where('status', 'resolved')->where('created_at', '>=', $startDate),
            ])
            ->having('total_tickets', '>', 0)
            ->get();

        // Satisfaction over time
        $satisfactionTrend = SatisfactionRating::select(
            DB::raw('DATE(created_at) as date'),
            DB::raw('AVG(rating) as avg_rating'),
            DB::raw('COUNT(*) as count'),
        )
            ->where('created_at', '>=', $startDate)
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        return Inertia::render('Dashboard/Analytics', [
            'period' => $period,
            'conversations_by_day' => $conversationsByDay,
            'tickets_by_status' => $ticketsByStatus,
            'agent_performance' => $agentPerformance,
            'satisfaction_trend' => $satisfactionTrend,
        ]);
    }
}
