<template>
    <div @click="$emit('click')"
         class="px-4 py-3 cursor-pointer transition-colors hover:bg-gray-50 dark:hover:bg-gray-800/50 border-b border-gray-100 dark:border-gray-800/50"
         :class="{ 'bg-brand-50 dark:bg-brand-900/10': active }">
        <div class="flex items-start gap-3">
            <div class="relative flex-shrink-0">
                <img :src="conversation.customer?.avatar_url"
                     class="w-9 h-9 rounded-full object-cover"
                     :alt="conversation.customer?.name" />
                <span v-if="!conversation.is_read"
                      class="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-brand-500 rounded-full border-2 border-white dark:border-gray-900" />
            </div>
            <div class="flex-1 min-w-0">
                <div class="flex items-center justify-between gap-1">
                    <span class="text-sm font-medium text-gray-900 dark:text-white truncate"
                          :class="{ 'font-semibold': !conversation.is_read }">
                        {{ conversation.customer?.name }}
                    </span>
                    <span class="text-xs text-gray-400 flex-shrink-0">{{ formatTime(conversation.last_activity_at) }}</span>
                </div>
                <p class="text-xs text-gray-500 dark:text-gray-400 truncate mt-0.5">
                    {{ conversation.last_message?.content ?? 'No messages' }}
                </p>
                <div class="flex items-center gap-1.5 mt-1.5">
                    <span class="text-xs px-1.5 py-0.5 rounded-full"
                          :class="typeColors[conversation.type] ?? 'bg-gray-100 text-gray-500'">
                        {{ conversation.type }}
                    </span>
                    <span class="text-xs px-1.5 py-0.5 rounded-full"
                          :class="priorityColors[conversation.priority] ?? ''">
                        {{ conversation.priority }}
                    </span>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { formatTime } from '@/Utils/format';

defineProps<{ conversation: any; active?: boolean }>();
defineEmits<{ click: [] }>();

const typeColors: Record<string, string> = {
    ai:     'bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-400',
    human:  'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
    hybrid: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
};
const priorityColors: Record<string, string> = {
    urgent:   'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
    high:     'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
    normal:   'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400',
    low:      'bg-gray-50 text-gray-500 dark:bg-gray-800/50 dark:text-gray-500',
};
</script>
