<template>
  <span class="badge" :class="colors[status]">{{ status }}</span>
</template>
<script setup lang="ts">
defineProps<{ status: string }>();
const colors: Record<string,string> = {
  open:       'badge-blue',
  waiting:    'badge-yellow',
  resolved:   'badge-green',
  closed:     'badge-gray',
};
</script>
