<?php

return [
    'default_provider' => env('AI_DEFAULT_PROVIDER', 'gemini'),

    'providers' => [
        'gemini' => [
            'driver' => 'gemini',
            'api_key' => env('GEMINI_API_KEY'),
            'model' => env('GEMINI_MODEL', 'gemini-1.5-flash'),
            'base_url' => 'https://generativelanguage.googleapis.com/v1beta',
            'max_tokens' => 2048,
            'temperature' => 0.7,
        ],

        'openai' => [
            'driver' => 'openai',
            'api_key' => env('OPENAI_API_KEY'),
            'organization' => env('OPENAI_ORGANIZATION'),
            'model' => env('OPENAI_MODEL', 'gpt-4o'),
            'max_tokens' => 2048,
            'temperature' => 0.7,
        ],

        'claude' => [
            'driver' => 'claude',
            'api_key' => env('CLAUDE_API_KEY'),
            'model' => env('CLAUDE_MODEL', 'claude-3-5-sonnet-20241022'),
            'max_tokens' => 2048,
            'temperature' => 0.7,
        ],

        'ollama' => [
            'driver' => 'ollama',
            'host' => env('OLLAMA_HOST', 'http://localhost:11434'),
            'model' => env('OLLAMA_MODEL', 'llama3'),
            'max_tokens' => 2048,
            'temperature' => 0.7,
        ],
    ],

    'rag' => [
        'chunk_size' => 500,
        'chunk_overlap' => 50,
        'max_articles' => 5,
        'similarity_threshold' => 0.7,
    ],

    'system_prompt' => <<<'PROMPT'
You are a helpful AI customer support assistant. Your primary goal is to help customers resolve their issues efficiently and professionally.

Guidelines:
- Be empathetic, professional, and solution-focused
- Use the provided knowledge base articles to answer questions accurately
- If you cannot find a satisfactory answer in the knowledge base, honestly acknowledge this
- Ask clarifying questions when needed
- If an issue is complex or requires human expertise, recommend escalation to a human agent
- Keep responses concise but thorough
- Never make up information or policies

When you need to escalate to a human agent, respond with: [ESCALATE]
PROMPT,
];
