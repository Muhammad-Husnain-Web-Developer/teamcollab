<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Tenant;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response;

class AdminController extends Controller
{
    public function dashboard(): Response
    {
        $stats = [
            'total_tenants' => Tenant::count(),
            'active_tenants' => Tenant::where('is_active', true)->count(),
            'plans' => Tenant::selectRaw('plan, COUNT(*) as count')->groupBy('plan')->pluck('count', 'plan'),
        ];

        $tenants = Tenant::withCount('domains')->latest()->limit(10)->get();

        return Inertia::render('Admin/Dashboard', [
            'stats' => $stats,
            'recent_tenants' => $tenants,
        ]);
    }

    public function tenants(Request $request): Response
    {
        $tenants = Tenant::withCount('domains')
            ->when($request->search, fn($q, $s) => $q->where('name', 'LIKE', "%{$s}%")->orWhere('email', 'LIKE', "%{$s}%"))
            ->when($request->plan, fn($q, $p) => $q->where('plan', $p))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        return Inertia::render('Admin/Tenants', [
            'tenants' => $tenants,
            'filters' => $request->only(['search', 'plan']),
        ]);
    }

    public function createTenant(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:tenants,email',
            'slug' => 'required|string|alpha_dash|unique:tenants,slug',
            'domain' => 'required|string',
            'plan' => 'required|in:free,starter,professional,enterprise',
        ]);

        $tenant = Tenant::create([
            'id' => Str::uuid()->toString(),
            'name' => $validated['name'],
            'email' => $validated['email'],
            'slug' => $validated['slug'],
            'plan' => $validated['plan'],
        ]);

        $tenant->domains()->create(['domain' => $validated['domain']]);

        // Run tenant migrations
        tenancy()->initialize($tenant);
        \Artisan::call('tenants:migrate', ['--tenants' => [$tenant->id]]);
        tenancy()->end();

        return response()->json(['success' => true, 'tenant' => $tenant], 201);
    }

    public function updateTenant(Request $request, string $tenantId): JsonResponse
    {
        $tenant = Tenant::findOrFail($tenantId);
        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'plan' => 'sometimes|in:free,starter,professional,enterprise',
            'is_active' => 'boolean',
        ]);

        $tenant->update($validated);
        return response()->json(['success' => true, 'tenant' => $tenant->fresh()]);
    }

    public function deleteTenant(string $tenantId): JsonResponse
    {
        $tenant = Tenant::findOrFail($tenantId);
        $tenant->delete();
        return response()->json(['success' => true]);
    }
}
