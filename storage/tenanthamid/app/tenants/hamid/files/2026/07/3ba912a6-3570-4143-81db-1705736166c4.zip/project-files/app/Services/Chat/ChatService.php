<?php

namespace App\Services\Chat;

use App\Events\ConversationUpdated;
use App\Events\MessageSent;
use App\Events\NewConversation;
use App\Events\TypingIndicator;
use App\Jobs\ProcessAiResponse;
use App\Models\Conversation;
use App\Models\Customer;
use App\Models\Message;
use App\Models\User;
use App\Services\AI\AIService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ChatService
{
    public function __construct(
        private readonly AIService $aiService
    ) {}

    /**
     * Create a new conversation for a customer.
     */
    public function createConversation(Customer $customer, array $data = []): Conversation
    {
        return DB::transaction(function () use ($customer, $data) {
            $conversation = Conversation::create([
                'customer_id' => $customer->id,
                'status' => 'open',
                'type' => 'ai',
                'channel' => $data['channel'] ?? 'web',
                'priority' => $data['priority'] ?? 'normal',
                'subject' => $data['subject'] ?? null,
                'last_activity_at' => now(),
            ]);

            $conversation->aiConversation()->create([
                'provider' => config('ai.default_provider', 'gemini'),
                'model' => config("ai.providers." . config('ai.default_provider', 'gemini') . ".model", ''),
                'context' => [],
            ]);

            if (! empty($data['initial_message'])) {
                $this->sendCustomerMessage($conversation, $customer, $data['initial_message']);
            }

            broadcast(new NewConversation($conversation))->toOthers();

            return $conversation;
        });
    }

    /**
     * Send a message from a customer.
     */
    public function sendCustomerMessage(Conversation $conversation, Customer $customer, string $content, array $attachments = []): Message
    {
        return DB::transaction(function () use ($conversation, $customer, $content, $attachments) {
            $message = Message::create([
                'conversation_id' => $conversation->id,
                'sender_id' => $customer->id,
                'sender_type' => Customer::class,
                'type' => 'text',
                'content' => $content,
                'attachments' => $attachments,
                'status' => 'sent',
            ]);

            broadcast(new MessageSent($message))->toOthers();

            // If AI conversation, dispatch AI response job
            if ($conversation->type === 'ai') {
                ProcessAiResponse::dispatch($conversation, $message)->onQueue('ai');
            } else {
                // Notify assigned agent
                $this->notifyAgent($conversation, $message);
            }

            return $message;
        });
    }

    /**
     * Send a message from an agent.
     */
    public function sendAgentMessage(Conversation $conversation, User $agent, string $content, bool $isInternal = false, array $attachments = []): Message
    {
        return DB::transaction(function () use ($conversation, $agent, $content, $isInternal, $attachments) {
            $message = Message::create([
                'conversation_id' => $conversation->id,
                'sender_id' => $agent->id,
                'sender_type' => User::class,
                'type' => 'text',
                'content' => $content,
                'is_internal' => $isInternal,
                'attachments' => $attachments,
                'status' => 'sent',
            ]);

            if (! $conversation->first_response_at) {
                $conversation->update(['first_response_at' => now()]);
            }

            if (! $isInternal) {
                broadcast(new MessageSent($message))->toOthers();
            }

            return $message;
        });
    }

    /**
     * Send AI-generated message.
     */
    public function sendAiMessage(Conversation $conversation, string $content, array $aiMeta = []): Message
    {
        $message = Message::create([
            'conversation_id' => $conversation->id,
            'sender_id' => 0, // AI sender
            'sender_type' => 'ai',
            'type' => 'text',
            'content' => $content,
            'is_ai_generated' => true,
            'ai_confidence' => $aiMeta['confidence_score'] ?? null,
            'status' => 'sent',
            'meta' => $aiMeta,
        ]);

        broadcast(new MessageSent($message))->toOthers();

        return $message;
    }

    /**
     * Assign conversation to an agent.
     */
    public function assignConversation(Conversation $conversation, ?User $agent): void
    {
        $conversation->update([
            'assigned_to' => $agent?->id,
            'type' => $agent ? 'human' : 'ai',
        ]);

        if ($agent) {
            $agent->availability()->increment('current_conversations');

            $this->sendSystemMessage($conversation, "Conversation assigned to {$agent->name}");
        }

        broadcast(new ConversationUpdated($conversation))->toOthers();
    }

    /**
     * Transfer conversation to another agent.
     */
    public function transferConversation(Conversation $conversation, User $fromAgent, User $toAgent): void
    {
        if ($conversation->assigned_to) {
            $fromAgent->availability()->decrement('current_conversations');
        }

        $conversation->update(['assigned_to' => $toAgent->id]);
        $toAgent->availability()->increment('current_conversations');

        $this->sendSystemMessage(
            $conversation,
            "Conversation transferred from {$fromAgent->name} to {$toAgent->name}"
        );

        broadcast(new ConversationUpdated($conversation))->toOthers();
    }

    /**
     * Escalate from AI to human agent.
     */
    public function escalateToHuman(Conversation $conversation, ?int $agentId = null): void
    {
        if (! $agentId) {
            $agentId = $this->aiService->findAvailableAgent();
        }

        $conversation->escalateToHuman($agentId);

        if ($agentId) {
            $agent = User::find($agentId);
            if ($agent) {
                $agent->availability()->increment('current_conversations');
                $this->sendSystemMessage($conversation, "Conversation transferred to {$agent->name}");
                $this->notifyAgent($conversation, null, $agent);
            }
        } else {
            $this->sendSystemMessage($conversation, "Waiting for an available agent...");
        }

        broadcast(new ConversationUpdated($conversation))->toOthers();
    }

    /**
     * Resolve a conversation.
     */
    public function resolveConversation(Conversation $conversation, User $resolvedBy): void
    {
        $conversation->update([
            'status' => 'resolved',
            'resolved_at' => now(),
        ]);

        if ($conversation->assigned_to) {
            $conversation->assignedTo?->availability()->decrement('current_conversations');
        }

        $this->sendSystemMessage($conversation, "Conversation resolved by {$resolvedBy->name}");
        broadcast(new ConversationUpdated($conversation))->toOthers();
    }

    /**
     * Handle typing indicator.
     */
    public function handleTyping(Conversation $conversation, $typist, bool $isTyping): void
    {
        broadcast(new TypingIndicator($conversation, $typist, $isTyping))->toOthers();
    }

    /**
     * Send a system message to the conversation.
     */
    public function sendSystemMessage(Conversation $conversation, string $content): Message
    {
        $message = Message::create([
            'conversation_id' => $conversation->id,
            'sender_id' => 0,
            'sender_type' => 'system',
            'type' => 'system',
            'content' => $content,
            'status' => 'sent',
        ]);

        broadcast(new MessageSent($message))->toOthers();

        return $message;
    }

    /**
     * Notify agent of new message.
     */
    private function notifyAgent(Conversation $conversation, ?Message $message, ?User $specificAgent = null): void
    {
        $agent = $specificAgent ?? $conversation->assignedTo;
        if ($agent) {
            $agent->notify(new \App\Notifications\NewMessageNotification($conversation, $message));
        }
    }

    /**
     * Get conversation statistics.
     */
    public function getStats(): array
    {
        return [
            'total' => Conversation::count(),
            'open' => Conversation::where('status', 'open')->count(),
            'ai_handled' => Conversation::where('type', 'ai')->count(),
            'human_handled' => Conversation::where('type', 'human')->count(),
            'resolved_today' => Conversation::where('status', 'resolved')
                ->whereDate('resolved_at', today())->count(),
        ];
    }
}
