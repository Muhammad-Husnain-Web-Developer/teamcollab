<?php

namespace App\Services\AI;

use App\Models\Conversation;
use App\Models\KbArticle;
use App\Models\Message;
use App\Models\Setting;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class AIService
{
    private AIProviderInterface $provider;

    public function __construct()
    {
        $this->provider = $this->resolveProvider();
    }

    private function resolveProvider(): AIProviderInterface
    {
        $providerName = Setting::getValue('ai_provider', config('ai.default_provider', 'gemini'));
        return $this->makeProvider($providerName);
    }

    public function makeProvider(string $name): AIProviderInterface
    {
        $config = config("ai.providers.{$name}", []);
        return match ($name) {
            'gemini' => new GeminiProvider($config),
            'openai' => new OpenAIProvider($config),
            'claude' => new ClaudeProvider($config),
            'ollama' => new OllamaProvider($config),
            default => throw new \InvalidArgumentException("Unknown AI provider: {$name}"),
        };
    }

    public function getProvider(): AIProviderInterface
    {
        return $this->provider;
    }

    /**
     * Handle customer message with RAG-like knowledge base search.
     */
    public function handleCustomerMessage(Conversation $conversation, string $message): AIResponse
    {
        // 1. Search knowledge base for relevant articles
        $relevantArticles = $this->searchKnowledgeBase($message);

        // 2. Build context from conversation history
        $history = $this->buildConversationHistory($conversation);

        // 3. Build enhanced system prompt with KB context
        $systemPrompt = $this->buildSystemPrompt($relevantArticles);

        // 4. Add new user message
        $history[] = ['role' => 'user', 'content' => $message];

        // 5. Generate response
        $response = $this->provider->generateResponse($history, $systemPrompt);

        return $response;
    }

    /**
     * Search knowledge base for relevant articles.
     */
    public function searchKnowledgeBase(string $query, int $limit = 5): array
    {
        $cacheKey = 'kb_search_' . md5($query);

        return Cache::remember($cacheKey, 300, function () use ($query, $limit) {
            $articles = KbArticle::published()
                ->search($query)
                ->limit($limit * 2)
                ->get();

            $scoredArticles = $articles->map(function (KbArticle $article) use ($query) {
                return [
                    'article' => $article,
                    'score' => $article->getRelevanceScore($query),
                ];
            })
                ->sortByDesc('score')
                ->take($limit)
                ->filter(fn($item) => $item['score'] > 0)
                ->values()
                ->toArray();

            return $scoredArticles;
        });
    }

    /**
     * Build conversation history for context.
     */
    public function buildConversationHistory(Conversation $conversation, int $limit = 20): array
    {
        $messages = $conversation->messages()
            ->where('is_internal', false)
            ->orderBy('created_at', 'asc')
            ->limit($limit)
            ->get();

        return $messages->map(function (Message $message) {
            $isCustomer = $message->sender_type === 'App\\Models\\Customer';
            return [
                'role' => $isCustomer ? 'user' : 'assistant',
                'content' => $message->content,
            ];
        })->toArray();
    }

    /**
     * Build system prompt with knowledge base articles.
     */
    private function buildSystemPrompt(array $relevantArticles): string
    {
        $basePrompt = config('ai.system_prompt');

        if (empty($relevantArticles)) {
            return $basePrompt;
        }

        $kbContext = "\n\nRELEVANT KNOWLEDGE BASE ARTICLES:\n";
        foreach ($relevantArticles as $item) {
            $article = $item['article'];
            $kbContext .= "\n--- {$article->title} ---\n";
            $kbContext .= substr($article->content_text ?? '', 0, 800) . "\n";
        }

        $kbContext .= "\nUse the above articles to inform your response. If none are relevant, rely on your general knowledge while being honest about limitations.";

        return $basePrompt . $kbContext;
    }

    /**
     * Generate smart reply suggestions for agents.
     */
    public function generateSmartSuggestions(Conversation $conversation, int $count = 3): array
    {
        $history = $this->buildConversationHistory($conversation, 10);
        if (empty($history)) {
            return [];
        }

        $prompt = "Based on this customer support conversation, suggest {$count} different professional response options for the agent. Format as a JSON array with 'label' and 'content' for each suggestion.";

        try {
            $response = $this->provider->generateResponse($history, $prompt);
            $suggestions = json_decode($response->content, true);
            return is_array($suggestions) ? $suggestions : [];
        } catch (\Exception $e) {
            Log::error('Smart suggestions error', ['error' => $e->getMessage()]);
            return [];
        }
    }

    /**
     * Summarize a conversation.
     */
    public function summarizeConversation(Conversation $conversation): string
    {
        $history = $this->buildConversationHistory($conversation);
        if (empty($history)) {
            return 'No messages to summarize.';
        }

        $summaryPrompt = "Summarize this customer support conversation in 2-3 sentences. Focus on: the customer's issue, actions taken, and current status.";

        try {
            $response = $this->provider->generateResponse($history, $summaryPrompt);
            return $response->content;
        } catch (\Exception $e) {
            Log::error('Conversation summary error', ['error' => $e->getMessage()]);
            return 'Unable to generate summary.';
        }
    }

    /**
     * Check if the AI should escalate based on response.
     */
    public function shouldEscalate(AIResponse $response): bool
    {
        return $response->needsHumanEscalation() || $response->confidenceScore < 0.4;
    }

    /**
     * Find the best available agent for escalation.
     */
    public function findAvailableAgent(): ?int
    {
        $agent = \App\Models\AgentAvailability::where('status', 'online')
            ->whereColumn('current_conversations', '<', 'max_conversations')
            ->join('users', 'agent_availability.user_id', '=', 'users.id')
            ->where('users.is_active', true)
            ->orderBy('current_conversations', 'asc')
            ->first();

        return $agent?->user_id;
    }
}
