import { formatDistanceToNow, format, parseISO } from 'date-fns';

export function formatTime(date: string | Date | null | undefined): string {
    if (!date) return '';
    try {
        const d = typeof date === 'string' ? parseISO(date) : date;
        return formatDistanceToNow(d, { addSuffix: true });
    } catch {
        return '';
    }
}

export function formatDate(date: string | Date | null | undefined): string {
    if (!date) return '—';
    try {
        const d = typeof date === 'string' ? parseISO(date) : date;
        return format(d, 'MMM d, yyyy');
    } catch {
        return '—';
    }
}

export function formatDateTime(date: string | Date | null | undefined): string {
    if (!date) return '—';
    try {
        const d = typeof date === 'string' ? parseISO(date) : date;
        return format(d, 'MMM d, yyyy h:mm a');
    } catch {
        return '—';
    }
}

export function formatDuration(seconds: number): string {
    if (!seconds || seconds <= 0) return '—';
    if (seconds < 60) return `${Math.round(seconds)}s`;
    if (seconds < 3600) return `${Math.round(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.round(seconds / 3600)}h`;
    return `${Math.round(seconds / 86400)}d`;
}

export function formatBytes(bytes: number): string {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export function truncate(str: string, length: number): string {
    if (!str) return '';
    return str.length > length ? str.slice(0, length) + '…' : str;
}
