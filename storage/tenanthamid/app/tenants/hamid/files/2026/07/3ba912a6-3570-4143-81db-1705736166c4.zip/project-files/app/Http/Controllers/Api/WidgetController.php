<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Customer;
use App\Services\Chat\ChatService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WidgetController extends Controller
{
    public function __construct(private readonly ChatService $chatService) {}

    public function identify(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'email' => 'required|email',
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:30',
            'company' => 'nullable|string|max:255',
            'custom_attributes' => 'nullable|array',
        ]);

        $customer = Customer::updateOrCreate(
            ['email' => $validated['email']],
            [
                'name' => $validated['name'],
                'phone' => $validated['phone'] ?? null,
                'company' => $validated['company'] ?? null,
                'custom_attributes' => $validated['custom_attributes'] ?? null,
                'source' => 'widget',
                'last_seen_at' => now(),
            ]
        );

        return response()->json(['customer_id' => $customer->id, 'name' => $customer->name]);
    }

    public function startConversation(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'message' => 'required|string|max:2000',
            'channel' => 'nullable|in:web,widget',
        ]);

        $customer = Customer::findOrFail($validated['customer_id']);

        // Check for an existing open conversation
        $existing = Conversation::where('customer_id', $customer->id)
            ->where('status', 'open')
            ->latest()
            ->first();

        if ($existing) {
            $this->chatService->sendCustomerMessage($existing, $customer, $validated['message']);
            return response()->json(['conversation_id' => $existing->uuid, 'status' => 'existing']);
        }

        $conversation = $this->chatService->createConversation($customer, [
            'channel' => $validated['channel'] ?? 'widget',
            'initial_message' => $validated['message'],
        ]);

        return response()->json(['conversation_id' => $conversation->uuid, 'status' => 'new'], 201);
    }

    public function getMessages(Request $request, string $uuid): JsonResponse
    {
        $conversation = Conversation::where('uuid', $uuid)->firstOrFail();

        $messages = $conversation->publicMessages()
            ->with('sender')
            ->orderBy('created_at')
            ->get()
            ->map(fn($m) => [
                'id' => $m->id,
                'content' => $m->content,
                'type' => $m->type,
                'sender_type' => $m->sender_type,
                'sender_name' => $m->sender?->name ?? 'AI Assistant',
                'is_ai_generated' => $m->is_ai_generated,
                'attachments' => $m->attachments,
                'created_at' => $m->created_at->toISOString(),
            ]);

        return response()->json(['messages' => $messages]);
    }

    public function sendMessage(Request $request, string $uuid): JsonResponse
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'message' => 'required|string|max:2000',
        ]);

        $conversation = Conversation::where('uuid', $uuid)->firstOrFail();
        $customer = Customer::findOrFail($validated['customer_id']);

        $message = $this->chatService->sendCustomerMessage($conversation, $customer, $validated['message']);

        return response()->json([
            'message_id' => $message->id,
            'status' => 'sent',
        ]);
    }

    public function rate(Request $request, string $uuid): JsonResponse
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'rating' => 'required|integer|between:1,5',
            'comment' => 'nullable|string|max:500',
        ]);

        $conversation = Conversation::where('uuid', $uuid)->firstOrFail();

        $conversation->satisfactionRating()->updateOrCreate(
            ['customer_id' => $validated['customer_id']],
            ['rating' => $validated['rating'], 'comment' => $validated['comment'] ?? null]
        );

        return response()->json(['success' => true]);
    }
}
