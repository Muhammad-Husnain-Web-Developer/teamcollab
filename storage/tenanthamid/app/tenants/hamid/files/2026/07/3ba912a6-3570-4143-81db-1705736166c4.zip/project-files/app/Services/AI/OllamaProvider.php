<?php

namespace App\Services\AI;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class OllamaProvider implements AIProviderInterface
{
    private string $host;
    private string $model;
    private int $maxTokens;
    private float $temperature;

    public function __construct(array $config)
    {
        $this->host = rtrim($config['host'] ?? 'http://localhost:11434', '/');
        $this->model = $config['model'] ?? 'llama3';
        $this->maxTokens = $config['max_tokens'] ?? 2048;
        $this->temperature = $config['temperature'] ?? 0.7;
    }

    public function generateResponse(array $messages, ?string $systemPrompt = null, array $options = []): AIResponse
    {
        $prompt = $this->buildPrompt($messages, $systemPrompt);

        try {
            $response = Http::timeout(60)->post("{$this->host}/api/generate", [
                'model' => $options['model'] ?? $this->model,
                'prompt' => $prompt,
                'stream' => false,
                'options' => [
                    'temperature' => $options['temperature'] ?? $this->temperature,
                    'num_predict' => $options['max_tokens'] ?? $this->maxTokens,
                ],
            ]);

            if ($response->failed()) {
                Log::error('Ollama API error', ['status' => $response->status(), 'body' => $response->body()]);
                throw new \RuntimeException("Ollama API error: " . $response->body());
            }

            $data = $response->json();
            $content = $data['response'] ?? '';
            $shouldEscalate = str_contains($content, '[ESCALATE]');

            return new AIResponse(
                content: $content,
                provider: 'ollama',
                model: $this->model,
                promptTokens: $data['prompt_eval_count'] ?? 0,
                completionTokens: $data['eval_count'] ?? 0,
                confidenceScore: $shouldEscalate ? 0.3 : 0.8,
                shouldEscalate: $shouldEscalate,
                meta: ['done' => $data['done'] ?? true],
            );
        } catch (\Exception $e) {
            Log::error('Ollama provider error', ['error' => $e->getMessage()]);
            throw $e;
        }
    }

    public function complete(string $prompt, array $options = []): AIResponse
    {
        return $this->generateResponse([
            ['role' => 'user', 'content' => $prompt],
        ], null, $options);
    }

    public function isAvailable(): bool
    {
        try {
            $response = Http::timeout(5)->get("{$this->host}/api/tags");
            return $response->successful();
        } catch (\Exception) {
            return false;
        }
    }

    public function getName(): string
    {
        return 'ollama';
    }

    public function getModel(): string
    {
        return $this->model;
    }

    private function buildPrompt(array $messages, ?string $systemPrompt): string
    {
        $prompt = '';
        if ($systemPrompt) {
            $prompt .= "System: {$systemPrompt}\n\n";
        }
        foreach ($messages as $message) {
            $role = ucfirst($message['role']);
            $prompt .= "{$role}: {$message['content']}\n";
        }
        $prompt .= "Assistant: ";
        return $prompt;
    }
}
