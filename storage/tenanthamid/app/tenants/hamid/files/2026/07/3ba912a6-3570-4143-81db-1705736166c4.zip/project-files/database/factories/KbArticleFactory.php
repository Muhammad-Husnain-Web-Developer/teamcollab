<?php

namespace Database\Factories;

use App\Models\KbArticle;
use App\Models\KbCategory;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class KbArticleFactory extends Factory
{
    protected $model = KbArticle::class;

    public function definition(): array
    {
        $title = fake()->sentence(5);
        return [
            'category_id'  => KbCategory::factory(),
            'author_id'    => User::factory(),
            'title'        => $title,
            'slug'         => Str::slug($title),
            'excerpt'      => fake()->sentence(15),
            'content'      => '<p>' . implode('</p><p>', fake()->paragraphs(3)) . '</p>',
            'content_text' => implode(' ', fake()->paragraphs(3)),
            'status'       => fake()->randomElement(['published', 'published', 'draft']),
            'is_public'    => true,
            'views'        => fake()->numberBetween(0, 500),
            'helpful_count'     => fake()->numberBetween(0, 50),
            'not_helpful_count' => fake()->numberBetween(0, 10),
            'published_at' => now(),
        ];
    }

    public function published(): static
    {
        return $this->state(fn() => ['status' => 'published', 'published_at' => now()]);
    }

    public function draft(): static
    {
        return $this->state(fn() => ['status' => 'draft', 'published_at' => null]);
    }
}
