<?php

namespace Tests\Feature\KB;

use App\Models\KbArticle;
use App\Models\KbCategory;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class KnowledgeBaseTest extends TestCase
{
    use RefreshDatabase;

    protected User $manager;

    protected function setUp(): void
    {
        parent::setUp();
        $this->manager = User::factory()->create();
        $this->manager->assignRole('manager');
    }

    public function test_manager_can_list_articles(): void
    {
        $this->actingAs($this->manager)
            ->get(route('tenant.kb.index'))
            ->assertOk()
            ->assertInertia(fn ($p) => $p->component('KB/Index'));
    }

    public function test_manager_can_create_article(): void
    {
        $category = KbCategory::factory()->create();

        $this->actingAs($this->manager)
            ->postJson(route('tenant.kb.articles.store'), [
                'title'       => 'How to Reset Password',
                'content'     => '<p>Go to the login page and click Forgot Password.</p>',
                'category_id' => $category->id,
                'status'      => 'published',
                'is_public'   => true,
            ])
            ->assertStatus(201);

        $this->assertDatabaseHas('kb_articles', ['title' => 'How to Reset Password']);
    }

    public function test_article_slug_is_auto_generated(): void
    {
        $category = KbCategory::factory()->create();
        $article  = KbArticle::factory()->create([
            'title'       => 'Getting Started Guide',
            'category_id' => $category->id,
            'author_id'   => $this->manager->id,
        ]);

        $this->assertNotNull($article->slug);
        $this->assertStringContainsString('getting-started', $article->slug);
    }

    public function test_manager_can_search_articles(): void
    {
        KbArticle::factory()->create([
            'title'        => 'Password Reset Help',
            'content_text' => 'Instructions for resetting your password',
            'status'       => 'published',
            'is_public'    => true,
            'author_id'    => $this->manager->id,
        ]);

        $this->actingAs($this->manager)
            ->getJson(route('tenant.kb.search', ['query' => 'password']))
            ->assertOk()
            ->assertJsonStructure(['articles', 'faqs']);
    }

    public function test_manager_can_delete_article(): void
    {
        $article = KbArticle::factory()->create(['author_id' => $this->manager->id]);

        $this->actingAs($this->manager)
            ->deleteJson(route('tenant.kb.articles.destroy', $article->id))
            ->assertOk();

        $this->assertSoftDeleted('kb_articles', ['id' => $article->id]);
    }
}
