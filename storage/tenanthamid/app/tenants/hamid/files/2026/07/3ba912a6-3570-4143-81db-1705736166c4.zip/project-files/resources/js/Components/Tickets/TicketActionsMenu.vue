<template>
  <div class="relative" ref="menuRef">
    <button @click.stop="open=!open" class="btn-ghost btn-sm p-1.5">
      <MoreHorizontal class="w-4 h-4" />
    </button>
    <div v-if="open" class="absolute right-0 mt-1 w-44 bg-white dark:bg-gray-900 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 z-50 p-1">
      <button @click.stop="go('view')" class="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">
        <Eye class="w-3.5 h-3.5" /> View
      </button>
      <button @click.stop="go('resolve')" class="w-full flex items-center gap-2 px-3 py-2 text-sm text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg">
        <CheckCircle class="w-3.5 h-3.5" /> Resolve
      </button>
      <button @click.stop="go('delete')" class="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg">
        <Trash2 class="w-3.5 h-3.5" /> Delete
      </button>
    </div>
  </div>
</template>
<script setup lang="ts">
import { ref } from 'vue';
import { onClickOutside } from '@vueuse/core';
import { MoreHorizontal, Eye, CheckCircle, Trash2 } from 'lucide-vue-next';
import { router } from '@inertiajs/vue3';
import axios from 'axios';
const props = defineProps<{ ticket: any }>();
const emit = defineEmits<{ updated: [] }>();
const open = ref(false);
const menuRef = ref<HTMLElement|null>(null);
onClickOutside(menuRef, () => { open.value = false; });
async function go(type: string) {
  open.value = false;
  if (type === 'view') router.visit(route('tenant.tickets.show', props.ticket.id));
  else if (type === 'resolve') { await axios.put(route('tenant.tickets.update', props.ticket.id), { status:'resolved' }); emit('updated'); }
  else if (type === 'delete') { if (confirm('Delete this ticket?')) { await axios.delete(route('tenant.tickets.destroy', props.ticket.id)); emit('updated'); } }
}
</script>
