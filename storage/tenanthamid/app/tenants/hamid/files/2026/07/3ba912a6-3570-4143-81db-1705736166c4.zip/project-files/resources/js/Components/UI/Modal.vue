<template>
  <Teleport to="body">
    <Transition enter-active-class="ease-out duration-200" enter-from-class="opacity-0" enter-to-class="opacity-100"
                leave-active-class="ease-in duration-150" leave-from-class="opacity-100" leave-to-class="opacity-0">
      <div v-if="show" class="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="absolute inset-0 bg-black/50 backdrop-blur-sm" @click="$emit('close')" />
        <div class="relative bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full border border-gray-200 dark:border-gray-800 animate-slide-up"
             :class="maxWidthClass">
          <div v-if="title" class="flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-800">
            <h3 class="text-base font-semibold text-gray-900 dark:text-white">{{ title }}</h3>
            <button @click="$emit('close')" class="btn-ghost btn-sm p-1"><X class="w-4 h-4" /></button>
          </div>
          <div class="p-6"><slot /></div>
          <div v-if="$slots.footer" class="px-6 py-4 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-2">
            <slot name="footer" />
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>
<script setup lang="ts">
import { computed } from 'vue';
import { X } from 'lucide-vue-next';
const props = defineProps<{ show: boolean; title?: string; maxWidth?: 'sm'|'md'|'lg'|'xl'|'2xl' }>();
defineEmits<{ close: [] }>();
const maxWidthClass = computed(() => ({ sm:'max-w-sm', md:'max-w-md', lg:'max-w-lg', xl:'max-w-xl', '2xl':'max-w-2xl' }[props.maxWidth ?? 'md']));
</script>
