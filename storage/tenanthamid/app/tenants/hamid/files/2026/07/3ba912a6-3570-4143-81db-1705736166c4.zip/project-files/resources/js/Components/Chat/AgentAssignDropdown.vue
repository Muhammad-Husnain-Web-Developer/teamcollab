<template>
  <div class="relative" ref="dropdownRef">
    <button @click="open = !open" class="btn-secondary btn-sm flex items-center gap-2">
      <div v-if="assignedAgent" class="flex items-center gap-1.5">
        <img :src="assignedAgent.avatar_url ?? `https://ui-avatars.com/api/?name=${assignedAgent.name}&background=6366f1&color=fff&size=32`"
             class="w-5 h-5 rounded-full" />
        <span class="max-w-24 truncate">{{ assignedAgent.name }}</span>
      </div>
      <span v-else class="flex items-center gap-1.5"><UserPlus class="w-3.5 h-3.5" />Assign</span>
      <ChevronDown class="w-3 h-3 text-gray-400" />
    </button>

    <Transition enter-active-class="transition ease-out duration-100" enter-from-class="opacity-0 scale-95"
                enter-to-class="opacity-100 scale-100" leave-active-class="transition ease-in duration-75"
                leave-from-class="opacity-100 scale-100" leave-to-class="opacity-0 scale-95">
      <div v-if="open" class="absolute right-0 mt-1 w-56 bg-white dark:bg-gray-900 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 z-50 overflow-hidden">
        <div class="p-2">
          <button @click="assign(null)" class="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">
            <X class="w-4 h-4" /> Unassign
          </button>
          <div class="border-t border-gray-100 dark:border-gray-800 my-1" />
          <button v-for="agent in agents" :key="agent.id"
                  @click="assign(agent.id)"
                  class="w-full flex items-center gap-2.5 px-3 py-2 text-sm hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">
            <img :src="`https://ui-avatars.com/api/?name=${agent.name}&background=6366f1&color=fff&size=32`"
                 class="w-6 h-6 rounded-full" />
            <span class="flex-1 text-left text-gray-800 dark:text-gray-200 truncate">{{ agent.name }}</span>
            <span class="w-1.5 h-1.5 rounded-full flex-shrink-0" :class="agent.status === 'online' ? 'bg-emerald-500' : 'bg-gray-300'" />
          </button>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { onClickOutside } from '@vueuse/core';
import { UserPlus, ChevronDown, X } from 'lucide-vue-next';

const props = defineProps<{ agents: any[]; assignedTo: number | null }>();
const emit = defineEmits<{ assign: [id: number | null] }>();
const open = ref(false);
const dropdownRef = ref<HTMLElement | null>(null);
onClickOutside(dropdownRef, () => { open.value = false; });
const assignedAgent = computed(() => props.agents.find(a => a.id === props.assignedTo) ?? null);
function assign(id: number | null) { emit('assign', id); open.value = false; }
</script>
