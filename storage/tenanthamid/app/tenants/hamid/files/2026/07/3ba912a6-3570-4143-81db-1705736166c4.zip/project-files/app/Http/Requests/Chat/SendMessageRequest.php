<?php
namespace App\Http\Requests\Chat;
use Illuminate\Foundation\Http\FormRequest;

class SendMessageRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array
    {
        return [
            'content'     => 'required|string|max:5000',
            'is_internal' => 'boolean',
            'attachments' => 'nullable|array|max:5',
        ];
    }
}
