# AI Support SaaS — Production Deployment Guide (Ubuntu 24.04)

---

## Step 1 — Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y curl git unzip wget software-properties-common \
  apt-transport-https ca-certificates gnupg lsb-release

# Install PHP 8.3
sudo add-apt-repository ppa:ondrej/php -y
sudo apt update
sudo apt install -y php8.3 php8.3-fpm php8.3-cli php8.3-common \
  php8.3-mysql php8.3-mbstring php8.3-xml php8.3-curl php8.3-zip \
  php8.3-bcmath php8.3-intl php8.3-redis php8.3-gd php8.3-imagick \
  php8.3-pcov

# Verify PHP
php -v

# Install Composer
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
composer --version

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node -v && npm -v

# Install Nginx
sudo apt install -y nginx

# Install MySQL 8.0
sudo apt install -y mysql-server
sudo mysql_secure_installation

# Install Redis
sudo apt install -y redis-server
sudo systemctl enable redis-server

# Install Supervisor
sudo apt install -y supervisor
sudo systemctl enable supervisor
```

---

## Step 2 — MySQL Setup

```bash
# Login to MySQL
sudo mysql -u root -p

# Create database and user
CREATE DATABASE ai_support_central CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'ai_support'@'localhost' IDENTIFIED BY 'your_strong_password_here';
GRANT ALL PRIVILEGES ON ai_support_central.* TO 'ai_support'@'localhost';
GRANT ALL PRIVILEGES ON `tenant_%`.* TO 'ai_support'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

---

## Step 3 — Redis Configuration

```bash
sudo nano /etc/redis/redis.conf
```

Set these values:
```
maxmemory 512mb
maxmemory-policy allkeys-lru
requirepass your_redis_password
save 900 1
save 300 10
save 60 10000
```

```bash
sudo systemctl restart redis-server
sudo systemctl enable redis-server
```

---

## Step 4 — Deploy Application

```bash
# Create web directory
sudo mkdir -p /var/www/ai-support
sudo chown -R $USER:www-data /var/www/ai-support

# Clone repository
git clone https://github.com/your-org/ai-support-saas.git /var/www/ai-support
cd /var/www/ai-support

# Install dependencies
composer install --no-dev --optimize-autoloader --no-interaction
npm ci --prefer-offline

# Configure environment
cp .env.example .env
nano .env  # Fill in production values
```

### Production `.env` key settings:
```env
APP_ENV=production
APP_DEBUG=false
APP_URL=https://yourdomain.com

DB_HOST=127.0.0.1
DB_DATABASE=ai_support_central
DB_USERNAME=ai_support
DB_PASSWORD=your_strong_password_here

REDIS_PASSWORD=your_redis_password

SESSION_DRIVER=redis
CACHE_STORE=redis
QUEUE_CONNECTION=redis

REVERB_SCHEME=https
REVERB_HOST=yourdomain.com
REVERB_PORT=443
```

```bash
# Generate app key
php artisan key:generate

# Run migrations
php artisan migrate --path=database/migrations/central --force

# Seed database
php artisan db:seed --class=SuperAdminSeeder --force

# Build frontend
npm run build

# Storage link
php artisan storage:link

# Set permissions
sudo chown -R www-data:www-data /var/www/ai-support
sudo chmod -R 775 /var/www/ai-support/storage /var/www/ai-support/bootstrap/cache

# Optimize for production
php artisan optimize
php artisan event:cache
php artisan view:cache
php artisan route:cache
php artisan config:cache
php artisan icons:cache
```

---

## Step 5 — Nginx Configuration

```bash
# Copy nginx config
sudo cp /var/www/ai-support/nginx/ai-support.conf /etc/nginx/sites-available/ai-support

# Edit domain name
sudo nano /etc/nginx/sites-available/ai-support
# Replace 'yourdomain.com' with your actual domain

# Enable site
sudo ln -s /etc/nginx/sites-available/ai-support /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test nginx config
sudo nginx -t

# Reload nginx
sudo systemctl reload nginx
sudo systemctl enable nginx
```

---

## Step 6 — SSL Certificate (Let's Encrypt Wildcard)

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-dns-cloudflare
# Or for nginx plugin:
sudo apt install -y python3-certbot-nginx

# For wildcard cert (requires DNS challenge)
sudo certbot certonly --manual --preferred-challenges dns \
  -d yourdomain.com -d "*.yourdomain.com"

# Follow the prompts to add DNS TXT records

# Auto-renewal
sudo systemctl enable certbot.timer
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet && systemctl reload nginx
```

Update Nginx SSL paths in `/etc/nginx/sites-available/ai-support`:
```nginx
ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
```

```bash
sudo nginx -t && sudo systemctl reload nginx
```

---

## Step 7 — PHP-FPM Tuning

```bash
sudo nano /etc/php/8.3/fpm/pool.d/www.conf
```

```ini
pm = dynamic
pm.max_children = 50
pm.start_servers = 10
pm.min_spare_servers = 5
pm.max_spare_servers = 20
pm.max_requests = 500

request_terminate_timeout = 120s
```

```bash
sudo nano /etc/php/8.3/fpm/php.ini
```

```ini
memory_limit = 256M
upload_max_filesize = 20M
post_max_size = 20M
max_execution_time = 120
opcache.enable = 1
opcache.memory_consumption = 256
opcache.max_accelerated_files = 20000
opcache.validate_timestamps = 0
```

```bash
sudo systemctl restart php8.3-fpm
```

---

## Step 8 — Supervisor (Queue Workers + Reverb + Horizon)

```bash
# Copy supervisor config
sudo cp /var/www/ai-support/supervisor/ai-support.conf /etc/supervisor/conf.d/

# Create log directory
sudo mkdir -p /var/log/supervisor
sudo chown -R www-data:www-data /var/log/supervisor

# Reload supervisor
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start ai-support:*

# Check status
sudo supervisorctl status
```

Expected output:
```
ai-support:ai-support-worker_00    RUNNING   pid 1234
ai-support:ai-support-worker_01    RUNNING   pid 1235
ai-support:ai-support-worker_02    RUNNING   pid 1236
ai-support:ai-support-worker_03    RUNNING   pid 1237
ai-support:ai-support-ai-worker_00 RUNNING   pid 1238
ai-support:ai-support-ai-worker_01 RUNNING   pid 1239
ai-support:ai-support-ai-worker_02 RUNNING   pid 1240
ai-support:ai-support-horizon      RUNNING   pid 1241
ai-support:ai-support-reverb       RUNNING   pid 1242
```

---

## Step 9 — Task Scheduler

```bash
sudo crontab -u www-data -e
```

Add:
```
* * * * * cd /var/www/ai-support && php artisan schedule:run >> /dev/null 2>&1
```

---

## Step 10 — DNS Configuration

In your DNS provider (Cloudflare, Route53, etc.):

| Record | Name                | Value         | TTL  |
|--------|---------------------|---------------|------|
| A      | yourdomain.com      | YOUR_SERVER_IP| 300  |
| A      | *.yourdomain.com    | YOUR_SERVER_IP| 300  |
| CNAME  | www.yourdomain.com  | yourdomain.com| 3600 |

---

## Step 11 — Stripe Webhook Production

1. Go to https://dashboard.stripe.com/webhooks
2. Add endpoint: `https://yourdomain.com/stripe/webhook`
3. Select events:
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
4. Copy webhook signing secret to `.env`

---

## Step 12 — Firewall Setup

```bash
# Install and configure UFW
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw deny 8080/tcp  # Reverb internal only
sudo ufw enable
sudo ufw status
```

---

## Step 13 — Log Rotation

```bash
sudo nano /etc/logrotate.d/ai-support
```

```
/var/www/ai-support/storage/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    sharedscripts
    postrotate
        php /var/www/ai-support/artisan queue:restart
    endscript
}
```

---

## Step 14 — Create First Production Tenant

```bash
cd /var/www/ai-support
sudo -u www-data php artisan tinker
```

```php
use App\Models\Tenant;
use Illuminate\Support\Str;

$tenant = Tenant::create([
    'id'    => Str::uuid()->toString(),
    'name'  => 'My Company',
    'slug'  => 'mycompany',
    'email' => 'admin@mycompany.com',
    'plan'  => 'professional',
]);

$tenant->domains()->create(['domain' => 'mycompany.yourdomain.com']);

tenancy()->initialize($tenant);
Artisan::call('migrate', ['--path' => 'database/migrations/tenant', '--force' => true]);
Artisan::call('db:seed', ['--class' => 'TenantDatabaseSeeder', '--force' => true]);
tenancy()->end();

echo "Done! Visit: https://mycompany.yourdomain.com\n";
```

---

## Deployment Script (CI/CD)

Create `/var/www/ai-support/deploy.sh`:

```bash
#!/bin/bash
set -e

echo "🚀 Deploying AI Support Platform..."

cd /var/www/ai-support

# Pull latest code
git pull origin main

# Install/update dependencies
composer install --no-dev --optimize-autoloader --no-interaction
npm ci --prefer-offline

# Build assets
npm run build

# Put in maintenance mode
php artisan down --render="errors::503" --retry=60

# Run migrations
php artisan migrate --force

# Clear & rebuild caches
php artisan optimize:clear
php artisan optimize
php artisan event:cache
php artisan view:cache
php artisan route:cache
php artisan config:cache

# Restart queues
php artisan queue:restart
sudo supervisorctl restart ai-support:*

# Set permissions
sudo chown -R www-data:www-data storage bootstrap/cache

# Bring back online
php artisan up

echo "✅ Deployment complete!"
```

```bash
chmod +x /var/www/ai-support/deploy.sh
```

Usage:
```bash
sudo -u www-data /var/www/ai-support/deploy.sh
```

---

## Monitoring & Health Check

```bash
# Check all services
sudo systemctl status nginx php8.3-fpm redis-server mysql supervisor

# Check supervisor processes
sudo supervisorctl status

# Check queue health
php artisan queue:monitor redis:default,redis:ai

# View horizon dashboard
# Visit: https://yourdomain.com/horizon (admin only)

# Check logs
tail -f /var/www/ai-support/storage/logs/laravel.log
tail -f /var/log/nginx/ai-support-error.log
tail -f /var/log/supervisor/ai-support-horizon.log
```

---

## Backup Strategy

```bash
# Database backup script
sudo nano /usr/local/bin/backup-ai-support.sh
```

```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/var/backups/ai-support"
mkdir -p $BACKUP_DIR

# Backup central database
mysqldump -u ai_support -p'your_password' ai_support_central | gzip > $BACKUP_DIR/central_$DATE.sql.gz

# Backup tenant databases (list all tenant_ prefixed DBs)
mysql -u ai_support -p'your_password' -e "SHOW DATABASES LIKE 'tenant_%'" | grep -v Database | while read DB; do
  mysqldump -u ai_support -p'your_password' $DB | gzip > $BACKUP_DIR/${DB}_$DATE.sql.gz
done

# Backup storage
tar -czf $BACKUP_DIR/storage_$DATE.tar.gz /var/www/ai-support/storage/app

# Delete backups older than 14 days
find $BACKUP_DIR -type f -mtime +14 -delete

echo "Backup completed: $DATE"
```

```bash
sudo chmod +x /usr/local/bin/backup-ai-support.sh
# Add to crontab:
# 0 2 * * * /usr/local/bin/backup-ai-support.sh >> /var/log/backup-ai-support.log 2>&1
```
