<template>
  <AppLayout>
    <template #header>
      <div class="flex items-center gap-2 text-sm">
        <Link :href="route('tenant.customers.index')" class="text-gray-500 hover:text-gray-700">Customers</Link>
        <ChevronRight class="w-3.5 h-3.5 text-gray-400" />
        <span class="font-semibold text-gray-900 dark:text-white">{{ customer.name }}</span>
      </div>
    </template>
    <div class="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Profile -->
      <div class="space-y-4">
        <div class="card p-6 text-center">
          <img :src="customer.avatar_url" class="w-20 h-20 rounded-full mx-auto object-cover mb-3" />
          <h2 class="text-lg font-bold text-gray-900 dark:text-white">{{ customer.name }}</h2>
          <p class="text-sm text-gray-500">{{ customer.email }}</p>
          <p v-if="customer.company" class="text-sm text-gray-500 mt-1">{{ customer.company }}</p>
          <div class="mt-3 flex justify-center gap-2">
            <span :class="customer.status==='active'?'badge-green':'badge-red'" class="badge">{{ customer.status }}</span>
          </div>
          <div class="mt-4 flex gap-2 justify-center">
            <button @click="editMode=!editMode" class="btn-secondary btn-sm"><Edit class="w-3.5 h-3.5"/>Edit</button>
            <button @click="blockCustomer" :class="customer.status==='active'?'btn-danger btn-sm':'btn-secondary btn-sm'">
              {{ customer.status === 'active' ? 'Block' : 'Unblock' }}
            </button>
          </div>
        </div>

        <div class="card p-4 space-y-3">
          <h3 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Details</h3>
          <InfoRow label="Phone"    :value="customer.phone ?? '—'" />
          <InfoRow label="Location" :value="customer.location ?? '—'" />
          <InfoRow label="Language" :value="customer.language ?? '—'" />
          <InfoRow label="Source"   :value="customer.source ?? '—'" />
          <InfoRow label="Joined"   :value="formatDate(customer.created_at)" />
          <InfoRow label="Last Seen" :value="formatTime(customer.last_seen_at)" />
        </div>

        <!-- Tags -->
        <div class="card p-4">
          <h3 class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Tags</h3>
          <div class="flex flex-wrap gap-1">
            <span v-for="tag in (customer.tags??[])" :key="tag" class="badge badge-purple">{{ tag }}</span>
            <span v-if="!customer.tags?.length" class="text-xs text-gray-400">No tags</span>
          </div>
        </div>
      </div>

      <!-- Main content -->
      <div class="lg:col-span-2 space-y-4">
        <!-- Stats row -->
        <div class="grid grid-cols-3 gap-3">
          <div class="card p-4 text-center">
            <p class="text-2xl font-bold text-brand-600">{{ customer.total_conversations }}</p>
            <p class="text-xs text-gray-500 mt-1">Conversations</p>
          </div>
          <div class="card p-4 text-center">
            <p class="text-2xl font-bold text-amber-600">{{ customer.total_tickets }}</p>
            <p class="text-xs text-gray-500 mt-1">Tickets</p>
          </div>
          <div class="card p-4 text-center">
            <p class="text-2xl font-bold text-emerald-600">{{ customer.notes?.length ?? 0 }}</p>
            <p class="text-xs text-gray-500 mt-1">Notes</p>
          </div>
        </div>

        <!-- Tabs -->
        <div class="card">
          <div class="border-b border-gray-100 dark:border-gray-800">
            <div class="flex gap-0 px-4">
              <button v-for="tab in tabs" :key="tab.id" @click="activeTab = tab.id"
                      :class="['px-4 py-3 text-sm font-medium border-b-2 transition-colors',
                               activeTab === tab.id ? 'border-brand-600 text-brand-600 dark:text-brand-400' : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300']">
                {{ tab.label }}
              </button>
            </div>
          </div>
          <div class="p-4">
            <!-- Conversations tab -->
            <div v-if="activeTab === 'conversations'" class="space-y-2">
              <div v-for="conv in customer.conversations" :key="conv.id"
                   @click="router.visit(route('tenant.conversations.show', conv.id))"
                   class="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer border border-gray-100 dark:border-gray-800">
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-2">
                    <span class="text-sm font-medium text-gray-900 dark:text-white">{{ conv.subject ?? 'No subject' }}</span>
                    <span :class="conv.type==='ai'?'badge-purple':'badge-green'" class="badge text-xs">{{ conv.type }}</span>
                  </div>
                  <p class="text-xs text-gray-500 mt-0.5 truncate">{{ conv.last_message?.content ?? 'No messages' }}</p>
                </div>
                <span class="text-xs text-gray-400 flex-shrink-0">{{ formatTime(conv.created_at) }}</span>
              </div>
              <EmptyState v-if="!customer.conversations?.length" :icon="MessageSquare" title="No conversations" />
            </div>
            <!-- Tickets tab -->
            <div v-if="activeTab === 'tickets'" class="space-y-2">
              <div v-for="t in customer.tickets" :key="t.id"
                   @click="router.visit(route('tenant.tickets.show', t.id))"
                   class="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer border border-gray-100 dark:border-gray-800">
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-2">
                    <span class="font-mono text-xs text-brand-600">{{ t.ticket_number }}</span>
                    <span class="text-sm font-medium text-gray-900 dark:text-white truncate">{{ t.subject }}</span>
                  </div>
                </div>
                <TicketStatusBadge :status="t.status" />
              </div>
              <EmptyState v-if="!customer.tickets?.length" :icon="Ticket" title="No tickets" />
            </div>
            <!-- Notes tab -->
            <div v-if="activeTab === 'notes'" class="space-y-3">
              <form @submit.prevent="addNote" class="flex gap-2">
                <textarea v-model="noteContent" rows="2" class="input resize-none flex-1" placeholder="Add a note..." />
                <button type="submit" :disabled="!noteContent.trim()" class="btn-primary btn-sm self-end">Add</button>
              </form>
              <div v-for="note in customer.notes" :key="note.id"
                   class="p-3 rounded-lg bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800/50">
                <p class="text-sm text-gray-800 dark:text-gray-200">{{ note.content }}</p>
                <p class="text-xs text-gray-500 mt-1">{{ note.user?.name }} · {{ formatDateTime(note.created_at) }}</p>
              </div>
              <EmptyState v-if="!customer.notes?.length" :icon="FileText" title="No notes yet" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </AppLayout>
</template>
<script setup lang="ts">
import { ref } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import { ChevronRight, Edit, MessageSquare, Ticket, FileText } from 'lucide-vue-next';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import InfoRow from '@/Components/Shared/InfoRow.vue';
import TicketStatusBadge from '@/Components/Tickets/TicketStatusBadge.vue';
import EmptyState from '@/Components/UI/EmptyState.vue';
import { formatTime, formatDate, formatDateTime } from '@/Utils/format';
import { useToast } from '@/Composables/useToast';
const props = defineProps<{ customer: any; timeline: any[] }>();
const { toast } = useToast();
const activeTab = ref('conversations');
const editMode = ref(false);
const noteContent = ref('');
const tabs = [{ id:'conversations', label:'Conversations' }, { id:'tickets', label:'Tickets' }, { id:'notes', label:'Notes' }];
async function addNote() {
  await axios.post(route('tenant.customers.notes.store', props.customer.id), { content: noteContent.value });
  noteContent.value = ''; router.reload({ only: ['customer'] }); toast.success('Note added');
}
async function blockCustomer() {
  const status = props.customer.status === 'active' ? 'blocked' : 'active';
  await axios.put(route('tenant.customers.update', props.customer.id), { status });
  router.reload({ only: ['customer'] });
}
</script>
