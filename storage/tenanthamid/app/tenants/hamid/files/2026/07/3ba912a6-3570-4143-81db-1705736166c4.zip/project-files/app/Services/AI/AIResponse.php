<?php

namespace App\Services\AI;

class AIResponse
{
    public function __construct(
        public readonly string $content,
        public readonly string $provider,
        public readonly string $model,
        public readonly int $promptTokens = 0,
        public readonly int $completionTokens = 0,
        public readonly float $confidenceScore = 1.0,
        public readonly bool $shouldEscalate = false,
        public readonly array $meta = [],
    ) {}

    public function getTotalTokens(): int
    {
        return $this->promptTokens + $this->completionTokens;
    }

    public function needsHumanEscalation(): bool
    {
        return $this->shouldEscalate || str_contains($this->content, '[ESCALATE]');
    }

    public function getCleanContent(): string
    {
        return trim(str_replace('[ESCALATE]', '', $this->content));
    }

    public function toArray(): array
    {
        return [
            'content' => $this->content,
            'provider' => $this->provider,
            'model' => $this->model,
            'prompt_tokens' => $this->promptTokens,
            'completion_tokens' => $this->completionTokens,
            'confidence_score' => $this->confidenceScore,
            'should_escalate' => $this->shouldEscalate,
            'meta' => $this->meta,
        ];
    }
}
