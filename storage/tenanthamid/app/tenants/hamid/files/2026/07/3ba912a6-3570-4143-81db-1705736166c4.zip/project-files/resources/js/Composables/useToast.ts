import { ref } from 'vue';

interface Toast {
    id: number;
    message: string;
    type: 'success' | 'error' | 'info' | 'warning';
}

const toasts = ref<Toast[]>([]);
let nextId = 0;

function add(message: string, type: Toast['type'] = 'info', duration = 4000) {
    const id = ++nextId;
    toasts.value.push({ id, message, type });
    setTimeout(() => remove(id), duration);
}

function remove(id: number) {
    const idx = toasts.value.findIndex(t => t.id === id);
    if (idx !== -1) toasts.value.splice(idx, 1);
}

export function useToast() {
    return {
        toasts,
        remove,
        toast: {
            success: (msg: string) => add(msg, 'success'),
            error:   (msg: string) => add(msg, 'error', 6000),
            info:    (msg: string) => add(msg, 'info'),
            warning: (msg: string) => add(msg, 'warning'),
        },
    };
}
