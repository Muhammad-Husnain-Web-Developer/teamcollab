<template>
  <AppLayout>
    <template #header>
      <div class="flex items-center gap-2 text-sm">
        <Link :href="route('tenant.kb.index')" class="text-gray-500 hover:text-gray-700 dark:text-gray-400">Knowledge Base</Link>
        <ChevronRight class="w-3.5 h-3.5 text-gray-400" />
        <span class="font-semibold text-gray-900 dark:text-white">{{ article ? 'Edit Article' : 'New Article' }}</span>
      </div>
    </template>

    <div class="p-6 max-w-4xl mx-auto">
      <form @submit.prevent="save" class="space-y-5">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <!-- Main content -->
          <div class="lg:col-span-2 space-y-4">
            <div class="card card-body space-y-4">
              <div>
                <label class="label">Title *</label>
                <input v-model="form.title" class="input text-lg font-semibold" placeholder="Article title..." required />
              </div>
              <div>
                <label class="label">Excerpt</label>
                <textarea v-model="form.excerpt" rows="2" class="input resize-none" placeholder="Short description shown in search results..." />
              </div>
              <div>
                <label class="label">Content *</label>
                <!-- Rich text toolbar -->
                <div class="border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden">
                  <div class="flex items-center gap-1 px-3 py-2 bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex-wrap">
                    <button type="button" v-for="cmd in editorCommands" :key="cmd.cmd"
                            @click="execCmd(cmd.cmd, cmd.val)"
                            class="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400 transition-colors"
                            :title="cmd.label">
                      <component :is="cmd.icon" v-if="cmd.icon" class="w-4 h-4" />
                      <span v-else class="text-xs font-bold">{{ cmd.label }}</span>
                    </button>
                    <div class="w-px h-5 bg-gray-300 dark:bg-gray-600 mx-1" />
                    <button type="button" @click="insertLink" class="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400">
                      <Link2 class="w-4 h-4" />
                    </button>
                    <button type="button" @click="insertImage" class="p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400">
                      <ImageIcon class="w-4 h-4" />
                    </button>
                  </div>
                  <div ref="editorRef"
                       contenteditable
                       @input="onEditorInput"
                       class="min-h-64 p-4 text-sm text-gray-800 dark:text-gray-200 focus:outline-none prose prose-sm dark:prose-invert max-w-none"
                       v-html="editorContent"
                       @paste="handlePaste" />
                </div>
              </div>
            </div>
          </div>

          <!-- Sidebar -->
          <div class="space-y-4">
            <!-- Publish settings -->
            <div class="card card-body space-y-4">
              <h3 class="text-sm font-semibold text-gray-900 dark:text-white">Publish Settings</h3>
              <div>
                <label class="label">Status</label>
                <select v-model="form.status" class="input">
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="archived">Archived</option>
                </select>
              </div>
              <div>
                <label class="label">Category</label>
                <select v-model="form.category_id" class="input">
                  <option value="">No category</option>
                  <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
                </select>
              </div>
              <div class="flex items-center justify-between">
                <label class="text-sm text-gray-700 dark:text-gray-300">Public</label>
                <button type="button" @click="form.is_public = !form.is_public"
                        :class="['relative w-10 h-5 rounded-full transition-colors', form.is_public ? 'bg-brand-600' : 'bg-gray-300 dark:bg-gray-600']">
                  <span :class="['absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform', form.is_public ? 'translate-x-5' : 'translate-x-0.5']" />
                </button>
              </div>
            </div>

            <!-- Tags -->
            <div class="card card-body space-y-3">
              <h3 class="text-sm font-semibold text-gray-900 dark:text-white">Tags</h3>
              <div class="flex gap-2">
                <input v-model="tagInput" @keydown.enter.prevent="addTag" class="input text-sm flex-1" placeholder="Add tag..." />
                <button type="button" @click="addTag" class="btn-secondary btn-sm"><Plus class="w-4 h-4" /></button>
              </div>
              <div class="flex flex-wrap gap-1.5">
                <span v-for="(tag, i) in form.tags" :key="tag"
                      class="badge badge-purple flex items-center gap-1">
                  {{ tag }}
                  <button type="button" @click="removeTag(i)" class="hover:text-red-500 ml-0.5"><X class="w-3 h-3" /></button>
                </span>
              </div>
            </div>

            <!-- Actions -->
            <div class="space-y-2">
              <button type="submit" :disabled="saving" class="btn-primary w-full justify-center">
                <Spinner v-if="saving" size="sm" />
                <Save v-else class="w-4 h-4" />
                {{ article ? 'Update Article' : 'Create Article' }}
              </button>
              <Link :href="route('tenant.kb.index')" class="btn-ghost w-full justify-center text-sm">
                Cancel
              </Link>
            </div>
          </div>
        </div>
      </form>
    </div>
  </AppLayout>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, nextTick } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import {
  ChevronRight, Bold, Italic, Underline, List, ListOrdered,
  Link2, Image as ImageIcon, Plus, X, Save, AlignLeft, AlignCenter, Heading1, Heading2
} from 'lucide-vue-next';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import Spinner from '@/Components/UI/Spinner.vue';
import { useToast } from '@/Composables/useToast';

const props = defineProps<{ article?: any; categories: any[] }>();
const { toast } = useToast();
const saving = ref(false);
const tagInput = ref('');
const editorRef = ref<HTMLElement | null>(null);
const editorContent = ref(props.article?.content ?? '');

const form = reactive({
  title: props.article?.title ?? '',
  excerpt: props.article?.excerpt ?? '',
  content: props.article?.content ?? '',
  category_id: props.article?.category_id ?? '',
  status: props.article?.status ?? 'draft',
  is_public: props.article?.is_public ?? true,
  tags: props.article?.tags ?? [] as string[],
});

const editorCommands = [
  { cmd: 'bold',          label: 'B',  icon: Bold,         val: undefined },
  { cmd: 'italic',        label: 'I',  icon: Italic,       val: undefined },
  { cmd: 'underline',     label: 'U',  icon: Underline,    val: undefined },
  { cmd: 'formatBlock',   label: 'H1', icon: Heading1,     val: 'h2' },
  { cmd: 'formatBlock',   label: 'H2', icon: Heading2,     val: 'h3' },
  { cmd: 'insertUnorderedList', label: 'UL', icon: List,   val: undefined },
  { cmd: 'insertOrderedList',   label: 'OL', icon: ListOrdered, val: undefined },
];

function execCmd(cmd: string, val?: string) {
  document.execCommand(cmd, false, val);
  editorRef.value?.focus();
}

function onEditorInput() {
  form.content = editorRef.value?.innerHTML ?? '';
}

function handlePaste(e: ClipboardEvent) {
  e.preventDefault();
  const text = e.clipboardData?.getData('text/plain') ?? '';
  document.execCommand('insertText', false, text);
}

function insertLink() {
  const url = prompt('Enter URL:');
  if (url) execCmd('createLink', url);
}

function insertImage() {
  const url = prompt('Enter image URL:');
  if (url) execCmd('insertImage', url);
}

function addTag() {
  const tag = tagInput.value.trim().toLowerCase();
  if (tag && !form.tags.includes(tag)) {
    form.tags.push(tag);
  }
  tagInput.value = '';
}

function removeTag(i: number) {
  form.tags.splice(i, 1);
}

async function save() {
  saving.value = true;
  form.content = editorRef.value?.innerHTML ?? '';
  try {
    if (props.article) {
      await axios.put(route('tenant.kb.articles.update', props.article.id), form);
      toast.success('Article updated!');
    } else {
      await axios.post(route('tenant.kb.articles.store'), form);
      toast.success('Article created!');
      router.visit(route('tenant.kb.index'));
    }
  } catch {
    toast.error('Failed to save article');
  } finally {
    saving.value = false;
  }
}

onMounted(() => {
  if (editorRef.value && props.article?.content) {
    editorRef.value.innerHTML = props.article.content;
  }
});
</script>
