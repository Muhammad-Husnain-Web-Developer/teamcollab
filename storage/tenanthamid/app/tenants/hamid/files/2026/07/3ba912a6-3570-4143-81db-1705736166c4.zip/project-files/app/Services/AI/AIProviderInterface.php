<?php

namespace App\Services\AI;

interface AIProviderInterface
{
    /**
     * Generate a response from the AI provider.
     *
     * @param  array  $messages  Array of messages [{role: 'user'|'assistant', content: string}]
     * @param  string|null  $systemPrompt  System prompt for context
     * @param  array  $options  Additional provider-specific options
     */
    public function generateResponse(array $messages, ?string $systemPrompt = null, array $options = []): AIResponse;

    /**
     * Generate a simple single-turn completion.
     */
    public function complete(string $prompt, array $options = []): AIResponse;

    /**
     * Check if the provider is available and configured.
     */
    public function isAvailable(): bool;

    /**
     * Get the provider name.
     */
    public function getName(): string;

    /**
     * Get the current model being used.
     */
    public function getModel(): string;
}
