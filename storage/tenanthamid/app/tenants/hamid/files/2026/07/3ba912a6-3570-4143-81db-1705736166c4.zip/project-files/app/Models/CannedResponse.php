<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class CannedResponse extends Model {
    protected $fillable = ['user_id','name','shortcut','content','is_global','is_active'];
    protected $casts = ['is_global'=>'boolean','is_active'=>'boolean'];
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
