<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Inertia\Inertia;
use Inertia\Response;

class SubscriptionController extends Controller
{
    public function index(): Response
    {
        $tenant = tenant();
        $plans = config('plans.plans');

        return Inertia::render('Subscription/Index', [
            'tenant' => $tenant,
            'plans' => $plans,
            'current_plan' => $tenant->plan,
            'stripe_key' => config('cashier.key'),
            'is_on_trial' => $tenant->isOnTrial(),
            'trial_ends_at' => $tenant->trial_ends_at?->toDateString(),
        ]);
    }

    public function checkout(Request $request): JsonResponse
    {
        $request->validate(['plan' => 'required|in:free,starter,professional,enterprise', 'billing' => 'in:monthly,yearly']);

        $tenant = tenant();
        $plan = config('plans.plans.' . $request->plan);
        $priceId = $request->billing === 'yearly'
            ? $plan['stripe_yearly_price_id']
            : $plan['stripe_monthly_price_id'];

        if ($request->plan === 'free') {
            $tenant->update(['plan' => 'free', 'stripe_status' => null]);
            return response()->json(['success' => true, 'redirect' => route('tenant.subscription.index')]);
        }

        $checkout = $tenant->newSubscription('default', $priceId)
            ->trialDays($plan['trial_days'])
            ->checkout([
                'success_url' => route('tenant.subscription.success') . '?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => route('tenant.subscription.index'),
            ]);

        return response()->json(['checkout_url' => $checkout->url]);
    }

    public function success(Request $request): RedirectResponse
    {
        $tenant = tenant();
        $tenant->update(['plan' => $request->plan ?? $tenant->plan]);

        return redirect()->route('tenant.subscription.index')
            ->with('success', 'Subscription activated successfully!');
    }

    public function cancel(): JsonResponse
    {
        $tenant = tenant();
        if ($tenant->subscribed('default')) {
            $tenant->subscription('default')->cancel();
        }
        return response()->json(['success' => true]);
    }

    public function resume(): JsonResponse
    {
        $tenant = tenant();
        if ($tenant->subscription('default')?->onGracePeriod()) {
            $tenant->subscription('default')->resume();
        }
        return response()->json(['success' => true]);
    }

    public function portal(): JsonResponse
    {
        $tenant = tenant();
        $url = $tenant->billingPortalUrl(route('tenant.subscription.index'));
        return response()->json(['url' => $url]);
    }

    public function webhook(Request $request): \Illuminate\Http\Response
    {
        return app(\Laravel\Cashier\Http\Controllers\WebhookController::class)->handleWebhook($request);
    }
}
