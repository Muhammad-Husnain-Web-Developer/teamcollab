<template>
  <div class="relative" ref="dropdownRef">
    <button @click="open=!open" class="btn-ghost btn-sm relative">
      <Bell class="w-4 h-4" />
      <span v-if="unread > 0" class="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 rounded-full text-white text-[10px] font-bold flex items-center justify-center">
        {{ unread > 9 ? '9+' : unread }}
      </span>
    </button>
    <Transition enter-active-class="transition ease-out duration-100" enter-from-class="opacity-0 scale-95" enter-to-class="opacity-100 scale-100"
                leave-active-class="transition ease-in duration-75" leave-from-class="opacity-100 scale-100" leave-to-class="opacity-0 scale-95">
      <div v-if="open" class="absolute right-0 mt-1 w-80 bg-white dark:bg-gray-900 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 z-50">
        <div class="flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800">
          <h4 class="text-sm font-semibold text-gray-900 dark:text-white">Notifications</h4>
          <button v-if="unread" @click="markAllRead" class="text-xs text-brand-600 dark:text-brand-400 hover:underline">Mark all read</button>
        </div>
        <div class="max-h-80 overflow-y-auto divide-y divide-gray-100 dark:divide-gray-800">
          <div v-for="n in notifications" :key="n.id"
               :class="['px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer', !n.read_at ? 'bg-brand-50/50 dark:bg-brand-900/10' : '']">
            <p class="text-xs text-gray-800 dark:text-gray-200">{{ n.data?.message ?? 'New notification' }}</p>
            <p class="text-xs text-gray-400 mt-0.5">{{ formatTime(n.created_at) }}</p>
          </div>
          <div v-if="!notifications.length" class="px-4 py-8 text-center text-sm text-gray-400">No notifications</div>
        </div>
      </div>
    </Transition>
  </div>
</template>
<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { Bell } from 'lucide-vue-next';
import { onClickOutside } from '@vueuse/core';
import axios from 'axios';
import { formatTime } from '@/Utils/format';
const open = ref(false);
const notifications = ref<any[]>([]);
const dropdownRef = ref<HTMLElement|null>(null);
onClickOutside(dropdownRef, () => { open.value = false; });
const unread = computed(() => notifications.value.filter(n => !n.read_at).length);
onMounted(async () => {
  try { const { data } = await axios.get('/api/notifications'); notifications.value = data.notifications ?? []; } catch {}
});
async function markAllRead() {
  try { await axios.post('/api/notifications/read-all'); notifications.value = notifications.value.map(n => ({...n, read_at: new Date().toISOString()})); } catch {}
}
</script>
