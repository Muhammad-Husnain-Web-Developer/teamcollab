<template>
  <button @click="$emit('click')"
          :class="['flex-shrink-0 text-xs px-3 py-1 rounded-full border transition-colors',
                   active ? 'bg-brand-600 text-white border-brand-600' : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-brand-400']">
    {{ label }}
  </button>
</template>
<script setup lang="ts">
defineProps<{ label: string; active?: boolean }>();
defineEmits<{ click: [] }>();
</script>
