<?php

namespace App\Console\Commands;

use App\Models\Conversation;
use App\Models\Message;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CleanupCommand extends Command
{
    protected $signature   = 'app:cleanup {--days=30 : Days to keep resolved conversations}';
    protected $description = 'Clean up old resolved conversations and soft-deleted records';

    public function handle(): int
    {
        $days = (int) $this->option('days');
        $this->info("Cleaning data older than {$days} days...");

        // Force delete soft-deleted messages
        $msgs = Message::onlyTrashed()->where('deleted_at', '<', now()->subDays($days))->forceDelete();
        $this->line("  ✓ Permanently deleted {$msgs} old messages");

        // Force delete soft-deleted conversations
        $convs = Conversation::onlyTrashed()->where('deleted_at', '<', now()->subDays($days))->forceDelete();
        $this->line("  ✓ Permanently deleted {$convs} old conversations");

        // Clean old typing indicators
        DB::table('typing_indicators')->where('expires_at', '<', now())->delete();
        $this->line("  ✓ Cleared expired typing indicators");

        // Clean old audit logs (keep 90 days)
        DB::table('audit_logs')->where('created_at', '<', now()->subDays(90))->delete();
        $this->line("  ✓ Pruned old audit logs");

        $this->info('✅ Cleanup complete!');
        return self::SUCCESS;
    }
}
