<template>
  <span :class="['badge', colors[status] ?? 'badge-gray']">{{ status }}</span>
</template>
<script setup lang="ts">
defineProps<{ status: string }>();
const colors: Record<string, string> = {
  published: 'badge-green',
  draft: 'badge-yellow',
  archived: 'badge-gray',
};
</script>
