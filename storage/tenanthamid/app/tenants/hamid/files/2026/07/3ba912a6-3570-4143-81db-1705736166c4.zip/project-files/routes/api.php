<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth:sanctum'])->group(function () {
    Route::get('/user', fn(Request $request) => $request->user());

    // Notifications
    Route::get('/notifications', function (Request $request) {
        $notifications = $request->user()
            ->notifications()
            ->latest()
            ->limit(20)
            ->get();
        return response()->json(['notifications' => $notifications]);
    });

    Route::post('/notifications/read-all', function (Request $request) {
        $request->user()->unreadNotifications->markAsRead();
        return response()->json(['success' => true]);
    });

    Route::delete('/notifications/{id}', function (Request $request, string $id) {
        $request->user()->notifications()->find($id)?->delete();
        return response()->json(['success' => true]);
    });

    // Global search
    Route::get('/search', function (Request $request) {
        $q = $request->get('q', '');
        if (strlen($q) < 2) {
            return response()->json(['results' => []]);
        }

        $results = [];

        // Search conversations
        $conversations = \App\Models\Conversation::with('customer')
            ->whereHas('customer', fn($q2) => $q2->where('name', 'LIKE', "%{$q}%")->orWhere('email', 'LIKE', "%{$q}%"))
            ->limit(5)->get();

        foreach ($conversations as $c) {
            $results[] = [
                'title'    => $c->customer->name,
                'subtitle' => 'Conversation · ' . $c->status,
                'url'      => route('tenant.conversations.show', $c->id),
                'icon'     => 'MessageSquare',
            ];
        }

        // Search tickets
        $tickets = \App\Models\Ticket::with('customer')
            ->where('subject', 'LIKE', "%{$q}%")
            ->orWhere('ticket_number', 'LIKE', "%{$q}%")
            ->limit(5)->get();

        foreach ($tickets as $t) {
            $results[] = [
                'title'    => $t->subject,
                'subtitle' => $t->ticket_number . ' · ' . $t->status,
                'url'      => route('tenant.tickets.show', $t->id),
                'icon'     => 'Ticket',
            ];
        }

        // Search customers
        $customers = \App\Models\Customer::where('name', 'LIKE', "%{$q}%")
            ->orWhere('email', 'LIKE', "%{$q}%")
            ->limit(5)->get();

        foreach ($customers as $c) {
            $results[] = [
                'title'    => $c->name,
                'subtitle' => $c->email,
                'url'      => route('tenant.customers.show', $c->id),
                'icon'     => 'Users',
            ];
        }

        return response()->json(['results' => $results]);
    });

    // Customer search (for ticket/chat forms)
    Route::get('/customers/search', function (Request $request) {
        $q = $request->get('q', '');
        $customers = \App\Models\Customer::where('name', 'LIKE', "%{$q}%")
            ->orWhere('email', 'LIKE', "%{$q}%")
            ->limit(10)
            ->get(['id', 'name', 'email', 'company']);
        return response()->json(['customers' => $customers]);
    });
});
