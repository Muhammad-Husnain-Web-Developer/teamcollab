<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class TicketCategory extends Model {
    protected $fillable = ['name','color','icon','description','is_active'];
    protected $casts = ['is_active'=>'boolean'];
    public function tickets(): HasMany { return $this->hasMany(Ticket::class,'category_id'); }
}
