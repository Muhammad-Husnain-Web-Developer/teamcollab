<template>
  <div :class="['card p-4 flex items-center gap-3', 'border-l-4', borderColors[color]]">
    <div class="flex-1">
      <p class="text-xs text-gray-500 dark:text-gray-400">{{ label }}</p>
      <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ value }}</p>
    </div>
  </div>
</template>
<script setup lang="ts">
defineProps<{ label: string; value: number; color?: string }>();
const borderColors: Record<string,string> = { blue:'border-blue-500', yellow:'border-yellow-500', orange:'border-orange-500', green:'border-emerald-500', red:'border-red-500', default:'border-gray-300' };
</script>
