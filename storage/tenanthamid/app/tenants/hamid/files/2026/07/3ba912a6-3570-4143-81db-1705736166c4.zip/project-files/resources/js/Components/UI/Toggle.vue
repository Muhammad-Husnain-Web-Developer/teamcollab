<template>
  <button type="button" @click="toggle"
          :class="['relative w-10 h-5 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-brand-500 focus:ring-offset-2',
                   modelValue ? 'bg-brand-600' : 'bg-gray-300 dark:bg-gray-600']">
    <span :class="['absolute top-0.5 w-4 h-4 rounded-full bg-white shadow-sm transition-transform',
                   modelValue ? 'translate-x-5' : 'translate-x-0.5']" />
  </button>
</template>
<script setup lang="ts">
const props = defineProps<{ modelValue: boolean }>();
const emit = defineEmits<{ 'update:modelValue': [val: boolean] }>();
function toggle() { emit('update:modelValue', !props.modelValue); }
</script>
