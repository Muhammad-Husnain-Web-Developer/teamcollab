<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class KbArticleFeedback extends Model {
    protected $table = 'kb_article_feedback';
    protected $fillable = ['article_id','customer_id','is_helpful','feedback','ip_address'];
    protected $casts = ['is_helpful'=>'boolean'];
    public function article(): BelongsTo { return $this->belongsTo(KbArticle::class,'article_id'); }
    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
}
