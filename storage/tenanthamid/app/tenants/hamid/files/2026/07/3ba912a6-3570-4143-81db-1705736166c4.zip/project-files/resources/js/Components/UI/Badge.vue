<template>
  <span :class="['badge', variantClass]"><slot /></span>
</template>
<script setup lang="ts">
import { computed } from 'vue';
const props = defineProps<{ variant?: 'blue'|'green'|'yellow'|'red'|'purple'|'gray'|'orange' }>();
const variantClass = computed(() => `badge-${props.variant ?? 'gray'}`);
</script>
