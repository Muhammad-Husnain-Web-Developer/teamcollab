<template>
  <AppLayout>
    <template #header><h1 class="text-sm font-semibold text-gray-900 dark:text-white">Team</h1></template>
    <div class="p-6 space-y-5">
      <div class="grid grid-cols-4 gap-4">
        <StatCard title="Total Members" :value="stats.total"   :icon="Users"      color="indigo"/>
        <StatCard title="Online"        :value="stats.online"  :icon="Wifi"       color="emerald"/>
        <StatCard title="Agents"        :value="stats.agents"  :icon="Headphones" color="blue"/>
        <StatCard title="Managers"      :value="stats.managers":icon="Shield"     color="violet"/>
      </div>
      <div class="card card-body py-3 flex justify-between items-center">
        <h2 class="text-sm font-semibold text-gray-900 dark:text-white">Team Members</h2>
        <button @click="showCreate=true" class="btn-primary btn-sm"><Plus class="w-4 h-4"/>Invite Member</button>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <div v-for="m in members.data" :key="m.id" class="card p-5 hover:shadow-md transition-shadow">
          <div class="flex items-start gap-4">
            <div class="relative">
              <img :src="`https://ui-avatars.com/api/?name=${m.name}&background=6366f1&color=fff&size=48`" class="w-12 h-12 rounded-xl object-cover"/>
              <span class="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white dark:border-gray-900"
                    :class="m.status==='online'?'bg-emerald-500':m.status==='busy'?'bg-amber-500':'bg-gray-300'"/>
            </div>
            <div class="flex-1 min-w-0">
              <p class="font-semibold text-gray-900 dark:text-white truncate">{{ m.name }}</p>
              <p class="text-xs text-gray-500 truncate">{{ m.email }}</p>
              <div class="flex gap-1.5 mt-1.5">
                <span v-for="role in m.roles" :key="role.name" class="badge badge-purple text-xs">{{ role.name }}</span>
              </div>
            </div>
          </div>
          <div class="mt-4 grid grid-cols-2 gap-2 text-center border-t border-gray-100 dark:border-gray-800 pt-3">
            <div><p class="text-lg font-bold text-brand-600">{{ m.open_tickets }}</p><p class="text-xs text-gray-500">Open Tickets</p></div>
            <div><p class="text-lg font-bold text-emerald-600">{{ m.active_conversations }}</p><p class="text-xs text-gray-500">Conversations</p></div>
          </div>
          <div class="mt-3 flex gap-2">
            <Link :href="route('tenant.team.show', m.id)" class="btn-secondary btn-sm flex-1 justify-center">View</Link>
            <button @click="toggleActive(m)" :class="m.is_active?'btn-ghost btn-sm':'btn-secondary btn-sm'">
              {{ m.is_active ? 'Deactivate' : 'Activate' }}
            </button>
          </div>
        </div>
      </div>
      <Pagination :links="members.links" :meta="members"/>
    </div>

    <Modal :show="showCreate" title="Invite Team Member" @close="showCreate=false">
      <form @submit.prevent="inviteMember" class="space-y-4">
        <div class="grid grid-cols-2 gap-3">
          <div><label class="label">Name *</label><input v-model="form.name" class="input" required /></div>
          <div><label class="label">Email *</label><input v-model="form.email" type="email" class="input" required /></div>
          <div><label class="label">Password *</label><input v-model="form.password" type="password" class="input" required /></div>
          <div><label class="label">Confirm Password *</label><input v-model="form.password_confirmation" type="password" class="input" required /></div>
        </div>
        <div><label class="label">Role</label>
          <select v-model="form.role" class="input"><option value="agent">Agent</option><option value="manager">Manager</option></select>
        </div>
        <div class="flex justify-end gap-2">
          <button type="button" @click="showCreate=false" class="btn-secondary btn-sm">Cancel</button>
          <button type="submit" class="btn-primary btn-sm">Invite</button>
        </div>
      </form>
    </Modal>
  </AppLayout>
</template>
<script setup lang="ts">
import { ref, reactive } from 'vue'; import { Link, router } from '@inertiajs/vue3';
import { Users, Wifi, Headphones, Shield, Plus } from 'lucide-vue-next';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue'; import StatCard from '@/Components/Dashboard/StatCard.vue';
import Modal from '@/Components/UI/Modal.vue'; import Pagination from '@/Components/Shared/Pagination.vue';
import { useToast } from '@/Composables/useToast';
const props = defineProps<{ members: any; roles: any[]; stats: any }>();
const { toast } = useToast();
const showCreate = ref(false);
const form = reactive({ name:'', email:'', password:'', password_confirmation:'', role:'agent' });
async function inviteMember() {
  try { await axios.post(route('tenant.team.store'), form); showCreate.value=false; router.reload(); toast.success('Member invited!'); }
  catch (e: any) { toast.error(e.response?.data?.message ?? 'Failed to invite'); }
}
async function toggleActive(m: any) {
  await axios.put(route('tenant.team.update', m.id), { is_active: !m.is_active });
  router.reload(); toast.success('Updated');
}
</script>
