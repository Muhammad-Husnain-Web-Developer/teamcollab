<template>
  <div class="min-h-screen bg-white dark:bg-gray-950">
    <!-- Nav -->
    <nav class="border-b border-gray-100 dark:border-gray-800 px-6 py-4 flex items-center justify-between max-w-6xl mx-auto">
      <div class="flex items-center gap-2">
        <div class="w-8 h-8 bg-gradient-to-br from-brand-500 to-violet-600 rounded-lg flex items-center justify-center">
          <Zap class="w-4 h-4 text-white"/>
        </div>
        <span class="font-bold text-gray-900 dark:text-white">AI Support</span>
      </div>
      <div class="flex items-center gap-3">
        <Link :href="route('login')" class="btn-ghost btn-sm">Sign in</Link>
        <Link :href="route('register')" class="btn-primary btn-sm">Get Started Free</Link>
      </div>
    </nav>

    <!-- Hero -->
    <div class="max-w-4xl mx-auto px-6 pt-20 pb-16 text-center">
      <div class="inline-flex items-center gap-2 bg-brand-50 dark:bg-brand-900/20 text-brand-700 dark:text-brand-400 text-xs font-semibold px-3 py-1.5 rounded-full border border-brand-200 dark:border-brand-800 mb-6">
        <Sparkles class="w-3.5 h-3.5"/> Powered by Gemini, GPT-4o & Claude
      </div>
      <h1 class="text-5xl font-extrabold text-gray-900 dark:text-white leading-tight mb-6">
        AI Customer Support<br/>
        <span class="bg-gradient-to-r from-brand-600 to-violet-600 bg-clip-text text-transparent">That Actually Works</span>
      </h1>
      <p class="text-xl text-gray-500 dark:text-gray-400 max-w-2xl mx-auto mb-10">
        Enterprise-grade AI support platform. Live chat, ticketing, knowledge base — all powered by AI that resolves 80% of queries automatically.
      </p>
      <div class="flex items-center justify-center gap-4">
        <Link :href="route('register')" class="btn-primary btn-lg px-8">
          Start Free Trial <ArrowRight class="w-5 h-5"/>
        </Link>
        <Link :href="route('login')" class="btn-secondary btn-lg px-8">
          View Demo
        </Link>
      </div>
      <p class="text-sm text-gray-400 mt-4">No credit card required · 14-day free trial</p>
    </div>

    <!-- Features -->
    <div class="max-w-6xl mx-auto px-6 py-16">
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div v-for="f in features" :key="f.title" class="card p-6 hover:shadow-lg transition-shadow">
          <div :class="['w-12 h-12 rounded-xl flex items-center justify-center mb-4', f.bg]">
            <component :is="f.icon" :class="['w-6 h-6', f.color]"/>
          </div>
          <h3 class="text-base font-bold text-gray-900 dark:text-white mb-2">{{ f.title }}</h3>
          <p class="text-sm text-gray-500">{{ f.desc }}</p>
        </div>
      </div>
    </div>

    <!-- CTA -->
    <div class="max-w-3xl mx-auto px-6 py-16 text-center">
      <div class="card p-10 bg-gradient-to-br from-brand-600 to-violet-600 border-0">
        <h2 class="text-3xl font-bold text-white mb-4">Ready to transform your support?</h2>
        <p class="text-brand-100 mb-8">Join businesses using AI to deliver better support, faster.</p>
        <Link :href="route('register')" class="bg-white text-brand-700 hover:bg-brand-50 btn btn-lg px-10 font-semibold">
          Start Free Trial
        </Link>
      </div>
    </div>

    <!-- Footer -->
    <footer class="border-t border-gray-100 dark:border-gray-800 py-8 text-center text-sm text-gray-400">
      © {{ new Date().getFullYear() }} AI Support Platform. Built with Laravel & Vue.
    </footer>
  </div>
</template>
<script setup lang="ts">
import { Link } from '@inertiajs/vue3';
import { Zap, Sparkles, ArrowRight, MessageSquare, Bot, BarChart3, Shield, Globe, Ticket } from 'lucide-vue-next';
const features = [
  { title:'AI-Powered Chat',     desc:'Gemini, GPT-4o, or Claude resolves 80% of queries automatically with context-aware responses.',              icon:Bot,          bg:'bg-violet-100 dark:bg-violet-900/30', color:'text-violet-600 dark:text-violet-400' },
  { title:'Live Chat & Tickets', desc:'Real-time messaging with typing indicators, file sharing, and full ticketing system with SLA tracking.', icon:MessageSquare, bg:'bg-blue-100 dark:bg-blue-900/30',   color:'text-blue-600 dark:text-blue-400'   },
  { title:'Multi-Tenant SaaS',   desc:'Each customer gets their own isolated workspace with custom branding, domain, and database.',              icon:Globe,        bg:'bg-emerald-100 dark:bg-emerald-900/30',color:'text-emerald-600 dark:text-emerald-400'},
  { title:'Knowledge Base',      desc:'Create articles and FAQs. AI searches them automatically to generate accurate, grounded responses.',       icon:Ticket,       bg:'bg-amber-100 dark:bg-amber-900/30',  color:'text-amber-600 dark:text-amber-400'  },
  { title:'Analytics Dashboard', desc:'Track resolution rates, response times, agent performance, and customer satisfaction in real-time.',      icon:BarChart3,    bg:'bg-pink-100 dark:bg-pink-900/30',    color:'text-pink-600 dark:text-pink-400'    },
  { title:'Enterprise Security', desc:'Role-based access, audit logs, rate limiting, CSRF protection, and tenant data isolation.',              icon:Shield,       bg:'bg-indigo-100 dark:bg-indigo-900/30', color:'text-indigo-600 dark:text-indigo-400'},
];
</script>
