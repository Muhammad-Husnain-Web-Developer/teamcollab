<template>
  <div class="min-h-screen bg-gradient-to-br from-brand-50 via-white to-violet-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 flex items-center justify-center p-4">
    <div class="w-full max-w-md">
      <!-- Logo -->
      <div class="text-center mb-8">
        <div class="w-12 h-12 bg-gradient-to-br from-brand-500 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-brand-200 dark:shadow-brand-900/30">
          <Zap class="w-6 h-6 text-white" />
        </div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Welcome back</h1>
        <p class="text-sm text-gray-500 mt-1">Sign in to your support dashboard</p>
      </div>

      <!-- Card -->
      <div class="card card-body shadow-xl shadow-gray-100 dark:shadow-gray-900/50">
        <!-- Status message -->
        <div v-if="status" class="mb-4 p-3 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 text-sm rounded-lg">
          {{ status }}
        </div>

        <form @submit.prevent="submit" class="space-y-4">
          <div>
            <label class="label">Email</label>
            <input v-model="form.email" type="email" class="input" placeholder="you@company.com" required autocomplete="email" />
            <p v-if="form.errors.email" class="text-xs text-red-500 mt-1">{{ form.errors.email }}</p>
          </div>
          <div>
            <div class="flex items-center justify-between mb-1">
              <label class="label mb-0">Password</label>
              <Link :href="route('password.request')" class="text-xs text-brand-600 hover:underline">Forgot password?</Link>
            </div>
            <input v-model="form.password" type="password" class="input" placeholder="••••••••" required autocomplete="current-password" />
            <p v-if="form.errors.password" class="text-xs text-red-500 mt-1">{{ form.errors.password }}</p>
          </div>
          <div class="flex items-center gap-2">
            <input v-model="form.remember" type="checkbox" id="remember" class="w-4 h-4 rounded border-gray-300 text-brand-600 focus:ring-brand-500" />
            <label for="remember" class="text-sm text-gray-600 dark:text-gray-400">Remember me for 30 days</label>
          </div>
          <button type="submit" :disabled="form.processing" class="btn-primary w-full justify-center py-2.5">
            <Spinner v-if="form.processing" size="sm" />
            <LogIn v-else class="w-4 h-4" />
            Sign in
          </button>
        </form>

        <div class="mt-5 text-center">
          <p class="text-sm text-gray-500">
            Don't have an account?
            <Link :href="route('register')" class="text-brand-600 dark:text-brand-400 font-medium hover:underline">Create workspace</Link>
          </p>
        </div>
      </div>

      <!-- Demo credentials hint -->
      <div class="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-xl text-xs text-amber-800 dark:text-amber-300 text-center border border-amber-200 dark:border-amber-800">
        <strong>Demo:</strong> owner@example.com / password
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Link, useForm } from '@inertiajs/vue3';
import { Zap, LogIn } from 'lucide-vue-next';
import Spinner from '@/Components/UI/Spinner.vue';

defineProps<{ canResetPassword?: boolean; status?: string }>();

const form = useForm({ email: '', password: '', remember: false });

function submit() {
  form.post(route('login'), {
    onFinish: () => form.reset('password'),
  });
}
</script>
