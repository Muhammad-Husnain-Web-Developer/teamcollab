<template>
    <AppLayout>
        <template #header>
            <div class="flex items-center gap-2 text-sm">
                <Link :href="route('tenant.conversations.index')" class="text-gray-500 hover:text-gray-700 dark:text-gray-400">
                    Conversations
                </Link>
                <ChevronRight class="w-3.5 h-3.5 text-gray-400" />
                <span class="font-semibold text-gray-900 dark:text-white">{{ conversation.customer?.name }}</span>
                <ConvTypeBadge :type="conversation.type" />
                <ConvStatusBadge :status="conversation.status" />
            </div>
        </template>

        <div class="flex h-[calc(100vh-64px)]">
            <!-- Messages area -->
            <div class="flex-1 flex flex-col">
                <!-- Conversation toolbar -->
                <div class="px-4 py-2.5 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 flex items-center gap-2">
                    <PriorityBadge :priority="conversation.priority" />

                    <div class="ml-auto flex items-center gap-2">
                        <!-- Assign -->
                        <AgentAssignDropdown
                            :agents="agents"
                            :assigned-to="conversation.assigned_to"
                            @assign="assignConversation"
                        />

                        <button @click="summarizeConversation" class="btn-secondary btn-sm" :disabled="summarizing">
                            <Sparkles class="w-3.5 h-3.5" />
                            Summarize
                        </button>

                        <button v-if="conversation.status !== 'resolved'" @click="resolveConversation"
                                class="btn-primary btn-sm">
                            <CheckCircle class="w-3.5 h-3.5" />
                            Resolve
                        </button>

                        <button v-else class="btn-secondary btn-sm opacity-60" disabled>
                            <CheckCircle class="w-3.5 h-3.5" />
                            Resolved
                        </button>
                    </div>
                </div>

                <!-- Messages -->
                <div ref="messagesContainer" class="flex-1 overflow-y-auto p-6 space-y-4">
                    <ChatMessage
                        v-for="msg in allMessages"
                        :key="msg.id"
                        :message="msg"
                        @react="(emoji) => addReaction(msg.id, emoji)"
                    />

                    <!-- Typing indicator -->
                    <div v-if="isTyping" class="flex items-end gap-2">
                        <div class="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center">
                            <Zap class="w-3.5 h-3.5 text-white" />
                        </div>
                        <div class="bg-gray-100 dark:bg-gray-800 rounded-2xl rounded-bl-sm px-4 py-2.5">
                            <div class="flex gap-1">
                                <span class="w-1.5 h-1.5 rounded-full bg-gray-400 animate-bounce" style="animation-delay:0ms" />
                                <span class="w-1.5 h-1.5 rounded-full bg-gray-400 animate-bounce" style="animation-delay:150ms" />
                                <span class="w-1.5 h-1.5 rounded-full bg-gray-400 animate-bounce" style="animation-delay:300ms" />
                            </div>
                        </div>
                    </div>

                    <!-- AI summary -->
                    <div v-if="summary" class="mx-auto max-w-lg bg-indigo-50 dark:bg-indigo-900/20 rounded-xl p-4 border border-indigo-100 dark:border-indigo-800">
                        <div class="flex items-center gap-2 mb-2">
                            <Sparkles class="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                            <span class="text-xs font-semibold text-indigo-700 dark:text-indigo-300">AI Summary</span>
                        </div>
                        <p class="text-sm text-indigo-800 dark:text-indigo-200">{{ summary }}</p>
                    </div>
                </div>

                <!-- Smart suggestions -->
                <div v-if="suggestions.length" class="px-4 py-2 border-t border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50">
                    <p class="text-xs text-gray-500 dark:text-gray-400 mb-2">AI Suggestions:</p>
                    <div class="flex gap-2 overflow-x-auto pb-1">
                        <button v-for="s in suggestions" :key="s.label"
                                @click="messageInput = s.content"
                                class="flex-shrink-0 text-xs px-3 py-1.5 rounded-full border border-brand-200 dark:border-brand-800 text-brand-700 dark:text-brand-300 hover:bg-brand-50 dark:hover:bg-brand-900/20 transition-colors">
                            {{ s.label }}
                        </button>
                    </div>
                </div>

                <!-- Message input -->
                <div class="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
                    <!-- Internal note toggle -->
                    <div class="flex items-center gap-3 px-4 pt-3">
                        <button @click="isInternal = false"
                                :class="['text-xs font-medium px-3 py-1 rounded-full transition-colors',
                                         !isInternal ? 'bg-brand-100 text-brand-700 dark:bg-brand-900/30 dark:text-brand-400' : 'text-gray-500 hover:text-gray-700']">
                            Reply
                        </button>
                        <button @click="isInternal = true"
                                :class="['text-xs font-medium px-3 py-1 rounded-full transition-colors flex items-center gap-1',
                                         isInternal ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' : 'text-gray-500 hover:text-gray-700']">
                            <Lock class="w-3 h-3" />
                            Internal Note
                        </button>
                    </div>

                    <div class="p-4 flex gap-3">
                        <textarea
                            v-model="messageInput"
                            @keydown.enter.exact.prevent="sendMessage"
                            @input="handleTyping"
                            :placeholder="isInternal ? 'Write an internal note... (not visible to customer)' : 'Type a message... (Enter to send, Shift+Enter for new line)'"
                            rows="3"
                            :class="['input resize-none transition-colors',
                                     isInternal ? 'border-amber-300 dark:border-amber-700 bg-amber-50/50 dark:bg-amber-900/10' : '']"
                        />
                        <div class="flex flex-col gap-2">
                            <label class="btn-secondary btn-sm cursor-pointer" title="Attach file">
                                <Paperclip class="w-4 h-4" />
                                <input type="file" class="hidden" @change="attachFile" />
                            </label>
                            <button @click="sendMessage" :disabled="!messageInput.trim() || sending"
                                    class="btn-primary btn-sm flex-1">
                                <div v-if="sending" class="spinner w-4 h-4" />
                                <Send v-else class="w-4 h-4" />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right sidebar: customer info -->
            <aside class="w-72 flex-shrink-0 bg-white dark:bg-gray-900 border-l border-gray-200 dark:border-gray-800 overflow-y-auto">
                <CustomerInfoPanel :conversation="conversation" />
            </aside>
        </div>
    </AppLayout>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, nextTick, computed } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import { ChevronRight, CheckCircle, Sparkles, Lock, Paperclip, Send, Zap } from 'lucide-vue-next';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import ChatMessage from '@/Components/Chat/ChatMessage.vue';
import ConvTypeBadge from '@/Components/Chat/ConvTypeBadge.vue';
import ConvStatusBadge from '@/Components/Chat/ConvStatusBadge.vue';
import PriorityBadge from '@/Components/Shared/PriorityBadge.vue';
import AgentAssignDropdown from '@/Components/Chat/AgentAssignDropdown.vue';
import CustomerInfoPanel from '@/Components/Chat/CustomerInfoPanel.vue';
import { useToast } from '@/Composables/useToast';

const props = defineProps<{
    conversation: any;
    messages: any;
    agents: any[];
    suggestions: any[];
}>();

const { toast } = useToast();
const messagesContainer = ref<HTMLElement | null>(null);
const messageInput = ref('');
const isInternal = ref(false);
const sending = ref(false);
const summarizing = ref(false);
const isTyping = ref(false);
const summary = ref('');
const allMessages = ref([...props.messages.data]);
let typingTimer: ReturnType<typeof setTimeout>;
let channel: any;

onMounted(() => {
    scrollToBottom();
    setupRealtime();
});

onUnmounted(() => {
    channel?.stopListening('.message.sent');
    channel?.stopListening('.typing');
    window.Echo?.leave(`conversation.${props.conversation.id}`);
});

function setupRealtime() {
    channel = window.Echo.join(`conversation.${props.conversation.id}`)
        .here((users: any) => {})
        .joining((user: any) => {})
        .leaving((user: any) => {})
        .listen('.message.sent', (e: any) => {
            allMessages.value.push(e);
            nextTick(scrollToBottom);
        })
        .listen('.typing', (e: any) => {
            if (e.sender_type !== 'user') {
                isTyping.value = e.is_typing;
                if (isTyping.value) {
                    setTimeout(() => { isTyping.value = false; }, 3000);
                }
            }
        });
}

async function sendMessage() {
    if (!messageInput.value.trim() || sending.value) return;
    sending.value = true;
    try {
        const { data } = await axios.post(route('tenant.conversations.messages.send', props.conversation.id), {
            content: messageInput.value,
            is_internal: isInternal.value,
        });
        allMessages.value.push(data.message);
        messageInput.value = '';
        nextTick(scrollToBottom);
    } catch (e) {
        toast.error('Failed to send message');
    } finally {
        sending.value = false;
    }
}

function handleTyping() {
    axios.post(route('tenant.conversations.typing', props.conversation.id), { is_typing: true });
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
        axios.post(route('tenant.conversations.typing', props.conversation.id), { is_typing: false });
    }, 2000);
}

async function resolveConversation() {
    await axios.post(route('tenant.conversations.resolve', props.conversation.id));
    toast.success('Conversation resolved');
    router.reload();
}

async function assignConversation(agentId: number | null) {
    await axios.post(route('tenant.conversations.assign', props.conversation.id), { agent_id: agentId });
    router.reload({ only: ['conversation'] });
}

async function addReaction(messageId: number, emoji: string) {
    await axios.post(route('tenant.conversations.reactions', [props.conversation.id, messageId]), { emoji });
}

async function summarizeConversation() {
    summarizing.value = true;
    try {
        const { data } = await axios.get(route('tenant.conversations.summarize', props.conversation.id));
        summary.value = data.summary;
    } catch (e) {
        toast.error('Failed to generate summary');
    } finally {
        summarizing.value = false;
    }
}

function attachFile(e: Event) {
    const file = (e.target as HTMLInputElement).files?.[0];
    if (file) toast.info(`File "${file.name}" ready to attach`);
}

function scrollToBottom() {
    if (messagesContainer.value) {
        messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight;
    }
}
</script>
