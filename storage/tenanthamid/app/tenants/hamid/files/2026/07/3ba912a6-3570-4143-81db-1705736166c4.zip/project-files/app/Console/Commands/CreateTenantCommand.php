<?php

namespace App\Console\Commands;

use App\Models\Tenant;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Str;

class CreateTenantCommand extends Command
{
    protected $signature = 'tenant:create
                            {name      : Company name}
                            {email     : Owner email}
                            {domain    : Full domain (e.g. company.yourdomain.com)}
                            {--slug=   : URL slug (auto-generated if omitted)}
                            {--plan=professional : Subscription plan}';

    protected $description = 'Create a new tenant with database, migrations and seed data';

    public function handle(): int
    {
        $name   = $this->argument('name');
        $email  = $this->argument('email');
        $domain = $this->argument('domain');
        $slug   = $this->option('slug') ?: Str::slug($name);
        $plan   = $this->option('plan');

        if (Tenant::where('email', $email)->exists()) {
            $this->error("Tenant with email [{$email}] already exists.");
            return self::FAILURE;
        }

        $this->info("Creating tenant: {$name}");

        $tenant = Tenant::create([
            'id'    => Str::uuid()->toString(),
            'name'  => $name,
            'slug'  => $slug,
            'email' => $email,
            'plan'  => $plan,
        ]);

        $tenant->domains()->create(['domain' => $domain]);
        $this->line("  ✓ Tenant record created");

        tenancy()->initialize($tenant);

        $this->line("  ✓ Running tenant migrations...");
        Artisan::call('migrate', [
            '--path'  => 'database/migrations/tenant',
            '--force' => true,
        ]);

        $this->line("  ✓ Seeding tenant database...");
        Artisan::call('db:seed', [
            '--class' => 'TenantDatabaseSeeder',
            '--force' => true,
        ]);

        tenancy()->end();

        $this->newLine();
        $this->info("✅ Tenant created successfully!");
        $this->table(['Field', 'Value'], [
            ['ID',     $tenant->id],
            ['Name',   $name],
            ['Email',  $email],
            ['Domain', $domain],
            ['Plan',   $plan],
            ['Login',  "https://{$domain}"],
            ['User',   'owner@example.com'],
            ['Pass',   'password (change immediately!)'],
        ]);

        return self::SUCCESS;
    }
}
