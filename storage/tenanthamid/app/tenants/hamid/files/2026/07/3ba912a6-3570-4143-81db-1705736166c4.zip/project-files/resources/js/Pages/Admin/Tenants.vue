<template>
  <div class="min-h-screen bg-gray-50 dark:bg-gray-950 p-6">
    <div class="max-w-6xl mx-auto space-y-6">
      <div class="flex items-center justify-between">
        <div>
          <Link :href="route('admin.dashboard')" class="text-sm text-gray-500 hover:text-gray-700">← Admin Dashboard</Link>
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white mt-1">Tenants</h1>
        </div>
        <button @click="showCreate = true" class="btn-primary"><Plus class="w-4 h-4"/>New Tenant</button>
      </div>

      <!-- Search/filter bar -->
      <div class="card card-body py-3 flex gap-3">
        <div class="relative flex-1">
          <Search class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"/>
          <input v-model="search" @input="debSearch" placeholder="Search tenants..." class="input pl-9"/>
        </div>
        <select v-model="planFilter" @change="applyFilters" class="input w-36 text-sm">
          <option value="">All Plans</option>
          <option value="free">Free</option>
          <option value="starter">Starter</option>
          <option value="professional">Professional</option>
          <option value="enterprise">Enterprise</option>
        </select>
      </div>

      <!-- Table -->
      <div class="table-wrapper">
        <table class="table">
          <thead><tr><th>Tenant</th><th>Slug</th><th>Plan</th><th>Domains</th><th>Status</th><th>Created</th><th></th></tr></thead>
          <tbody>
            <tr v-for="t in tenants.data" :key="t.id">
              <td>
                <div>
                  <p class="font-medium text-sm text-gray-900 dark:text-white">{{ t.name }}</p>
                  <p class="text-xs text-gray-500">{{ t.email }}</p>
                </div>
              </td>
              <td><span class="font-mono text-xs text-gray-600 dark:text-gray-400">{{ t.slug }}</span></td>
              <td><span class="badge badge-purple capitalize">{{ t.plan }}</span></td>
              <td class="text-sm text-center">{{ t.domains_count }}</td>
              <td>
                <span :class="t.is_active ? 'badge-green' : 'badge-red'" class="badge">{{ t.is_active ? 'Active' : 'Inactive' }}</span>
              </td>
              <td class="text-xs text-gray-500">{{ formatTime(t.created_at) }}</td>
              <td>
                <div class="flex gap-1">
                  <button @click="toggleTenant(t)" class="btn-ghost btn-sm p-1.5">
                    <Power class="w-3.5 h-3.5" :class="t.is_active ? 'text-emerald-500' : 'text-red-400'"/>
                  </button>
                  <button @click="deleteTenant(t.id)" class="btn-ghost btn-sm p-1.5 text-red-500 hover:text-red-600">
                    <Trash2 class="w-3.5 h-3.5"/>
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <Pagination :links="tenants.links" :meta="tenants"/>
    </div>

    <!-- Create Tenant Modal -->
    <Modal :show="showCreate" title="Create Tenant" max-width="lg" @close="showCreate = false">
      <form @submit.prevent="createTenant" class="space-y-4">
        <div class="grid grid-cols-2 gap-3">
          <div><label class="label">Company Name *</label><input v-model="form.name" class="input" required/></div>
          <div><label class="label">Email *</label><input v-model="form.email" type="email" class="input" required/></div>
          <div><label class="label">Slug *</label><input v-model="form.slug" class="input" placeholder="company-name" required/></div>
          <div><label class="label">Domain *</label><input v-model="form.domain" class="input" placeholder="company.yourdomain.com" required/></div>
        </div>
        <div><label class="label">Plan</label>
          <select v-model="form.plan" class="input">
            <option value="free">Free</option><option value="starter">Starter</option>
            <option value="professional">Professional</option><option value="enterprise">Enterprise</option>
          </select>
        </div>
        <div class="flex justify-end gap-2">
          <button type="button" @click="showCreate=false" class="btn-secondary btn-sm">Cancel</button>
          <button type="submit" :disabled="creating" class="btn-primary btn-sm">
            <Spinner v-if="creating" size="sm"/>Create Tenant
          </button>
        </div>
      </form>
    </Modal>
  </div>
</template>
<script setup lang="ts">
import { ref, reactive } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import { Search, Plus, Power, Trash2 } from 'lucide-vue-next';
import { useDebounceFn } from '@vueuse/core';
import axios from 'axios';
import Modal from '@/Components/UI/Modal.vue';
import Pagination from '@/Components/Shared/Pagination.vue';
import Spinner from '@/Components/UI/Spinner.vue';
import { formatTime } from '@/Utils/format';
import { useToast } from '@/Composables/useToast';
const props = defineProps<{ tenants: any; filters: any }>();
const { toast } = useToast();
const showCreate = ref(false); const creating = ref(false);
const search = ref(props.filters.search ?? ''); const planFilter = ref(props.filters.plan ?? '');
const form = reactive({ name:'', email:'', slug:'', domain:'', plan:'professional' });
const debSearch = useDebounceFn(() => applyFilters(), 400);
function applyFilters() { router.get(route('admin.tenants'), { search: search.value||undefined, plan: planFilter.value||undefined }, { preserveState: true }); }
async function createTenant() { creating.value=true; try { await axios.post(route('admin.tenants.store'), form); showCreate.value=false; router.reload(); toast.success('Tenant created!'); } catch(e:any) { toast.error(e.response?.data?.message??'Failed'); } finally { creating.value=false; } }
async function toggleTenant(t: any) { await axios.put(route('admin.tenants.update', t.id), { is_active: !t.is_active }); router.reload(); }
async function deleteTenant(id: string) { if (confirm('Delete this tenant? This is IRREVERSIBLE.')) { await axios.delete(route('admin.tenants.delete', id)); router.reload(); } }
</script>
