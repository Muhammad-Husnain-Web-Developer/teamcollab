<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Message extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'uuid',
        'conversation_id',
        'sender_id',
        'sender_type',
        'type',
        'content',
        'attachments',
        'meta',
        'is_internal',
        'status',
        'reactions',
        'parent_id',
        'is_ai_generated',
        'ai_confidence',
    ];

    protected $casts = [
        'attachments' => 'array',
        'meta' => 'array',
        'reactions' => 'array',
        'is_internal' => 'boolean',
        'is_ai_generated' => 'boolean',
        'ai_confidence' => 'float',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(function (self $model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid()->toString();
            }
        });

        static::created(function (self $model) {
            $model->conversation->increment('message_count');
            $model->conversation->update(['last_activity_at' => now()]);
        });
    }

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(Conversation::class);
    }

    public function sender(): MorphTo
    {
        return $this->morphTo();
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Message::class, 'parent_id');
    }

    public function replies(): HasMany
    {
        return $this->hasMany(Message::class, 'parent_id');
    }

    public function attachments(): HasMany
    {
        return $this->hasMany(MessageAttachment::class);
    }

    public function addReaction(string $emoji, int $userId): void
    {
        $reactions = $this->reactions ?? [];
        if (! isset($reactions[$emoji])) {
            $reactions[$emoji] = [];
        }
        if (! in_array($userId, $reactions[$emoji])) {
            $reactions[$emoji][] = $userId;
        } else {
            $reactions[$emoji] = array_filter($reactions[$emoji], fn($id) => $id !== $userId);
            if (empty($reactions[$emoji])) {
                unset($reactions[$emoji]);
            }
        }
        $this->update(['reactions' => $reactions]);
    }

    public function markAsSeen(): void
    {
        $this->update(['status' => 'seen']);
    }

    public function markAsDelivered(): void
    {
        if ($this->status === 'sent') {
            $this->update(['status' => 'delivered']);
        }
    }

    public function getSenderNameAttribute(): string
    {
        return $this->sender?->name ?? 'Unknown';
    }
}
