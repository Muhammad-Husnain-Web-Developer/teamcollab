<?php

namespace App\Notifications;

use App\Models\Conversation;
use App\Models\Message;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\BroadcastMessage;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NewMessageNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(
        private readonly Conversation $conversation,
        private readonly ?Message $message,
    ) {}

    public function via(object $notifiable): array
    {
        return ['database', 'broadcast'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('New message from ' . $this->conversation->customer->name)
            ->line('You have a new message in conversation #' . $this->conversation->uuid)
            ->line($this->message?->content ?? '')
            ->action('View Conversation', url('/conversations/' . $this->conversation->id));
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'            => 'new_message',
            'message'         => 'New message from ' . $this->conversation->customer->name,
            'conversation_id' => $this->conversation->id,
            'conversation_uuid'=> $this->conversation->uuid,
            'customer_name'   => $this->conversation->customer->name,
            'preview'         => $this->message ? substr($this->message->content, 0, 100) : '',
        ];
    }

    public function toBroadcast(object $notifiable): BroadcastMessage
    {
        return new BroadcastMessage($this->toArray($notifiable));
    }
}
