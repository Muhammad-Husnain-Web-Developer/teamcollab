<template>
  <div v-if="meta.last_page > 1" class="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
    <p>Showing {{ meta.from }}–{{ meta.to }} of {{ meta.total }}</p>
    <div class="flex gap-1">
      <Link v-for="link in links" :key="link.label"
            :href="link.url ?? '#'"
            :class="['px-3 py-1.5 rounded-lg text-xs font-medium transition-colors',
                     link.active ? 'bg-brand-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-800',
                     !link.url ? 'opacity-40 cursor-default pointer-events-none' : '']"
            preserve-scroll preserve-state
            v-html="link.label" />
    </div>
  </div>
</template>
<script setup lang="ts">
import { Link } from '@inertiajs/vue3';
defineProps<{ links: any[]; meta: any }>();
</script>
