<?php

namespace App\Notifications;

use App\Models\Ticket;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NewTicketNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(private readonly Ticket $ticket) {}

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("New Ticket: {$this->ticket->ticket_number}")
            ->line("A new support ticket has been created by {$this->ticket->customer->name}.")
            ->line("Subject: {$this->ticket->subject}")
            ->line("Priority: {$this->ticket->priority}")
            ->action('View Ticket', url('/tickets/' . $this->ticket->id));
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type'          => 'new_ticket',
            'message'       => "New ticket: {$this->ticket->subject}",
            'ticket_id'     => $this->ticket->id,
            'ticket_number' => $this->ticket->ticket_number,
            'priority'      => $this->ticket->priority,
            'customer_name' => $this->ticket->customer->name,
        ];
    }
}
