<template>
  <AppLayout>
    <template #header><h1 class="text-sm font-semibold text-gray-900 dark:text-white">Settings</h1></template>
    <div class="p-6 max-w-4xl mx-auto space-y-5">

      <!-- Tabs -->
      <div class="flex gap-1 border-b border-gray-200 dark:border-gray-800">
        <button v-for="t in tabs" :key="t.id" @click="activeTab = t.id"
                :class="['px-4 py-2.5 text-sm font-medium border-b-2 transition-colors flex items-center gap-2',
                         activeTab === t.id ? 'border-brand-600 text-brand-600 dark:text-brand-400' : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300']">
          <component :is="t.icon" class="w-4 h-4" />
          {{ t.label }}
        </button>
      </div>

      <!-- General Settings -->
      <div v-if="activeTab === 'general'" class="card card-body space-y-4">
        <h2 class="text-base font-semibold text-gray-900 dark:text-white">General Settings</h2>
        <div class="grid grid-cols-2 gap-4">
          <div><label class="label">Company Name</label><input v-model="general.company_name" class="input" /></div>
          <div><label class="label">Support Email</label><input v-model="general.support_email" type="email" class="input" /></div>
          <div><label class="label">Support Phone</label><input v-model="general.support_phone" class="input" /></div>
          <div><label class="label">Timezone</label>
            <select v-model="general.timezone" class="input">
              <option value="UTC">UTC</option>
              <option value="America/New_York">Eastern Time</option>
              <option value="America/Los_Angeles">Pacific Time</option>
              <option value="Europe/London">London</option>
              <option value="Asia/Karachi">Karachi (PKT)</option>
              <option value="Asia/Dubai">Dubai</option>
            </select>
          </div>
        </div>
        <div><label class="label">Widget Greeting Message</label>
          <textarea v-model="general.widget_greeting" rows="2" class="input resize-none" />
        </div>
        <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <div><p class="text-sm font-medium text-gray-900 dark:text-white">Auto Assignment</p>
            <p class="text-xs text-gray-500">Automatically assign conversations to available agents</p></div>
          <Toggle v-model="general.auto_assignment" />
        </div>
        <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <div><p class="text-sm font-medium text-gray-900 dark:text-white">Email Notifications</p>
            <p class="text-xs text-gray-500">Send email notifications for new tickets and messages</p></div>
          <Toggle v-model="general.email_notifications" />
        </div>
        <div class="flex justify-end">
          <button @click="saveGeneral" :disabled="saving" class="btn-primary btn-sm"><Save class="w-4 h-4" />Save Settings</button>
        </div>
      </div>

      <!-- Branding -->
      <div v-if="activeTab === 'branding'" class="card card-body space-y-5">
        <h2 class="text-base font-semibold text-gray-900 dark:text-white">Branding</h2>
        <div class="grid grid-cols-2 gap-6">
          <div>
            <label class="label">Company Logo</label>
            <div class="border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl p-6 text-center hover:border-brand-400 transition-colors cursor-pointer" @click="$refs.logoInput.click()">
              <img v-if="tenant.logo" :src="'/storage/'+tenant.logo" class="h-16 mx-auto object-contain mb-2" />
              <Upload v-else class="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p class="text-xs text-gray-500">Click to upload logo</p>
              <input ref="logoInput" type="file" accept="image/*" class="hidden" @change="handleLogoUpload" />
            </div>
          </div>
          <div>
            <label class="label">Favicon</label>
            <div class="border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl p-6 text-center hover:border-brand-400 transition-colors cursor-pointer" @click="$refs.faviconInput.click()">
              <img v-if="tenant.favicon" :src="'/storage/'+tenant.favicon" class="h-16 mx-auto object-contain mb-2" />
              <Upload v-else class="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p class="text-xs text-gray-500">Click to upload favicon</p>
              <input ref="faviconInput" type="file" accept="image/*" class="hidden" @change="handleFaviconUpload" />
            </div>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="label">Primary Color</label>
            <div class="flex items-center gap-3">
              <input v-model="branding.primary_color" type="color" class="w-12 h-10 rounded-lg border border-gray-200 dark:border-gray-700 cursor-pointer p-1" />
              <input v-model="branding.primary_color" class="input flex-1 font-mono text-sm" placeholder="#6366f1" />
            </div>
          </div>
          <div>
            <label class="label">Secondary Color</label>
            <div class="flex items-center gap-3">
              <input v-model="branding.secondary_color" type="color" class="w-12 h-10 rounded-lg border border-gray-200 dark:border-gray-700 cursor-pointer p-1" />
              <input v-model="branding.secondary_color" class="input flex-1 font-mono text-sm" placeholder="#8b5cf6" />
            </div>
          </div>
        </div>
        <!-- Preview -->
        <div class="border border-gray-200 dark:border-gray-700 rounded-xl p-4">
          <p class="text-xs text-gray-500 mb-3">Color Preview</p>
          <div class="flex gap-3">
            <div class="h-12 flex-1 rounded-lg" :style="{ backgroundColor: branding.primary_color }" />
            <div class="h-12 flex-1 rounded-lg" :style="{ backgroundColor: branding.secondary_color }" />
          </div>
        </div>
        <div class="flex justify-end">
          <button @click="saveBranding" :disabled="saving" class="btn-primary btn-sm"><Save class="w-4 h-4" />Save Branding</button>
        </div>
      </div>

      <!-- AI Settings -->
      <div v-if="activeTab === 'ai'" class="space-y-4">
        <div class="card card-body space-y-4">
          <h2 class="text-base font-semibold text-gray-900 dark:text-white">AI Provider</h2>
          <div class="grid grid-cols-2 gap-3">
            <button v-for="p in aiProviders" :key="p.id"
                    @click="selectProvider(p.id)"
                    :class="['p-4 rounded-xl border-2 text-left transition-all',
                             current_ai_provider === p.id ? 'border-brand-500 bg-brand-50 dark:bg-brand-900/20' : 'border-gray-200 dark:border-gray-700 hover:border-brand-300']">
              <div class="flex items-center gap-3 mb-2">
                <div :class="['w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold', p.color]">{{ p.short }}</div>
                <span class="font-semibold text-sm text-gray-900 dark:text-white">{{ p.name }}</span>
                <span v-if="current_ai_provider === p.id" class="ml-auto badge badge-green text-xs">Active</span>
              </div>
              <p class="text-xs text-gray-500">{{ p.desc }}</p>
            </button>
          </div>
        </div>
        <div class="card card-body space-y-4">
          <h2 class="text-base font-semibold text-gray-900 dark:text-white">AI Behaviour</h2>
          <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div><p class="text-sm font-medium text-gray-900 dark:text-white">AI Auto-Responses</p>
              <p class="text-xs text-gray-500">Let AI automatically respond to new conversations</p></div>
            <Toggle v-model="aiSettings.ai_enabled" />
          </div>
          <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div><p class="text-sm font-medium text-gray-900 dark:text-white">Smart Suggestions</p>
              <p class="text-xs text-gray-500">Show AI-generated reply suggestions to agents</p></div>
            <Toggle v-model="aiSettings.smart_suggestions" />
          </div>
          <div>
            <label class="label">Escalation Threshold</label>
            <p class="text-xs text-gray-500 mb-2">AI confidence score below this will trigger human escalation</p>
            <div class="flex items-center gap-4">
              <input v-model="aiSettings.escalation_threshold" type="range" min="0.1" max="0.9" step="0.1" class="flex-1" />
              <span class="text-sm font-semibold text-brand-600 w-10">{{ (aiSettings.escalation_threshold * 100).toFixed(0) }}%</span>
            </div>
          </div>
          <div class="flex justify-end">
            <button @click="saveAiSettings" class="btn-primary btn-sm"><Save class="w-4 h-4" />Save AI Settings</button>
          </div>
        </div>
      </div>

      <!-- Notifications -->
      <div v-if="activeTab === 'notifications'" class="card card-body space-y-4">
        <h2 class="text-base font-semibold text-gray-900 dark:text-white">Notification Settings</h2>
        <div v-for="n in notifSettings" :key="n.key"
             class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <div>
            <p class="text-sm font-medium text-gray-900 dark:text-white">{{ n.label }}</p>
            <p class="text-xs text-gray-500">{{ n.desc }}</p>
          </div>
          <Toggle v-model="n.value" />
        </div>
        <div class="flex justify-end">
          <button @click="saveNotifications" class="btn-primary btn-sm"><Save class="w-4 h-4" />Save</button>
        </div>
      </div>

    </div>
  </AppLayout>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';
import { Settings, Palette, Bot, Bell, Save, Upload } from 'lucide-vue-next';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import Toggle from '@/Components/UI/Toggle.vue';
import { useToast } from '@/Composables/useToast';

const props = defineProps<{
  settings: any;
  tenant: any;
  ai_providers: any;
  current_ai_provider: string;
}>();

const { toast } = useToast();
const saving = ref(false);
const activeTab = ref('general');

const tabs = [
  { id: 'general',       label: 'General',       icon: Settings },
  { id: 'branding',      label: 'Branding',      icon: Palette },
  { id: 'ai',            label: 'AI Settings',   icon: Bot },
  { id: 'notifications', label: 'Notifications', icon: Bell },
];

const general = reactive({
  company_name:        props.settings?.general?.find((s:any) => s.key === 'company_name')?.value ?? '',
  support_email:       props.settings?.general?.find((s:any) => s.key === 'support_email')?.value ?? '',
  support_phone:       props.settings?.general?.find((s:any) => s.key === 'support_phone')?.value ?? '',
  timezone:            props.settings?.general?.find((s:any) => s.key === 'timezone')?.value ?? 'UTC',
  widget_greeting:     props.settings?.chat?.find((s:any) => s.key === 'widget_greeting')?.value ?? '',
  auto_assignment:     props.settings?.chat?.find((s:any) => s.key === 'auto_assignment')?.value === '1',
  email_notifications: props.settings?.notifications?.find((s:any) => s.key === 'email_notifications')?.value === '1',
});

const branding = reactive({
  name:            props.tenant?.name ?? '',
  primary_color:   props.tenant?.primary_color ?? '#6366f1',
  secondary_color: props.tenant?.secondary_color ?? '#8b5cf6',
});

const aiSettings = reactive({
  ai_enabled:             true,
  smart_suggestions:      true,
  escalation_threshold:   0.4,
});

const aiProviders = [
  { id: 'gemini', name: 'Google Gemini', short: 'G',  color: 'bg-blue-500',   desc: 'Fast, multimodal AI by Google' },
  { id: 'openai', name: 'OpenAI GPT-4o', short: 'O',  color: 'bg-emerald-500', desc: 'Powerful language model by OpenAI' },
  { id: 'claude', name: 'Anthropic Claude', short: 'C', color: 'bg-orange-500', desc: 'Safe, helpful AI by Anthropic' },
  { id: 'ollama', name: 'Ollama (Local)', short: 'L',  color: 'bg-gray-600',   desc: 'Run models locally on your server' },
];

const notifSettings = reactive([
  { key: 'new_conversation',  label: 'New Conversation',   desc: 'Notify when a new conversation starts', value: true },
  { key: 'new_message',       label: 'New Message',        desc: 'Notify on new messages in assigned conversations', value: true },
  { key: 'new_ticket',        label: 'New Ticket',         desc: 'Notify when a new ticket is created', value: true },
  { key: 'ticket_assigned',   label: 'Ticket Assigned',    desc: 'Notify when a ticket is assigned to you', value: true },
  { key: 'escalation',        label: 'Escalation',         desc: 'Notify when AI escalates to human', value: true },
]);

async function saveGeneral() {
  saving.value = true;
  try {
    await axios.post(route('tenant.settings.update'), {
      settings: Object.entries(general).map(([key, value]) => ({ key, value }))
    });
    toast.success('Settings saved!');
  } catch { toast.error('Failed to save'); }
  finally { saving.value = false; }
}

async function saveBranding() {
  saving.value = true;
  try {
    const fd = new FormData();
    Object.entries(branding).forEach(([k, v]) => fd.append(k, v as string));
    await axios.post(route('tenant.settings.branding'), fd);
    toast.success('Branding saved!');
  } catch { toast.error('Failed to save'); }
  finally { saving.value = false; }
}

async function selectProvider(provider: string) {
  await axios.post(route('tenant.settings.ai-provider'), { provider });
  toast.success(`Switched to ${provider}`);
  window.location.reload();
}

async function saveAiSettings() {
  await axios.post(route('tenant.settings.update'), {
    settings: Object.entries(aiSettings).map(([key, value]) => ({ key, value }))
  });
  toast.success('AI settings saved!');
}

async function saveNotifications() {
  await axios.post(route('tenant.settings.update'), {
    settings: notifSettings.map(n => ({ key: n.key, value: n.value ? '1' : '0' }))
  });
  toast.success('Notification settings saved!');
}

function handleLogoUpload(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0];
  if (file) { /* handled via form submit */ }
}
function handleFaviconUpload(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0];
  if (file) { /* handled via form submit */ }
}
</script>
