<template>
  <span class="badge" :class="colors[type]">{{ labels[type] ?? type }}</span>
</template>
<script setup lang="ts">
defineProps<{ type: string }>();
const labels: Record<string,string> = { ai:'AI', human:'Human', hybrid:'Hybrid' };
const colors: Record<string,string> = {
  ai:    'bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-400',
  human: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
  hybrid:'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
};
</script>
