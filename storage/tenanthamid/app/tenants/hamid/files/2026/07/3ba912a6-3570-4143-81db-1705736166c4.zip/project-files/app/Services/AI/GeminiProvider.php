<?php

namespace App\Services\AI;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class GeminiProvider implements AIProviderInterface
{
    private string $apiKey;
    private string $model;
    private string $baseUrl;
    private int $maxTokens;
    private float $temperature;

    public function __construct(array $config)
    {
        $this->apiKey = $config['api_key'] ?? '';
        $this->model = $config['model'] ?? 'gemini-1.5-flash';
        $this->baseUrl = $config['base_url'] ?? 'https://generativelanguage.googleapis.com/v1beta';
        $this->maxTokens = $config['max_tokens'] ?? 2048;
        $this->temperature = $config['temperature'] ?? 0.7;
    }

    public function generateResponse(array $messages, ?string $systemPrompt = null, array $options = []): AIResponse
    {
        $contents = $this->formatMessages($messages);

        $payload = [
            'contents' => $contents,
            'generationConfig' => [
                'temperature' => $options['temperature'] ?? $this->temperature,
                'maxOutputTokens' => $options['max_tokens'] ?? $this->maxTokens,
                'topP' => 0.8,
                'topK' => 10,
            ],
        ];

        if ($systemPrompt) {
            $payload['systemInstruction'] = [
                'parts' => [['text' => $systemPrompt]],
            ];
        }

        if (! empty($options['safety_settings'])) {
            $payload['safetySettings'] = $options['safety_settings'];
        }

        try {
            $response = Http::timeout(30)
                ->post("{$this->baseUrl}/models/{$this->model}:generateContent?key={$this->apiKey}", $payload);

            if ($response->failed()) {
                Log::error('Gemini API error', ['status' => $response->status(), 'body' => $response->body()]);
                throw new \RuntimeException("Gemini API error: " . $response->body());
            }

            $data = $response->json();
            $content = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
            $usage = $data['usageMetadata'] ?? [];

            $shouldEscalate = str_contains($content, '[ESCALATE]');
            $confidence = $shouldEscalate ? 0.3 : 0.9;

            return new AIResponse(
                content: $content,
                provider: 'gemini',
                model: $this->model,
                promptTokens: $usage['promptTokenCount'] ?? 0,
                completionTokens: $usage['candidatesTokenCount'] ?? 0,
                confidenceScore: $confidence,
                shouldEscalate: $shouldEscalate,
                meta: ['finish_reason' => $data['candidates'][0]['finishReason'] ?? ''],
            );
        } catch (\Exception $e) {
            Log::error('Gemini provider error', ['error' => $e->getMessage()]);
            throw $e;
        }
    }

    public function complete(string $prompt, array $options = []): AIResponse
    {
        return $this->generateResponse([
            ['role' => 'user', 'content' => $prompt],
        ], null, $options);
    }

    public function isAvailable(): bool
    {
        return ! empty($this->apiKey);
    }

    public function getName(): string
    {
        return 'gemini';
    }

    public function getModel(): string
    {
        return $this->model;
    }

    private function formatMessages(array $messages): array
    {
        $contents = [];
        foreach ($messages as $message) {
            $role = $message['role'] === 'assistant' ? 'model' : 'user';
            $contents[] = [
                'role' => $role,
                'parts' => [['text' => $message['content']]],
            ];
        }
        return $contents;
    }
}
