<?php

namespace App\Jobs;

use App\Events\MessageSent;
use App\Models\Conversation;
use App\Models\Message;
use App\Services\AI\AIService;
use App\Services\Chat\ChatService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ProcessAiResponse implements ShouldQueue
{
    use Queueable, InteractsWithQueue, SerializesModels;

    public int $tries = 3;
    public int $timeout = 60;
    public array $backoff = [5, 15, 30];

    public function __construct(
        private readonly Conversation $conversation,
        private readonly Message $triggerMessage,
    ) {}

    public function handle(AIService $aiService, ChatService $chatService): void
    {
        try {
            $this->conversation->loadMissing(['customer', 'messages', 'aiConversation']);

            $response = $aiService->handleCustomerMessage(
                $this->conversation,
                $this->triggerMessage->content
            );

            if ($aiService->shouldEscalate($response)) {
                // Send escalation message first
                $chatService->sendAiMessage(
                    $this->conversation,
                    "I'm connecting you with a human agent who can better assist you. Please hold on.",
                    $response->toArray()
                );

                // Escalate to human
                $chatService->escalateToHuman($this->conversation);
            } else {
                $chatService->sendAiMessage(
                    $this->conversation,
                    $response->getCleanContent(),
                    $response->toArray()
                );

                // Update AI conversation stats
                if ($this->conversation->aiConversation) {
                    $this->conversation->aiConversation->increment('prompt_tokens', $response->promptTokens);
                    $this->conversation->aiConversation->increment('completion_tokens', $response->completionTokens);
                }
            }
        } catch (\Exception $e) {
            Log::error('AI response processing failed', [
                'conversation_id' => $this->conversation->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            if ($this->attempts() >= $this->tries) {
                // After all retries, send fallback message and escalate
                $chatService->sendAiMessage(
                    $this->conversation,
                    "I apologize, I'm experiencing technical difficulties. Let me connect you with a human agent.",
                    []
                );
                $chatService->escalateToHuman($this->conversation);
            }

            throw $e;
        }
    }

    public function failed(\Throwable $exception): void
    {
        Log::error('AI response job permanently failed', [
            'conversation_id' => $this->conversation->id,
            'error' => $exception->getMessage(),
        ]);
    }
}
