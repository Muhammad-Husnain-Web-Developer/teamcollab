<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('kb_categories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('parent_id')->nullable()->constrained('kb_categories')->nullOnDelete();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('icon')->nullable();
            $table->string('color')->default('#6366f1');
            $table->integer('order')->default(0);
            $table->boolean('is_public')->default(true);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('kb_articles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->nullable()->constrained('kb_categories')->nullOnDelete();
            $table->foreignId('author_id')->constrained('users')->cascadeOnDelete();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('excerpt')->nullable();
            $table->longText('content');
            $table->longText('content_text')->nullable(); // plain text for search
            $table->json('tags')->nullable();
            $table->string('status')->default('draft'); // draft, published, archived
            $table->boolean('is_public')->default(true);
            $table->integer('views')->default(0);
            $table->integer('helpful_count')->default(0);
            $table->integer('not_helpful_count')->default(0);
            $table->integer('order')->default(0);
            $table->json('meta')->nullable();
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['status', 'is_public']);
            $table->fullText(['title', 'content_text']);
        });

        Schema::create('kb_article_feedback', function (Blueprint $table) {
            $table->id();
            $table->foreignId('article_id')->constrained('kb_articles')->cascadeOnDelete();
            $table->foreignId('customer_id')->nullable()->constrained()->nullOnDelete();
            $table->boolean('is_helpful');
            $table->text('feedback')->nullable();
            $table->string('ip_address')->nullable();
            $table->timestamps();
        });

        Schema::create('kb_faqs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->nullable()->constrained('kb_categories')->nullOnDelete();
            $table->string('question');
            $table->text('answer');
            $table->json('tags')->nullable();
            $table->boolean('is_public')->default(true);
            $table->boolean('is_active')->default(true);
            $table->integer('order')->default(0);
            $table->integer('views')->default(0);
            $table->timestamps();

            $table->fullText(['question', 'answer']);
        });

        Schema::create('kb_search_logs', function (Blueprint $table) {
            $table->id();
            $table->string('query');
            $table->foreignId('customer_id')->nullable()->constrained()->nullOnDelete();
            $table->integer('results_count')->default(0);
            $table->boolean('found_answer')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kb_search_logs');
        Schema::dropIfExists('kb_faqs');
        Schema::dropIfExists('kb_article_feedback');
        Schema::dropIfExists('kb_articles');
        Schema::dropIfExists('kb_categories');
    }
};
