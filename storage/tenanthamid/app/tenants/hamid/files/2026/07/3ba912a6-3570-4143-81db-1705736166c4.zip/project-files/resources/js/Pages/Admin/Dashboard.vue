<template>
  <div class="min-h-screen bg-gray-50 dark:bg-gray-950 p-6">
    <div class="max-w-6xl mx-auto space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Super Admin</h1>
          <p class="text-sm text-gray-500 mt-1">Manage all tenants and platform settings</p>
        </div>
      </div>

      <!-- Stats -->
      <div class="grid grid-cols-3 gap-4">
        <div class="card p-5">
          <p class="text-xs text-gray-500 uppercase tracking-wider">Total Tenants</p>
          <p class="text-3xl font-bold text-gray-900 dark:text-white mt-1">{{ stats.total_tenants }}</p>
        </div>
        <div class="card p-5">
          <p class="text-xs text-gray-500 uppercase tracking-wider">Active Tenants</p>
          <p class="text-3xl font-bold text-emerald-600 mt-1">{{ stats.active_tenants }}</p>
        </div>
        <div class="card p-5">
          <p class="text-xs text-gray-500 uppercase tracking-wider">Plans</p>
          <div class="flex gap-2 mt-2 flex-wrap">
            <span v-for="(count, plan) in stats.plans" :key="plan" class="badge badge-blue text-xs">
              {{ plan }}: {{ count }}
            </span>
          </div>
        </div>
      </div>

      <!-- Recent tenants -->
      <div class="card">
        <div class="card-header flex items-center justify-between">
          <h2 class="text-sm font-semibold text-gray-900 dark:text-white">Recent Tenants</h2>
          <Link :href="route('admin.tenants')" class="text-xs text-brand-600 hover:underline">View all</Link>
        </div>
        <div class="table-wrapper">
          <table class="table">
            <thead><tr><th>Tenant</th><th>Plan</th><th>Domains</th><th>Status</th><th>Created</th></tr></thead>
            <tbody>
              <tr v-for="t in recent_tenants" :key="t.id">
                <td>
                  <div>
                    <p class="font-medium text-gray-900 dark:text-white text-sm">{{ t.name }}</p>
                    <p class="text-xs text-gray-500">{{ t.email }}</p>
                  </div>
                </td>
                <td><span class="badge badge-purple capitalize">{{ t.plan }}</span></td>
                <td class="text-sm text-gray-600 dark:text-gray-400">{{ t.domains_count }}</td>
                <td><span :class="t.is_active ? 'badge-green' : 'badge-red'" class="badge">{{ t.is_active ? 'Active' : 'Inactive' }}</span></td>
                <td class="text-xs text-gray-500">{{ formatTime(t.created_at) }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { Link } from '@inertiajs/vue3';
import { formatTime } from '@/Utils/format';
defineProps<{ stats: any; recent_tenants: any[] }>();
</script>
