<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Inertia\Response;

class SettingsController extends Controller
{
    public function index(): Response
    {
        $settings = Setting::all()->groupBy('group');
        $tenant = tenant();

        return Inertia::render('Settings/Index', [
            'settings' => $settings,
            'tenant' => $tenant,
            'ai_providers' => config('ai.providers'),
            'current_ai_provider' => Setting::getValue('ai_provider', config('ai.default_provider')),
        ]);
    }

    public function update(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'settings' => 'required|array',
            'settings.*.key' => 'required|string',
            'settings.*.value' => 'nullable',
        ]);

        foreach ($validated['settings'] as $setting) {
            Setting::updateOrCreate(
                ['key' => $setting['key']],
                ['value' => $setting['value']]
            );
        }

        return response()->json(['success' => true]);
    }

    public function updateBranding(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'primary_color' => 'required|string|max:7',
            'secondary_color' => 'required|string|max:7',
            'logo' => 'nullable|image|max:2048',
            'favicon' => 'nullable|image|max:512',
        ]);

        $tenant = tenant();

        if ($request->hasFile('logo')) {
            $path = $request->file('logo')->store('branding', 'public');
            $validated['logo'] = $path;
        }

        if ($request->hasFile('favicon')) {
            $path = $request->file('favicon')->store('branding', 'public');
            $validated['favicon'] = $path;
        }

        $tenant->update($validated);

        return response()->json(['success' => true, 'tenant' => $tenant->fresh()]);
    }

    public function updateAiProvider(Request $request): JsonResponse
    {
        $request->validate(['provider' => 'required|in:gemini,openai,claude,ollama']);

        Setting::updateOrCreate(
            ['key' => 'ai_provider'],
            ['value' => $request->provider, 'group' => 'ai']
        );

        return response()->json(['success' => true]);
    }

    public function updateWorkingHours(Request $request): JsonResponse
    {
        $request->validate([
            'working_hours' => 'required|array',
        ]);

        Setting::updateOrCreate(
            ['key' => 'working_hours'],
            ['value' => json_encode($request->working_hours), 'group' => 'general', 'type' => 'json']
        );

        return response()->json(['success' => true]);
    }
}
