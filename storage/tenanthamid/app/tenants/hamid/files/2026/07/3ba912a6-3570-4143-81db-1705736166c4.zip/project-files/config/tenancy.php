<?php

declare(strict_types=1);

use Stancl\Tenancy\Database\Models\Domain;
use Stancl\Tenancy\Database\Models\Tenant;

return [
    'tenant_model' => \App\Models\Tenant::class,
    'id_generator' => \Stancl\Tenancy\UUIDGenerator::class,

    'domain_model' => Domain::class,

    'central_domains' => array_filter(explode(',', env('CENTRAL_DOMAINS', 'localhost'))),

    'bootstrappers' => [
        \Stancl\Tenancy\Bootstrappers\DatabaseTenancyBootstrapper::class,
        \Stancl\Tenancy\Bootstrappers\CacheTenancyBootstrapper::class,
        \Stancl\Tenancy\Bootstrappers\FilesystemTenancyBootstrapper::class,
        \Stancl\Tenancy\Bootstrappers\QueueTenancyBootstrapper::class,
        \Stancl\Tenancy\Bootstrappers\RedisTenancyBootstrapper::class,
    ],

    'database' => [
        'based_on' => env('DB_CONNECTION', 'mysql'),
        'prefix' => env('TENANCY_DATABASE_PREFIX', 'tenant_'),
        'suffix' => '',
        'managers' => [
            'sqlite' => \Stancl\Tenancy\DatabaseManagers\SQLiteDatabaseManager::class,
            'mysql' => \Stancl\Tenancy\DatabaseManagers\MySQLDatabaseManager::class,
            'pgsql' => \Stancl\Tenancy\DatabaseManagers\PostgreSQLDatabaseManager::class,
        ],
    ],

    'cache' => [
        'tag_base' => 'tenant',
    ],

    'filesystem' => [
        'suffix_base' => 'tenant',
        'disks' => [
            'local',
            'public',
            's3',
        ],
        'root_override' => [
            'local' => '%storage_path%/app/',
            'public' => '%storage_path%/app/public/',
        ],
        'suffix_storage_path' => true,
        'asset_helper_tenancy' => false,
    ],

    'redis' => [
        'prefix_base' => 'tenant',
        'prefixed_connections' => [
            'default',
            'cache',
        ],
    ],

    'features' => [
        \Stancl\Tenancy\Features\UserImpersonation::class,
        \Stancl\Tenancy\Features\TelescopeTags::class,
        \Stancl\Tenancy\Features\UniversalRoutes::class,
    ],

    'identification_middleware' => [
        \Stancl\Tenancy\Middleware\InitializeTenancyByDomain::class,
    ],

    'queue_tunnel_middleware' => [
        \Stancl\Tenancy\Middleware\InitializeTenancyByDomain::class,
    ],

    'migration_parameters' => [
        '--force' => true,
        '--realpath' => true,
        '--path' => [
            database_path('migrations/tenant'),
        ],
    ],

    'seeder_parameters' => [
        '--force' => true,
        '--class' => 'TenantDatabaseSeeder',
    ],

    'routes' => false,
];
