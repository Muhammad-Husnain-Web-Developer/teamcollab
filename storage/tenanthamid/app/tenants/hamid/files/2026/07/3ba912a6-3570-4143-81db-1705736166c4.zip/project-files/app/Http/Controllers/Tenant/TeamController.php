<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Inertia\Inertia;
use Inertia\Response;
use Spatie\Permission\Models\Role;

class TeamController extends Controller
{
    public function index(): Response
    {
        $members = User::with('roles')
            ->withCount(['tickets as open_tickets' => fn($q) => $q->where('status', 'open')])
            ->withCount(['conversations as active_conversations' => fn($q) => $q->where('status', 'open')])
            ->orderByDesc('created_at')
            ->paginate(20);

        $roles = Role::all();

        $stats = [
            'total' => User::count(),
            'online' => User::where('status', 'online')->count(),
            'agents' => User::role('agent')->count(),
            'managers' => User::role('manager')->count(),
        ];

        return Inertia::render('Team/Index', [
            'members' => $members,
            'roles' => $roles,
            'stats' => $stats,
        ]);
    }

    public function show(User $user): Response
    {
        $user->loadMissing(['roles']);

        $recentTickets = $user->tickets()->with('customer')->latest()->limit(5)->get();
        $recentConversations = $user->conversations()->with('customer')->latest()->limit(5)->get();

        $performance = [
            'tickets_resolved' => $user->tickets()->where('status', 'resolved')->count(),
            'avg_resolution_time' => $user->tickets()->whereNotNull('resolution_time')->avg('resolution_time') ?? 0,
            'conversations_handled' => $user->conversations()->count(),
            'satisfaction_avg' => \App\Models\SatisfactionRating::whereHas('conversation', fn($q) => $q->where('assigned_to', $user->id))->avg('rating') ?? 0,
        ];

        return Inertia::render('Team/Show', [
            'member' => $user,
            'recent_tickets' => $recentTickets,
            'recent_conversations' => $recentConversations,
            'performance' => $performance,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|in:agent,manager',
            'phone' => 'nullable|string|max:30',
        ]);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'phone' => $validated['phone'] ?? null,
            'is_active' => true,
        ]);

        $user->assignRole($validated['role']);
        $user->availability()->create(['status' => 'offline']);

        return response()->json(['success' => true, 'member' => $user->load('roles')], 201);
    }

    public function update(Request $request, User $user): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|email|unique:users,email,' . $user->id,
            'role' => 'sometimes|in:agent,manager',
            'phone' => 'nullable|string|max:30',
            'is_active' => 'boolean',
        ]);

        if (isset($validated['role'])) {
            $user->syncRoles([$validated['role']]);
            unset($validated['role']);
        }

        $user->update($validated);
        return response()->json(['success' => true, 'member' => $user->fresh()->load('roles')]);
    }

    public function destroy(User $user): JsonResponse
    {
        abort_if($user->id === auth()->id(), 422, 'Cannot delete yourself');
        $user->delete();
        return response()->json(['success' => true]);
    }

    public function updateStatus(Request $request): JsonResponse
    {
        $request->validate(['status' => 'required|in:online,busy,away,offline']);
        $user = auth()->user();
        $user->updateStatus($request->status);

        broadcast(new \App\Events\AgentStatusChanged($user, $request->status))->toOthers();

        return response()->json(['success' => true, 'status' => $request->status]);
    }
}
