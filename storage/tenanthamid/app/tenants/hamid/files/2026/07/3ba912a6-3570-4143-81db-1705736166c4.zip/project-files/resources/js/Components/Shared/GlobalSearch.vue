<template>
  <Teleport to="body">
    <div class="fixed inset-0 z-[200] flex items-start justify-center pt-20 px-4">
      <div class="absolute inset-0 bg-black/40 backdrop-blur-sm" @click="$emit('close')" />
      <div class="relative bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-lg border border-gray-200 dark:border-gray-700 animate-slide-down">
        <div class="flex items-center gap-3 px-4 py-3 border-b border-gray-100 dark:border-gray-800">
          <Search class="w-4 h-4 text-gray-400 flex-shrink-0" />
          <input v-model="query" @input="doSearch" ref="inputRef" placeholder="Search conversations, tickets, customers..."
                 class="flex-1 bg-transparent text-sm text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none" />
          <kbd class="text-xs text-gray-400 border border-gray-200 dark:border-gray-700 rounded px-1.5 py-0.5">Esc</kbd>
        </div>
        <div class="max-h-96 overflow-y-auto p-2">
          <div v-if="results.length === 0 && query" class="text-sm text-gray-400 text-center py-8">No results found</div>
          <div v-if="!query" class="text-sm text-gray-400 text-center py-8">Start typing to search...</div>
          <Link v-for="r in results" :key="r.url" :href="r.url" @click="$emit('close')"
                class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            <component :is="r.icon" class="w-4 h-4 text-gray-400 flex-shrink-0" />
            <div>
              <p class="text-sm text-gray-900 dark:text-white">{{ r.title }}</p>
              <p class="text-xs text-gray-500">{{ r.subtitle }}</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  </Teleport>
</template>
<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { Link } from '@inertiajs/vue3';
import { Search, MessageSquare, Ticket, Users } from 'lucide-vue-next';
import { useDebounceFn } from '@vueuse/core';
import axios from 'axios';
const emit = defineEmits<{ close: [] }>();
const query = ref(''); const results = ref<any[]>([]); const inputRef = ref<HTMLInputElement|null>(null);
onMounted(() => { inputRef.value?.focus(); });
const doSearch = useDebounceFn(async () => {
  if (query.value.length < 2) { results.value = []; return; }
  try { const { data } = await axios.get('/api/search', { params: { q: query.value } }); results.value = data.results ?? []; } catch {}
}, 300);
</script>
