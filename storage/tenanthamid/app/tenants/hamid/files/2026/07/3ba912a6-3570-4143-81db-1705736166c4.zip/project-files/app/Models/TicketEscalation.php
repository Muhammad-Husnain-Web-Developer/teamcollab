<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class TicketEscalation extends Model {
    protected $fillable = ['ticket_id','escalated_by','escalated_to','reason','notes'];
    public function ticket(): BelongsTo { return $this->belongsTo(Ticket::class); }
    public function escalatedBy(): BelongsTo { return $this->belongsTo(User::class,'escalated_by'); }
    public function escalatedTo(): BelongsTo { return $this->belongsTo(User::class,'escalated_to'); }
}
