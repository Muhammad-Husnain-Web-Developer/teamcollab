<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />

    <title inertia>{{ config('app.name', 'AI Support') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://rsms.me" />

    <!-- Favicon -->
    @if(tenancy()->initialized && tenant('favicon'))
        <link rel="icon" href="{{ asset('storage/' . tenant('favicon')) }}" />
    @else
        <link rel="icon" href="/favicon.ico" />
    @endif

    <!-- Tenant branding injection -->
    @if(tenancy()->initialized)
    <style>
        :root {
            --color-brand: {{ hexToRgb(tenant('primary_color', '#6366f1')) }};
        }
    </style>
    @endif

    @routes
    @vite(['resources/js/app.ts'])
    @inertiaHead
</head>
<body class="font-sans antialiased">
    @inertia
</body>
</html>
