<template>
    <div class="flex h-screen overflow-hidden" :class="{ dark: isDark }">
        <!-- Sidebar -->
        <aside
            class="flex flex-col w-64 flex-shrink-0 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800"
            :class="{ '-translate-x-full': !sidebarOpen, 'translate-x-0': sidebarOpen }"
        >
            <!-- Logo -->
            <div class="flex items-center gap-3 px-5 h-16 border-b border-gray-100 dark:border-gray-800">
                <div class="w-8 h-8 bg-gradient-to-br from-brand-500 to-violet-600 rounded-lg flex items-center justify-center">
                    <Zap class="w-4 h-4 text-white" />
                </div>
                <span class="font-bold text-gray-900 dark:text-white text-sm tracking-tight">AI Support</span>
                <span class="ml-auto">
                    <button @click="toggleDark" class="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500">
                        <Sun v-if="isDark" class="w-4 h-4" />
                        <Moon v-else class="w-4 h-4" />
                    </button>
                </span>
            </div>

            <!-- Agent status -->
            <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                <div class="flex items-center gap-2.5">
                    <div class="relative">
                        <img :src="authUser?.avatar_url" :alt="authUser?.name" class="w-8 h-8 rounded-full object-cover" />
                        <span class="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white dark:border-gray-900"
                              :class="statusColor" />
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-xs font-semibold text-gray-900 dark:text-white truncate">{{ authUser?.name }}</p>
                        <select @change="updateStatus($event.target.value)" :value="currentStatus"
                                class="text-xs text-gray-500 dark:text-gray-400 bg-transparent border-none p-0 focus:ring-0 cursor-pointer">
                            <option value="online">Online</option>
                            <option value="busy">Busy</option>
                            <option value="away">Away</option>
                            <option value="offline">Offline</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Nav -->
            <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
                <NavItem :href="route('tenant.dashboard')" :icon="LayoutDashboard" label="Dashboard" />
                <NavItem :href="route('tenant.conversations.index')" :icon="MessageSquare" label="Conversations">
                    <template #badge>
                        <span v-if="openConversations > 0"
                              class="ml-auto text-xs font-medium bg-brand-100 text-brand-700 dark:bg-brand-900/30 dark:text-brand-400 px-1.5 py-0.5 rounded-full">
                            {{ openConversations }}
                        </span>
                    </template>
                </NavItem>
                <NavItem :href="route('tenant.tickets.index')" :icon="Ticket" label="Tickets">
                    <template #badge>
                        <span v-if="openTickets > 0"
                              class="ml-auto text-xs font-medium bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 px-1.5 py-0.5 rounded-full">
                            {{ openTickets }}
                        </span>
                    </template>
                </NavItem>
                <NavItem :href="route('tenant.customers.index')" :icon="Users" label="Customers" />
                <NavItem :href="route('tenant.kb.index')" :icon="BookOpen" label="Knowledge Base" />

                <div class="pt-3 pb-1">
                    <p class="px-3 text-xs font-semibold text-gray-400 dark:text-gray-600 uppercase tracking-wider">Manage</p>
                </div>
                <NavItem :href="route('tenant.team.index')" :icon="UserCheck" label="Team" />
                <NavItem :href="route('tenant.analytics')" :icon="BarChart3" label="Analytics" />
                <NavItem :href="route('tenant.subscription.index')" :icon="CreditCard" label="Subscription" />
                <NavItem :href="route('tenant.settings.index')" :icon="Settings" label="Settings" />
            </nav>

            <!-- Bottom section -->
            <div class="px-3 py-3 border-t border-gray-100 dark:border-gray-800">
                <Link :href="route('logout')" method="post" as="button"
                      class="flex items-center gap-2.5 w-full px-3 py-2 text-sm text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-lg transition-colors">
                    <LogOut class="w-4 h-4" />
                    Sign out
                </Link>
            </div>
        </aside>

        <!-- Main content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Top bar -->
            <header class="h-16 flex items-center gap-4 px-6 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 flex-shrink-0">
                <button @click="sidebarOpen = !sidebarOpen" class="btn-ghost btn-sm lg:hidden">
                    <Menu class="w-5 h-5" />
                </button>

                <!-- Breadcrumbs slot -->
                <slot name="header" />

                <div class="ml-auto flex items-center gap-2">
                    <!-- Notifications -->
                    <NotificationBell />

                    <!-- Search -->
                    <button class="btn-ghost btn-sm hidden md:flex" @click="showSearch = true">
                        <Search class="w-4 h-4" />
                        <span class="text-xs text-gray-400">⌘K</span>
                    </button>
                </div>
            </header>

            <!-- Page content -->
            <main class="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-950">
                <slot />
            </main>
        </div>

        <!-- Global Search Modal -->
        <GlobalSearch v-if="showSearch" @close="showSearch = false" />

        <!-- Toast notifications -->
        <ToastContainer />
    </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { Link, usePage } from '@inertiajs/vue3';
import {
    LayoutDashboard, MessageSquare, Ticket, Users, BookOpen,
    UserCheck, BarChart3, CreditCard, Settings, LogOut,
    Zap, Moon, Sun, Menu, Search
} from 'lucide-vue-next';
import { useStorage } from '@vueuse/core';
import NavItem from '@/Components/Shared/NavItem.vue';
import NotificationBell from '@/Components/Shared/NotificationBell.vue';
import GlobalSearch from '@/Components/Shared/GlobalSearch.vue';
import ToastContainer from '@/Components/UI/ToastContainer.vue';
import { useAgentStatus } from '@/Composables/useAgentStatus';
import axios from 'axios';

const page = usePage();
const authUser = computed(() => page.props.auth?.user);
const isDark = useStorage('dark-mode', false);
const sidebarOpen = ref(true);
const showSearch = ref(false);

const { currentStatus, updateStatus } = useAgentStatus();

const openConversations = computed(() => (page.props as any).open_conversations ?? 0);
const openTickets = computed(() => (page.props as any).open_tickets ?? 0);

const statusColor = computed(() => ({
    online: 'bg-emerald-500',
    busy: 'bg-amber-500',
    away: 'bg-gray-400',
    offline: 'bg-gray-300',
}[currentStatus.value] || 'bg-gray-300'));

function toggleDark() {
    isDark.value = !isDark.value;
    document.documentElement.classList.toggle('dark', isDark.value);
}

// Apply dark mode on mount
if (isDark.value) document.documentElement.classList.add('dark');
</script>
