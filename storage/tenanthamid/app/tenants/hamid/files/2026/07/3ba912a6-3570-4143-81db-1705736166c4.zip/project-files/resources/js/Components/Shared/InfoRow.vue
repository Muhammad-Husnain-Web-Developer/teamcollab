<template>
  <div class="flex justify-between items-center">
    <span class="text-xs text-gray-500 dark:text-gray-400">{{ label }}</span>
    <span class="text-xs font-medium text-gray-800 dark:text-gray-200 capitalize">{{ value }}</span>
  </div>
</template>
<script setup lang="ts">
defineProps<{ label: string; value: any }>();
</script>
