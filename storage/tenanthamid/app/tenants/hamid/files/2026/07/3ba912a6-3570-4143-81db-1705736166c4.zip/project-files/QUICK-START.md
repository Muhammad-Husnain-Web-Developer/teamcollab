# 🚀 Quick Start Guide — Run in 5 Minutes

## Prerequisites (install these first)

| Tool | Download | Version Needed |
|------|----------|----------------|
| PHP | https://www.php.net/downloads OR https://www.apachefriends.org (XAMPP) | 8.2+ |
| Composer | https://getcomposer.org | 2.x |
| Node.js | https://nodejs.org | 18+ |

> **MySQL/Redis are NOT required** for local development. We use SQLite + file drivers.

---

## 🖥️ Mac / Linux — One Command Setup

```bash
bash setup.sh
```

Then start the app:
```bash
php artisan serve
```

Open browser: **http://localhost:8000**

---

## 🪟 Windows — One Click Setup

1. Double-click **`setup-windows.bat`**
2. Wait for it to finish
3. Run: `php artisan serve`
4. Open: **http://localhost:8000**

---

## 🔑 Login Credentials

| Field    | Value               |
|----------|---------------------|
| Email    | owner@example.com   |
| Password | password            |

---

## 📋 Manual Steps (if script fails)

```bash
# 1. Install packages
composer install
npm install

# 2. Setup environment
cp .env.example .env
php artisan key:generate

# 3. Create SQLite database
touch database/database.sqlite

# 4. Edit .env — set SQLite:
#    DB_CONNECTION=sqlite
#    QUEUE_CONNECTION=sync
#    CACHE_STORE=file
#    SESSION_DRIVER=file

# 5. Run migrations
php artisan migrate --path=database/migrations/central --force

# 6. Create demo tenant (copy-paste into terminal)
php artisan tinker
```

Inside tinker, paste this:
```php
use App\Models\Tenant;
use Illuminate\Support\Str;

$tenant = Tenant::create([
    'id'    => Str::uuid()->toString(),
    'name'  => 'Demo Company',
    'slug'  => 'demo',
    'email' => 'demo@example.com',
    'plan'  => 'professional',
    'is_active' => true,
]);

$tenant->domains()->create(['domain' => 'localhost']);

tenancy()->initialize($tenant);
Artisan::call('migrate', ['--path' => 'database/migrations/tenant', '--force' => true]);
Artisan::call('db:seed', ['--class' => 'TenantDatabaseSeeder', '--force' => true]);
tenancy()->end();

echo "Done! Login: owner@example.com / password\n";
exit;
```

```bash
# 7. Build frontend
npm run build

# 8. Start server
php artisan serve
```

---

## ⚙️ Optional Features

### AI Responses (Required for AI chat)
Get a **free** Gemini API key:
1. Go to https://aistudio.google.com/apikey
2. Click "Create API Key"
3. Add to `.env`: `GEMINI_API_KEY=your_key_here`
4. Restart server

### Real-Time (WebSockets)
```bash
# Terminal 1: Start Reverb WebSocket server
php artisan reverb:start

# Terminal 2: Start queue worker
php artisan queue:work

# Terminal 3: Start app
php artisan serve
```

### Hot Reload (Development)
```bash
# Terminal 1:
npm run dev

# Terminal 2:
php artisan serve
```

---

## 🎯 What You Can Do

After logging in at http://localhost:8000:

- 💬 **Live Chat** → Conversations tab → New conversations with AI
- 🎫 **Tickets** → Create and manage support tickets
- 👥 **Customers** → Add and manage customer profiles
- 📚 **Knowledge Base** → Create articles, FAQs
- 👤 **Team** → Invite agents, set roles
- 📊 **Analytics** → View dashboard metrics
- ⚙️ **Settings** → Configure AI provider, branding
- 💳 **Subscription** → View plan features

---

## 🐛 Common Issues

**"Class not found" errors:**
```bash
composer dump-autoload
```

**Blank page / 500 error:**
```bash
php artisan config:clear
php artisan cache:clear
php artisan view:clear
```

**Migrations fail:**
```bash
# Make sure database/database.sqlite exists
touch database/database.sqlite
php artisan migrate:fresh --path=database/migrations/central --force
```

**npm run build fails:**
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```
