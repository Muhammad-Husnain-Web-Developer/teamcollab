<?php

namespace Database\Seeders;

use App\Models\Tenant;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class SuperAdminSeeder extends Seeder
{
    public function run(): void
    {
        // Create a demo tenant
        $tenant = Tenant::firstOrCreate(
            ['email' => 'demo@example.com'],
            [
                'id' => Str::uuid()->toString(),
                'name' => 'Demo Company',
                'slug' => 'demo',
                'email' => 'demo@example.com',
                'plan' => 'professional',
                'is_active' => true,
                'primary_color' => '#6366f1',
                'secondary_color' => '#8b5cf6',
            ]
        );

        $domain = config('tenancy.central_domains')[0] ?? 'localhost';
        $tenant->domains()->firstOrCreate(['domain' => 'demo.' . $domain]);

        $this->command->info("Demo tenant created: demo.{$domain}");
    }
}
