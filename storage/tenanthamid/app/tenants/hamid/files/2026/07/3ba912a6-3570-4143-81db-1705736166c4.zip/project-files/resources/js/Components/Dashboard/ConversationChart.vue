<template>
  <div class="w-full">
    <div v-if="!data?.length" class="h-48 flex items-center justify-center text-sm text-gray-400">No data yet</div>
    <svg v-else :viewBox="`0 0 ${w} ${h}`" class="w-full h-48" preserveAspectRatio="none">
      <defs>
        <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#6366f1" stop-opacity="0.3"/>
          <stop offset="100%" stop-color="#6366f1" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <path :d="areaPath" fill="url(#grad)" />
      <path :d="linePath" fill="none" stroke="#6366f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      <g v-for="(p, i) in points" :key="i">
        <circle :cx="p.x" :cy="p.y" r="3" fill="#6366f1" />
        <text :x="p.x" :y="h-2" text-anchor="middle" font-size="9" fill="currentColor" class="text-gray-400">{{ p.label }}</text>
      </g>
    </svg>
  </div>
</template>
<script setup lang="ts">
import { computed } from 'vue';
const props = defineProps<{ data: any[] }>();
const w = 600; const h = 180; const pad = 20;
const maxVal = computed(() => Math.max(...(props.data?.map(d => d.total) ?? [1]), 1));
const points = computed(() => (props.data ?? []).map((d, i) => {
  const x = pad + (i / Math.max(props.data.length - 1, 1)) * (w - pad * 2);
  const y = h - pad - ((d.total / maxVal.value) * (h - pad * 2));
  return { x, y, label: d.date?.slice(5) ?? '' };
}));
const linePath = computed(() => points.value.map((p, i) => `${i===0?'M':'L'}${p.x},${p.y}`).join(' '));
const areaPath = computed(() => {
  if (!points.value.length) return '';
  const line = points.value.map((p, i) => `${i===0?'M':'L'}${p.x},${p.y}`).join(' ');
  const last = points.value[points.value.length-1]; const first = points.value[0];
  return `${line} L${last.x},${h-pad} L${first.x},${h-pad} Z`;
});
</script>
