<?php

namespace Tests\Feature\Ticket;

use App\Models\Customer;
use App\Models\Ticket;
use App\Models\TicketCategory;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class TicketTest extends TestCase
{
    use RefreshDatabase;

    protected User $agent;
    protected Customer $customer;

    protected function setUp(): void
    {
        parent::setUp();
        $this->agent    = User::factory()->create();
        $this->agent->assignRole('agent');
        $this->customer = Customer::factory()->create();
    }

    public function test_agent_can_list_tickets(): void
    {
        Ticket::factory()->count(5)->create(['customer_id' => $this->customer->id]);

        $this->actingAs($this->agent)
            ->get(route('tenant.tickets.index'))
            ->assertOk()
            ->assertInertia(fn ($p) => $p->component('Tickets/Index')->has('tickets'));
    }

    public function test_agent_can_create_ticket(): void
    {
        $category = TicketCategory::factory()->create();

        $this->actingAs($this->agent)
            ->postJson(route('tenant.tickets.store'), [
                'subject'     => 'Cannot login to my account',
                'description' => 'I am unable to login since yesterday.',
                'customer_id' => $this->customer->id,
                'priority'    => 'high',
                'category_id' => $category->id,
            ])
            ->assertStatus(201)
            ->assertJsonStructure(['success', 'ticket' => ['id', 'ticket_number']]);

        $this->assertDatabaseHas('tickets', [
            'subject'     => 'Cannot login to my account',
            'customer_id' => $this->customer->id,
        ]);
    }

    public function test_ticket_number_is_auto_generated(): void
    {
        $ticket = Ticket::factory()->create(['customer_id' => $this->customer->id]);
        $this->assertStringStartsWith('TKT-', $ticket->ticket_number);
    }

    public function test_agent_can_update_ticket_status(): void
    {
        $ticket = Ticket::factory()->open()->create(['customer_id' => $this->customer->id]);

        $this->actingAs($this->agent)
            ->putJson(route('tenant.tickets.update', $ticket->id), ['status' => 'resolved'])
            ->assertOk();

        $this->assertDatabaseHas('tickets', ['id' => $ticket->id, 'status' => 'resolved']);
    }

    public function test_agent_can_reply_to_ticket(): void
    {
        $ticket = Ticket::factory()->open()->create(['customer_id' => $this->customer->id]);

        $this->actingAs($this->agent)
            ->postJson(route('tenant.tickets.reply', $ticket->id), ['content' => 'We are looking into this issue.'])
            ->assertStatus(201);

        $this->assertDatabaseHas('ticket_replies', [
            'ticket_id' => $ticket->id,
            'user_id'   => $this->agent->id,
            'content'   => 'We are looking into this issue.',
        ]);
    }

    public function test_agent_can_delete_ticket(): void
    {
        $ticket = Ticket::factory()->create(['customer_id' => $this->customer->id]);

        $this->actingAs($this->agent)
            ->deleteJson(route('tenant.tickets.destroy', $ticket->id))
            ->assertOk();

        $this->assertSoftDeleted('tickets', ['id' => $ticket->id]);
    }
}
