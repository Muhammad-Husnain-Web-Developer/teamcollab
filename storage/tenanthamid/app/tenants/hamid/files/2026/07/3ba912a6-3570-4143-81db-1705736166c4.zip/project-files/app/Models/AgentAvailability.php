<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AgentAvailability extends Model
{
    protected $table = 'agent_availability';
    protected $fillable = ['user_id', 'status', 'max_conversations', 'current_conversations', 'last_updated_at'];
    protected $casts = ['last_updated_at' => 'datetime'];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function isAvailable(): bool
    {
        return $this->status === 'online' && $this->current_conversations < $this->max_conversations;
    }
}
