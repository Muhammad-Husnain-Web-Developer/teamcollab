<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class AiConversation extends Model {
    protected $fillable = ['conversation_id','provider','model','context','prompt_tokens','completion_tokens','confidence_score','escalated','escalated_at'];
    protected $casts = ['context'=>'array','escalated'=>'boolean','escalated_at'=>'datetime'];
    public function conversation(): BelongsTo { return $this->belongsTo(Conversation::class); }
}
