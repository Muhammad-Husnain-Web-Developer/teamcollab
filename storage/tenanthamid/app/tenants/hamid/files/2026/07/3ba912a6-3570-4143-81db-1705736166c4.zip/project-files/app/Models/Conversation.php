<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

class Conversation extends Model
{
    use HasFactory, SoftDeletes, LogsActivity;

    protected $fillable = [
        'uuid',
        'customer_id',
        'assigned_to',
        'status',
        'type',
        'channel',
        'priority',
        'labels',
        'tags',
        'subject',
        'first_response_at',
        'resolved_at',
        'last_activity_at',
        'message_count',
        'is_read',
        'meta',
    ];

    protected $casts = [
        'labels' => 'array',
        'tags' => 'array',
        'meta' => 'array',
        'first_response_at' => 'datetime',
        'resolved_at' => 'datetime',
        'last_activity_at' => 'datetime',
        'is_read' => 'boolean',
    ];

    protected static function boot(): void
    {
        parent::boot();
        static::creating(function (self $model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid()->toString();
            }
        });
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['status', 'assigned_to', 'priority'])
            ->logOnlyDirty();
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function assignedTo(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function messages(): HasMany
    {
        return $this->hasMany(Message::class);
    }

    public function publicMessages(): HasMany
    {
        return $this->hasMany(Message::class)->where('is_internal', false);
    }

    public function internalNotes(): HasMany
    {
        return $this->hasMany(Message::class)->where('is_internal', true);
    }

    public function lastMessage(): HasOne
    {
        return $this->hasOne(Message::class)->latestOfMany();
    }

    public function participants(): HasMany
    {
        return $this->hasMany(ConversationParticipant::class);
    }

    public function ticket(): HasOne
    {
        return $this->hasOne(Ticket::class);
    }

    public function aiConversation(): HasOne
    {
        return $this->hasOne(AiConversation::class);
    }

    public function satisfactionRating(): HasOne
    {
        return $this->hasOne(SatisfactionRating::class);
    }

    public function scopeOpen($query)
    {
        return $query->where('status', 'open');
    }

    public function scopeAssignedTo($query, int $userId)
    {
        return $query->where('assigned_to', $userId);
    }

    public function scopeAiType($query)
    {
        return $query->where('type', 'ai');
    }

    public function isOpen(): bool
    {
        return $this->status === 'open';
    }

    public function isResolved(): bool
    {
        return in_array($this->status, ['resolved', 'closed']);
    }

    public function isAiHandled(): bool
    {
        return $this->type === 'ai';
    }

    public function escalateToHuman(?int $agentId = null): void
    {
        $this->update([
            'type' => 'human',
            'assigned_to' => $agentId,
            'status' => 'open',
        ]);

        if ($this->aiConversation) {
            $this->aiConversation->update([
                'escalated' => true,
                'escalated_at' => now(),
            ]);
        }
    }
}
