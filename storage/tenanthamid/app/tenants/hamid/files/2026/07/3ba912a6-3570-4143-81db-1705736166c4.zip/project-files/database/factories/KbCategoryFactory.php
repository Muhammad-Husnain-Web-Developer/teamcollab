<?php

namespace Database\Factories;

use App\Models\KbCategory;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class KbCategoryFactory extends Factory
{
    protected $model = KbCategory::class;

    public function definition(): array
    {
        $name = fake()->words(2, true);
        return [
            'name'      => ucwords($name),
            'slug'      => Str::slug($name) . '-' . fake()->unique()->numberBetween(1, 9999),
            'description' => fake()->sentence(),
            'color'     => fake()->hexColor(),
            'is_public' => true,
            'is_active' => true,
            'order'     => fake()->numberBetween(0, 10),
        ];
    }
}
