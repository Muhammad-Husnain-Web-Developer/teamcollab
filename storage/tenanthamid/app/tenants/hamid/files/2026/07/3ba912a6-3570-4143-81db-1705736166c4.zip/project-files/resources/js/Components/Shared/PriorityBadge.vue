<template>
  <span :class="['priority-'+priority]">{{ priority }}</span>
</template>
<script setup lang="ts">
defineProps<{ priority: string }>();
</script>
