<template>
  <div class="fixed bottom-5 right-5 z-[100] flex flex-col gap-2 min-w-72 pointer-events-none">
    <TransitionGroup name="toast" tag="div" class="space-y-2">
      <div v-for="t in toasts" :key="t.id" class="pointer-events-auto"
           :class="['flex items-start gap-3 px-4 py-3 rounded-xl shadow-lg text-sm font-medium border', typeClass(t.type)]">
        <component :is="icon(t.type)" class="w-4 h-4 flex-shrink-0 mt-0.5" />
        <span class="flex-1">{{ t.message }}</span>
        <button @click="remove(t.id)" class="opacity-60 hover:opacity-100"><X class="w-3.5 h-3.5"/></button>
      </div>
    </TransitionGroup>
  </div>
</template>
<script setup lang="ts">
import { CheckCircle, AlertCircle, Info, X } from 'lucide-vue-next';
import { useToast } from '@/Composables/useToast';
const { toasts, remove } = useToast();
function typeClass(t: string) {
  return { success:'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-800',
           error:'bg-red-50 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-800',
           info:'bg-blue-50 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800',
           warning:'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800' }[t] ?? '';
}
function icon(t: string) { return { success:CheckCircle, error:AlertCircle, info:Info, warning:AlertCircle }[t] ?? Info; }
</script>
<style scoped>
.toast-enter-active,.toast-leave-active{transition:all .3s ease}
.toast-enter-from,.toast-leave-to{opacity:0;transform:translateX(100%)}
</style>
