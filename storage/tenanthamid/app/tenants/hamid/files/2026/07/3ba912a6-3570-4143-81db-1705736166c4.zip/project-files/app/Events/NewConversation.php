<?php

namespace App\Events;

use App\Models\Conversation;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class NewConversation implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public readonly Conversation $conversation) {}

    public function broadcastOn(): array
    {
        return [
            new Channel('conversations'),
        ];
    }

    public function broadcastAs(): string
    {
        return 'conversation.new';
    }

    public function broadcastWith(): array
    {
        $this->conversation->loadMissing('customer');
        return [
            'id' => $this->conversation->id,
            'uuid' => $this->conversation->uuid,
            'status' => $this->conversation->status,
            'type' => $this->conversation->type,
            'priority' => $this->conversation->priority,
            'channel' => $this->conversation->channel,
            'customer' => [
                'id' => $this->conversation->customer->id,
                'name' => $this->conversation->customer->name,
                'email' => $this->conversation->customer->email,
                'avatar_url' => $this->conversation->customer->avatar_url,
            ],
            'created_at' => $this->conversation->created_at->toISOString(),
        ];
    }
}
