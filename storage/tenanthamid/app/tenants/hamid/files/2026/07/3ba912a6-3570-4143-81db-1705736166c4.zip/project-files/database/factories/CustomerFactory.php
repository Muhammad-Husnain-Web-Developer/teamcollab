<?php

namespace Database\Factories;

use App\Models\Customer;
use Illuminate\Database\Eloquent\Factories\Factory;

class CustomerFactory extends Factory
{
    protected $model = Customer::class;

    public function definition(): array
    {
        return [
            'name'         => fake()->name(),
            'email'        => fake()->unique()->safeEmail(),
            'phone'        => fake()->optional()->phoneNumber(),
            'company'      => fake()->optional()->company(),
            'location'     => fake()->optional()->city(),
            'timezone'     => 'UTC',
            'language'     => 'en',
            'status'       => 'active',
            'source'       => fake()->randomElement(['web', 'api', 'email', 'widget']),
            'last_seen_at' => fake()->dateTimeBetween('-30 days', 'now'),
            'tags'         => fake()->optional()->randomElements(['vip', 'enterprise', 'trial', 'churned'], 2),
        ];
    }
}
