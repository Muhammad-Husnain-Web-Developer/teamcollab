<template>
    <Link :href="href"
          class="sidebar-link"
          :class="{ 'active': isActive }">
        <component :is="icon" class="w-4 h-4 flex-shrink-0" />
        <span class="flex-1">{{ label }}</span>
        <slot name="badge" />
    </Link>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { Link, usePage } from '@inertiajs/vue3';

const props = defineProps<{
    href: string;
    icon: any;
    label: string;
}>();

const page = usePage();
const isActive = computed(() => page.url.startsWith(new URL(props.href, window.location.origin).pathname));
</script>
