<template>
    <AppLayout>
        <template #header>
            <div class="flex items-center gap-2 text-sm">
                <Link :href="route('tenant.tickets.index')" class="text-gray-500 hover:text-gray-700 dark:text-gray-400">Tickets</Link>
                <ChevronRight class="w-3.5 h-3.5 text-gray-400" />
                <span class="font-mono text-brand-600 dark:text-brand-400 font-semibold">{{ ticket.ticket_number }}</span>
                <TicketStatusBadge :status="ticket.status" />
                <span :class="'priority-'+ticket.priority">{{ ticket.priority }}</span>
            </div>
        </template>

        <div class="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Main content -->
            <div class="lg:col-span-2 space-y-4">
                <!-- Ticket detail -->
                <div class="card">
                    <div class="card-header flex items-center justify-between">
                        <h2 class="text-base font-semibold text-gray-900 dark:text-white">{{ ticket.subject }}</h2>
                        <div class="flex gap-2">
                            <button v-if="ticket.status !== 'resolved'" @click="updateStatus('resolved')" class="btn-primary btn-sm">
                                <CheckCircle class="w-3.5 h-3.5" /> Resolve
                            </button>
                            <button v-if="ticket.status === 'open'" @click="updateStatus('in_progress')" class="btn-secondary btn-sm">
                                Start Progress
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="prose prose-sm dark:prose-invert max-w-none" v-html="ticket.description" />
                    </div>
                </div>

                <!-- Replies -->
                <div class="space-y-3">
                    <div v-for="reply in replies" :key="reply.id"
                         :class="['card overflow-hidden', reply.is_internal ? 'border-amber-200 dark:border-amber-800' : '']">
                        <div :class="['px-4 py-2.5 flex items-center gap-3 border-b', reply.is_internal ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-100 dark:border-amber-800' : 'bg-gray-50 dark:bg-gray-800/50 border-gray-100 dark:border-gray-800']">
                            <img :src="`https://ui-avatars.com/api/?name=${reply.user?.name ?? reply.customer?.name ?? 'U'}&background=6366f1&color=fff&size=28`"
                                 class="w-7 h-7 rounded-full" />
                            <div>
                                <span class="text-sm font-medium text-gray-900 dark:text-white">{{ reply.user?.name ?? reply.customer?.name ?? 'Unknown' }}</span>
                                <span class="text-xs text-gray-500 ml-2">{{ formatDateTime(reply.created_at) }}</span>
                            </div>
                            <span v-if="reply.is_internal" class="ml-auto badge badge-yellow text-xs flex items-center gap-1">
                                <Lock class="w-3 h-3" /> Internal Note
                            </span>
                        </div>
                        <div class="p-4 prose prose-sm dark:prose-invert max-w-none" v-html="reply.content" />
                    </div>
                </div>

                <!-- Reply form -->
                <div class="card">
                    <div class="card-header">
                        <div class="flex gap-2">
                            <button @click="replyInternal = false" :class="['btn-sm', !replyInternal ? 'btn-primary' : 'btn-ghost']">Reply</button>
                            <button @click="replyInternal = true" :class="['btn-sm flex items-center gap-1', replyInternal ? 'btn-secondary border-amber-300 text-amber-700' : 'btn-ghost']">
                                <Lock class="w-3 h-3" /> Internal Note
                            </button>
                        </div>
                    </div>
                    <div class="card-body space-y-3">
                        <textarea v-model="replyContent" rows="4" :placeholder="replyInternal ? 'Write internal note (only visible to agents)...' : 'Write your reply...'"
                                  :class="['input resize-none', replyInternal ? 'border-amber-300 dark:border-amber-700 bg-amber-50/30' : '']" />
                        <div class="flex justify-end gap-2">
                            <button class="btn-secondary btn-sm"><Paperclip class="w-3.5 h-3.5" /> Attach</button>
                            <button @click="submitReply" :disabled="!replyContent.trim() || submitting" class="btn-primary btn-sm">
                                <Spinner v-if="submitting" size="sm" />
                                <Send v-else class="w-3.5 h-3.5" />
                                Send Reply
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="space-y-4">
                <!-- Details card -->
                <div class="card">
                    <div class="card-header"><h3 class="text-sm font-semibold text-gray-900 dark:text-white">Details</h3></div>
                    <div class="p-4 space-y-3">
                        <!-- Assign -->
                        <div>
                            <label class="label text-xs">Assigned To</label>
                            <select @change="assignTicket($event.target.value)" :value="ticket.assigned_to ?? ''" class="input text-sm">
                                <option value="">Unassigned</option>
                                <option v-for="a in agents" :key="a.id" :value="a.id">{{ a.name }}</option>
                            </select>
                        </div>
                        <!-- Status -->
                        <div>
                            <label class="label text-xs">Status</label>
                            <select @change="updateStatus($event.target.value)" :value="ticket.status" class="input text-sm">
                                <option value="open">Open</option><option value="in_progress">In Progress</option>
                                <option value="waiting">Waiting</option><option value="resolved">Resolved</option>
                                <option value="closed">Closed</option>
                            </select>
                        </div>
                        <!-- Priority -->
                        <div>
                            <label class="label text-xs">Priority</label>
                            <select @change="updatePriority($event.target.value)" :value="ticket.priority" class="input text-sm">
                                <option v-for="p in ['low','normal','high','urgent','critical']" :key="p" :value="p">{{ p.charAt(0).toUpperCase()+p.slice(1) }}</option>
                            </select>
                        </div>
                        <!-- Category -->
                        <div>
                            <label class="label text-xs">Category</label>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ ticket.category?.name ?? '—' }}</p>
                        </div>
                        <div class="border-t border-gray-100 dark:border-gray-800 pt-3 space-y-2">
                            <InfoRow label="Created"  :value="formatDateTime(ticket.created_at)" />
                            <InfoRow label="Updated"  :value="formatDateTime(ticket.updated_at)" />
                            <InfoRow v-if="ticket.resolved_at" label="Resolved" :value="formatDateTime(ticket.resolved_at)" />
                            <InfoRow v-if="ticket.response_time" label="First Response" :value="formatDuration(ticket.response_time)" />
                            <InfoRow v-if="ticket.resolution_time" label="Resolution" :value="formatDuration(ticket.resolution_time)" />
                        </div>
                    </div>
                </div>

                <!-- Customer card -->
                <div class="card">
                    <div class="card-header"><h3 class="text-sm font-semibold text-gray-900 dark:text-white">Customer</h3></div>
                    <div class="p-4">
                        <div class="flex items-center gap-3 mb-3">
                            <img :src="ticket.customer?.avatar_url" class="w-10 h-10 rounded-full" />
                            <div>
                                <p class="text-sm font-semibold text-gray-900 dark:text-white">{{ ticket.customer?.name }}</p>
                                <p class="text-xs text-gray-500">{{ ticket.customer?.email }}</p>
                            </div>
                        </div>
                        <Link :href="route('tenant.customers.show', ticket.customer_id)" class="btn-secondary btn-sm w-full justify-center">
                            View Profile
                        </Link>
                    </div>
                </div>

                <!-- Escalate -->
                <div class="card">
                    <div class="card-body">
                        <button @click="showEscalate = true" class="btn-danger btn-sm w-full justify-center">
                            <ArrowUp class="w-3.5 h-3.5" /> Escalate
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Escalate Modal -->
        <Modal :show="showEscalate" title="Escalate Ticket" @close="showEscalate = false">
            <div class="space-y-3">
                <div>
                    <label class="label">Reason *</label>
                    <textarea v-model="escalateForm.reason" rows="3" class="input resize-none" placeholder="Why are you escalating this ticket?" />
                </div>
                <div>
                    <label class="label">Escalate To</label>
                    <select v-model="escalateForm.escalated_to" class="input">
                        <option value="">Select agent (optional)</option>
                        <option v-for="a in agents" :key="a.id" :value="a.id">{{ a.name }}</option>
                    </select>
                </div>
            </div>
            <template #footer>
                <button @click="showEscalate = false" class="btn-secondary btn-sm">Cancel</button>
                <button @click="submitEscalation" :disabled="!escalateForm.reason" class="btn-danger btn-sm">Escalate</button>
            </template>
        </Modal>
    </AppLayout>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import { ChevronRight, CheckCircle, Lock, Paperclip, Send, ArrowUp } from 'lucide-vue-next';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import TicketStatusBadge from '@/Components/Tickets/TicketStatusBadge.vue';
import InfoRow from '@/Components/Shared/InfoRow.vue';
import Modal from '@/Components/UI/Modal.vue';
import Spinner from '@/Components/UI/Spinner.vue';
import { formatDateTime, formatDuration } from '@/Utils/format';
import { useToast } from '@/Composables/useToast';

const props = defineProps<{ ticket: any; replies: any[]; agents: any[] }>();
const { toast } = useToast();
const replyContent = ref('');
const replyInternal = ref(false);
const submitting = ref(false);
const showEscalate = ref(false);
const escalateForm = reactive({ reason: '', escalated_to: '' });

async function submitReply() {
    submitting.value = true;
    try {
        await axios.post(route('tenant.tickets.reply', props.ticket.id), { content: replyContent.value, is_internal: replyInternal.value });
        replyContent.value = '';
        router.reload({ only: ['replies', 'ticket'] });
        toast.success('Reply sent!');
    } catch { toast.error('Failed to send reply'); }
    finally { submitting.value = false; }
}
async function updateStatus(status: string) {
    await axios.put(route('tenant.tickets.update', props.ticket.id), { status });
    router.reload({ only: ['ticket'] });
    toast.success('Status updated');
}
async function updatePriority(priority: string) {
    await axios.put(route('tenant.tickets.update', props.ticket.id), { priority });
    router.reload({ only: ['ticket'] });
}
async function assignTicket(userId: string) {
    await axios.put(route('tenant.tickets.update', props.ticket.id), { assigned_to: userId || null });
    router.reload({ only: ['ticket'] });
    toast.success('Ticket assigned');
}
async function submitEscalation() {
    await axios.post(route('tenant.tickets.escalate', props.ticket.id), escalateForm);
    showEscalate.value = false;
    router.reload();
    toast.success('Ticket escalated');
}
</script>
