<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo,HasMany};
class KbCategory extends Model {
    protected $table = 'kb_categories';
    protected $fillable = ['parent_id','name','slug','description','icon','color','order','is_public','is_active'];
    protected $casts = ['is_public'=>'boolean','is_active'=>'boolean'];
    public function parent(): BelongsTo { return $this->belongsTo(KbCategory::class,'parent_id'); }
    public function children(): HasMany { return $this->hasMany(KbCategory::class,'parent_id'); }
    public function articles(): HasMany { return $this->hasMany(KbArticle::class,'category_id'); }
}
