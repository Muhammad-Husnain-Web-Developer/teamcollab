<template>
    <AppLayout>
        <template #header>
            <h1 class="text-sm font-semibold text-gray-900 dark:text-white">Tickets</h1>
        </template>

        <div class="p-6 space-y-5">
            <!-- Stats bar -->
            <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <StatPill v-for="s in statPills" :key="s.label" :label="s.label" :value="s.value" :color="s.color" />
            </div>

            <!-- Toolbar -->
            <div class="card">
                <div class="card-body py-3 flex flex-col sm:flex-row gap-3">
                    <div class="relative flex-1">
                        <Search class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input v-model="search" @input="debSearch" placeholder="Search by ticket number, subject, customer..."
                               class="input pl-9" />
                    </div>
                    <div class="flex gap-2 flex-wrap">
                        <select v-model="filters.status"   @change="applyFilters" class="input w-auto text-sm">
                            <option value="">All Status</option>
                            <option v-for="s in statuses" :key="s" :value="s">{{ capitalize(s) }}</option>
                        </select>
                        <select v-model="filters.priority" @change="applyFilters" class="input w-auto text-sm">
                            <option value="">All Priority</option>
                            <option v-for="p in priorities" :key="p" :value="p">{{ capitalize(p) }}</option>
                        </select>
                        <select v-model="filters.category_id" @change="applyFilters" class="input w-auto text-sm">
                            <option value="">All Categories</option>
                            <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
                        </select>
                        <button @click="showCreate = true" class="btn-primary btn-sm">
                            <Plus class="w-4 h-4" /> New Ticket
                        </button>
                    </div>
                </div>
            </div>

            <!-- Table -->
            <div class="table-wrapper">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Ticket</th><th>Customer</th><th>Category</th>
                            <th>Status</th><th>Priority</th><th>Assigned To</th>
                            <th>Created</th><th>Due</th><th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-if="!tickets.data.length">
                            <td colspan="9">
                                <EmptyState :icon="Ticket" title="No tickets found" description="Create your first ticket or adjust filters" />
                            </td>
                        </tr>
                        <tr v-for="t in tickets.data" :key="t.id"
                            class="cursor-pointer" @click="router.visit(route('tenant.tickets.show', t.id))">
                            <td>
                                <div>
                                    <p class="font-mono text-xs font-semibold text-brand-600 dark:text-brand-400">{{ t.ticket_number }}</p>
                                    <p class="text-sm font-medium text-gray-900 dark:text-white truncate max-w-48">{{ t.subject }}</p>
                                </div>
                            </td>
                            <td>
                                <div class="flex items-center gap-2">
                                    <img :src="t.customer?.avatar_url" class="w-6 h-6 rounded-full flex-shrink-0" />
                                    <span class="text-sm truncate max-w-32">{{ t.customer?.name }}</span>
                                </div>
                            </td>
                            <td><span class="badge badge-purple text-xs">{{ t.category?.name ?? '—' }}</span></td>
                            <td><TicketStatusBadge :status="t.status" /></td>
                            <td><span :class="'priority-'+t.priority">{{ t.priority }}</span></td>
                            <td>
                                <div v-if="t.assigned_to" class="flex items-center gap-2">
                                    <img :src="`https://ui-avatars.com/api/?name=${t.assigned_to_user?.name ?? 'A'}&background=6366f1&color=fff&size=24`" class="w-5 h-5 rounded-full" />
                                    <span class="text-xs truncate max-w-24">{{ t.assigned_to_user?.name ?? '—' }}</span>
                                </div>
                                <span v-else class="text-xs text-gray-400">Unassigned</span>
                            </td>
                            <td class="text-xs text-gray-500">{{ formatTime(t.created_at) }}</td>
                            <td>
                                <span v-if="t.due_at" :class="['text-xs', isOverdue(t) ? 'text-red-500 font-semibold' : 'text-gray-500']">
                                    {{ formatDate(t.due_at) }}
                                </span>
                                <span v-else class="text-xs text-gray-400">—</span>
                            </td>
                            <td @click.stop>
                                <TicketActionsMenu :ticket="t" @updated="router.reload()" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <Pagination :links="tickets.links" :meta="tickets" />
        </div>

        <!-- Create Ticket Modal -->
        <Modal :show="showCreate" title="New Ticket" max-width="lg" @close="showCreate = false">
            <CreateTicketForm :categories="categories" :agents="agents" @created="onCreated" />
        </Modal>
    </AppLayout>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';
import { router } from '@inertiajs/vue3';
import { Search, Plus, Ticket } from 'lucide-vue-next';
import { useDebounceFn } from '@vueuse/core';
import AppLayout from '@/Layouts/AppLayout.vue';
import StatPill from '@/Components/Dashboard/StatPill.vue';
import TicketStatusBadge from '@/Components/Tickets/TicketStatusBadge.vue';
import TicketActionsMenu from '@/Components/Tickets/TicketActionsMenu.vue';
import CreateTicketForm from '@/Components/Tickets/CreateTicketForm.vue';
import Modal from '@/Components/UI/Modal.vue';
import EmptyState from '@/Components/UI/EmptyState.vue';
import Pagination from '@/Components/Shared/Pagination.vue';
import { formatTime, formatDate } from '@/Utils/format';
import { useToast } from '@/Composables/useToast';

const props = defineProps<{ tickets: any; stats: any; categories: any[]; agents: any[]; filters: any }>();
const { toast } = useToast();
const showCreate = ref(false);
const search = ref(props.filters.search ?? '');
const filters = reactive({ status: props.filters.status ?? '', priority: props.filters.priority ?? '', category_id: props.filters.category_id ?? '' });

const statuses  = ['open','in_progress','waiting','resolved','closed'];
const priorities = ['low','normal','high','urgent','critical'];

const statPills = [
    { label: 'Open',       value: props.stats.open,        color: 'blue' },
    { label: 'In Progress',value: props.stats.in_progress, color: 'yellow' },
    { label: 'Waiting',    value: props.stats.waiting,     color: 'orange' },
    { label: 'Resolved',   value: props.stats.resolved,    color: 'green' },
    { label: 'Overdue',    value: props.stats.overdue,     color: 'red' },
];

const debSearch = useDebounceFn(() => applyFilters(), 400);

function applyFilters() {
    router.get(route('tenant.tickets.index'), { ...filters, search: search.value || undefined }, { preserveState: true });
}

function onCreated() { showCreate.value = false; router.reload(); toast.success('Ticket created!'); }
function capitalize(s: string) { return s.charAt(0).toUpperCase() + s.slice(1).replace('_', ' '); }
function isOverdue(t: any) { return t.due_at && new Date(t.due_at) < new Date() && !['resolved','closed'].includes(t.status); }
</script>
