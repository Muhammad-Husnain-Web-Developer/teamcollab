<?php

namespace App\Events;

use App\Models\User;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class AgentStatusChanged implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public readonly User $agent,
        public readonly string $status,
    ) {}

    public function broadcastOn(): array
    {
        return [new Channel('agents')];
    }

    public function broadcastAs(): string
    {
        return 'agent.status';
    }

    public function broadcastWith(): array
    {
        return [
            'agent_id' => $this->agent->id,
            'name' => $this->agent->name,
            'status' => $this->status,
            'avatar_url' => $this->agent->avatar_url,
        ];
    }
}
