<?php

namespace Database\Seeders;

use App\Models\KbArticle;
use App\Models\KbCategory;
use App\Models\KbFaq;
use App\Models\Setting;
use App\Models\TicketCategory;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class TenantDatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->seedRolesAndPermissions();
        $this->seedDefaultUser();
        $this->seedSettings();
        $this->seedTicketCategories();
        $this->seedKnowledgeBase();
    }

    private function seedRolesAndPermissions(): void
    {
        $permissions = [
            // Conversations
            'view conversations', 'manage conversations', 'assign conversations', 'close conversations',
            // Tickets
            'view tickets', 'create tickets', 'manage tickets', 'assign tickets', 'delete tickets',
            // Customers
            'view customers', 'create customers', 'manage customers', 'delete customers',
            // Knowledge Base
            'view kb', 'create kb articles', 'manage kb', 'delete kb articles',
            // Team
            'view team', 'manage team', 'delete team members',
            // Settings
            'view settings', 'manage settings',
            // Analytics
            'view analytics',
            // AI
            'manage ai settings',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission, 'guard_name' => 'web']);
        }

        $roles = [
            'tenant_owner' => $permissions,
            'manager' => array_diff($permissions, ['delete team members', 'manage settings']),
            'agent' => [
                'view conversations', 'manage conversations',
                'view tickets', 'create tickets', 'manage tickets',
                'view customers', 'create customers',
                'view kb',
            ],
        ];

        foreach ($roles as $roleName => $rolePermissions) {
            $role = Role::firstOrCreate(['name' => $roleName, 'guard_name' => 'web']);
            $role->syncPermissions($rolePermissions);
        }
    }

    private function seedDefaultUser(): void
    {
        $owner = User::firstOrCreate(
            ['email' => 'owner@example.com'],
            [
                'name' => 'Tenant Owner',
                'password' => Hash::make('password'),
                'is_active' => true,
                'email_verified_at' => now(),
            ]
        );
        $owner->assignRole('tenant_owner');
        $owner->availability()->firstOrCreate(['user_id' => $owner->id], ['status' => 'online']);

        // Create sample agents
        foreach (['Alice Agent' => 'alice@example.com', 'Bob Agent' => 'bob@example.com'] as $name => $email) {
            $agent = User::firstOrCreate(
                ['email' => $email],
                ['name' => $name, 'password' => Hash::make('password'), 'is_active' => true, 'email_verified_at' => now()]
            );
            $agent->assignRole('agent');
            $agent->availability()->firstOrCreate(['user_id' => $agent->id], ['status' => 'online']);
        }
    }

    private function seedSettings(): void
    {
        $defaults = [
            ['group' => 'general', 'key' => 'company_name', 'value' => 'My Company', 'type' => 'string'],
            ['group' => 'general', 'key' => 'support_email', 'value' => 'support@example.com', 'type' => 'string'],
            ['group' => 'ai', 'key' => 'ai_provider', 'value' => 'gemini', 'type' => 'string'],
            ['group' => 'ai', 'key' => 'ai_enabled', 'value' => '1', 'type' => 'boolean'],
            ['group' => 'chat', 'key' => 'widget_greeting', 'value' => 'Hi! How can we help you today?', 'type' => 'string'],
            ['group' => 'chat', 'key' => 'auto_assignment', 'value' => '1', 'type' => 'boolean'],
            ['group' => 'tickets', 'key' => 'auto_close_days', 'value' => '7', 'type' => 'integer'],
            ['group' => 'notifications', 'key' => 'email_notifications', 'value' => '1', 'type' => 'boolean'],
        ];

        foreach ($defaults as $setting) {
            Setting::firstOrCreate(['key' => $setting['key']], $setting);
        }
    }

    private function seedTicketCategories(): void
    {
        $categories = [
            ['name' => 'Technical Support', 'color' => '#6366f1', 'icon' => 'wrench'],
            ['name' => 'Billing', 'color' => '#10b981', 'icon' => 'credit-card'],
            ['name' => 'Account', 'color' => '#f59e0b', 'icon' => 'user'],
            ['name' => 'Feature Request', 'color' => '#8b5cf6', 'icon' => 'lightbulb'],
            ['name' => 'Bug Report', 'color' => '#ef4444', 'icon' => 'bug'],
        ];

        foreach ($categories as $cat) {
            TicketCategory::firstOrCreate(['name' => $cat['name']], $cat);
        }
    }

    private function seedKnowledgeBase(): void
    {
        $category = KbCategory::firstOrCreate(
            ['slug' => 'getting-started'],
            ['name' => 'Getting Started', 'description' => 'Learn the basics', 'color' => '#6366f1', 'is_active' => true, 'is_public' => true]
        );

        $author = User::first();
        if (! $author) return;

        KbArticle::firstOrCreate(
            ['slug' => 'how-to-create-ticket'],
            [
                'category_id' => $category->id,
                'author_id' => $author->id,
                'title' => 'How to Create a Support Ticket',
                'excerpt' => 'Learn how to submit a support ticket effectively.',
                'content' => '<h2>Creating a Support Ticket</h2><p>To create a support ticket, navigate to the Support section and click "New Ticket". Fill in the subject, describe your issue in detail, and select the appropriate category and priority.</p><h3>Tips for a great ticket</h3><ul><li>Be specific about your issue</li><li>Include screenshots if possible</li><li>Mention steps to reproduce the problem</li></ul>',
                'content_text' => 'Creating a Support Ticket. To create a support ticket, navigate to the Support section and click New Ticket.',
                'status' => 'published',
                'is_public' => true,
                'published_at' => now(),
            ]
        );

        KbFaq::firstOrCreate(
            ['question' => 'How do I reset my password?'],
            [
                'category_id' => $category->id,
                'answer' => 'Click on "Forgot Password" on the login page and enter your email address. You will receive a password reset link within a few minutes.',
                'is_public' => true,
                'is_active' => true,
                'order' => 1,
            ]
        );
    }
}
