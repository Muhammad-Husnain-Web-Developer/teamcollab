<?php

namespace Tests\Unit\Services;

use App\Models\Conversation;
use App\Models\Customer;
use App\Services\AI\AIResponse;
use App\Services\AI\AIService;
use App\Services\AI\GeminiProvider;
use Mockery;
use Tests\TestCase;

class AIServiceTest extends TestCase
{
    public function test_ai_response_detects_escalation(): void
    {
        $response = new AIResponse(
            content: 'I cannot help with this. [ESCALATE]',
            provider: 'gemini',
            model: 'gemini-1.5-flash',
        );

        $this->assertTrue($response->needsHumanEscalation());
        $this->assertEquals('I cannot help with this. ', trim($response->getCleanContent()));
    }

    public function test_ai_response_no_escalation_for_normal_response(): void
    {
        $response = new AIResponse(
            content: 'Your order will arrive in 3-5 business days.',
            provider: 'gemini',
            model: 'gemini-1.5-flash',
            confidenceScore: 0.9,
        );

        $this->assertFalse($response->needsHumanEscalation());
    }

    public function test_ai_service_uses_correct_provider(): void
    {
        $service = new AIService();
        $this->assertNotNull($service->getProvider());
    }

    public function test_ai_response_total_tokens(): void
    {
        $response = new AIResponse(
            content: 'Test',
            provider: 'gemini',
            model: 'test',
            promptTokens: 100,
            completionTokens: 50,
        );

        $this->assertEquals(150, $response->getTotalTokens());
    }

    public function test_gemini_provider_name(): void
    {
        $provider = new GeminiProvider(['api_key' => 'test', 'model' => 'gemini-1.5-flash']);
        $this->assertEquals('gemini', $provider->getName());
        $this->assertEquals('gemini-1.5-flash', $provider->getModel());
    }

    public function test_gemini_provider_unavailable_without_key(): void
    {
        $provider = new GeminiProvider(['api_key' => '', 'model' => 'gemini-1.5-flash']);
        $this->assertFalse($provider->isAvailable());
    }

    public function test_knowledge_base_search_returns_empty_for_empty_articles(): void
    {
        $service = new AIService();
        $results = $service->searchKnowledgeBase('how to reset password');
        $this->assertIsArray($results);
    }
}
