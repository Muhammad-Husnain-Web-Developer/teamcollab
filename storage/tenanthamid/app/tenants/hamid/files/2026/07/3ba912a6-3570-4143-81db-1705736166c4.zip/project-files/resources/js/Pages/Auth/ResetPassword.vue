<template>
  <div class="min-h-screen bg-gradient-to-br from-brand-50 via-white to-violet-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 flex items-center justify-center p-4">
    <div class="w-full max-w-sm">
      <div class="text-center mb-8">
        <div class="w-12 h-12 bg-gradient-to-br from-brand-500 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-4"><Zap class="w-6 h-6 text-white"/></div>
        <h1 class="text-xl font-bold text-gray-900 dark:text-white">Set new password</h1>
      </div>
      <div class="card card-body shadow-xl">
        <form @submit.prevent="submit" class="space-y-4">
          <div><label class="label">Email</label><input v-model="form.email" type="email" class="input" required/><p v-if="form.errors.email" class="text-xs text-red-500 mt-1">{{form.errors.email}}</p></div>
          <div><label class="label">New Password</label><input v-model="form.password" type="password" class="input" required/><p v-if="form.errors.password" class="text-xs text-red-500 mt-1">{{form.errors.password}}</p></div>
          <div><label class="label">Confirm Password</label><input v-model="form.password_confirmation" type="password" class="input" required/></div>
          <button type="submit" :disabled="form.processing" class="btn-primary w-full justify-center">Reset Password</button>
        </form>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { useForm } from '@inertiajs/vue3';
import { Zap } from 'lucide-vue-next';
const props = defineProps<{ token: string; email: string }>();
const form = useForm({ token: props.token, email: props.email, password: '', password_confirmation: '' });
function submit() { form.post(route('password.store')); }
</script>
