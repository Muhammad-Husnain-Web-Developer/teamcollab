<template>
  <AppLayout>
    <template #header><h1 class="text-sm font-semibold text-gray-900 dark:text-white">Knowledge Base</h1></template>
    <div class="p-6 space-y-5">
      <!-- Stats -->
      <div class="grid grid-cols-4 gap-4">
        <StatCard title="Total Articles"  :value="stats.total_articles"  :icon="FileText"  color="indigo" />
        <StatCard title="Published"       :value="stats.published"        :icon="CheckCircle" color="emerald" />
        <StatCard title="Draft"           :value="stats.draft"            :icon="Edit"      color="amber" />
        <StatCard title="Total FAQs"      :value="stats.total_faqs"       :icon="HelpCircle" color="violet" />
      </div>

      <!-- Tabs -->
      <div class="card">
        <div class="border-b border-gray-100 dark:border-gray-800 px-4 flex gap-0">
          <button v-for="t in ['Articles','FAQs','Categories']" :key="t"
                  @click="tab = t"
                  :class="['px-4 py-3 text-sm font-medium border-b-2 transition-colors',
                           tab === t ? 'border-brand-600 text-brand-600' : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300']">
            {{ t }}
          </button>
        </div>

        <!-- Articles tab -->
        <div v-if="tab === 'Articles'" class="p-4 space-y-4">
          <div class="flex gap-3">
            <div class="relative flex-1">
              <Search class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"/>
              <input v-model="search" @input="debSearch" placeholder="Search articles..." class="input pl-9"/>
            </div>
            <select v-model="statusFilter" @change="applyFilters" class="input w-36 text-sm">
              <option value="">All Status</option>
              <option value="published">Published</option>
              <option value="draft">Draft</option>
              <option value="archived">Archived</option>
            </select>
            <select v-model="catFilter" @change="applyFilters" class="input w-44 text-sm">
              <option value="">All Categories</option>
              <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
            </select>
            <Link :href="route('tenant.kb.articles.create')" class="btn-primary btn-sm"><Plus class="w-4 h-4"/>New Article</Link>
          </div>
          <div class="table-wrapper">
            <table class="table">
              <thead><tr><th>Title</th><th>Category</th><th>Status</th><th>Views</th><th>Helpful</th><th>Updated</th><th></th></tr></thead>
              <tbody>
                <tr v-if="!articles.data.length"><td colspan="7"><EmptyState :icon="FileText" title="No articles found" /></td></tr>
                <tr v-for="a in articles.data" :key="a.id" class="cursor-pointer"
                    @click="router.visit(route('tenant.kb.articles.show', a.id))">
                  <td>
                    <div>
                      <p class="font-medium text-gray-900 dark:text-white text-sm">{{ a.title }}</p>
                      <p v-if="a.excerpt" class="text-xs text-gray-500 truncate max-w-64">{{ a.excerpt }}</p>
                    </div>
                  </td>
                  <td><span v-if="a.category" class="badge badge-purple text-xs">{{ a.category.name }}</span><span v-else class="text-gray-400 text-xs">—</span></td>
                  <td><ArticleStatusBadge :status="a.status"/></td>
                  <td class="text-sm text-center">{{ a.views }}</td>
                  <td class="text-sm text-center text-emerald-600">{{ a.helpful_ratio ?? 0 }}%</td>
                  <td class="text-xs text-gray-500">{{ formatTime(a.updated_at) }}</td>
                  <td @click.stop class="flex gap-1">
                    <Link :href="route('tenant.kb.articles.edit', a.id)" class="btn-ghost btn-sm p-1.5"><Edit class="w-3.5 h-3.5"/></Link>
                    <button @click="deleteArticle(a.id)" class="btn-ghost btn-sm p-1.5 text-red-500 hover:text-red-600"><Trash2 class="w-3.5 h-3.5"/></button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <Pagination :links="articles.links" :meta="articles"/>
        </div>

        <!-- FAQs tab -->
        <div v-if="tab === 'FAQs'" class="p-4">
          <div class="flex justify-between mb-4">
            <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300">Frequently Asked Questions</h3>
            <button @click="showFaqForm=true" class="btn-primary btn-sm"><Plus class="w-4 h-4"/>Add FAQ</button>
          </div>
          <div class="space-y-2">
            <div v-for="faq in faqs" :key="faq.id" class="card p-4">
              <div class="flex items-start justify-between gap-3">
                <div class="flex-1">
                  <p class="text-sm font-semibold text-gray-900 dark:text-white">{{ faq.question }}</p>
                  <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">{{ faq.answer }}</p>
                </div>
                <span class="badge badge-blue text-xs flex-shrink-0">{{ faq.views }} views</span>
              </div>
            </div>
            <EmptyState v-if="!faqs?.length" :icon="HelpCircle" title="No FAQs yet" />
          </div>
        </div>

        <!-- Categories tab -->
        <div v-if="tab === 'Categories'" class="p-4">
          <div class="flex justify-between mb-4">
            <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300">Categories</h3>
            <button @click="showCatForm=true" class="btn-primary btn-sm"><Plus class="w-4 h-4"/>Add Category</button>
          </div>
          <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
            <div v-for="cat in categories" :key="cat.id" class="card p-4">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center" :style="{ background: cat.color+'20' }">
                  <FolderOpen class="w-5 h-5" :style="{ color: cat.color }"/>
                </div>
                <div>
                  <p class="text-sm font-semibold text-gray-900 dark:text-white">{{ cat.name }}</p>
                  <p class="text-xs text-gray-500">{{ cat.articles_count ?? 0 }} articles</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- FAQ Form Modal -->
    <Modal :show="showFaqForm" title="Add FAQ" @close="showFaqForm=false">
      <form @submit.prevent="saveFaq" class="space-y-4">
        <div><label class="label">Question *</label><input v-model="faqForm.question" class="input" required /></div>
        <div><label class="label">Answer *</label><textarea v-model="faqForm.answer" rows="4" class="input resize-none" required /></div>
        <div class="flex justify-end gap-2">
          <button type="button" @click="showFaqForm=false" class="btn-secondary btn-sm">Cancel</button>
          <button type="submit" class="btn-primary btn-sm">Save FAQ</button>
        </div>
      </form>
    </Modal>

    <!-- Category Form Modal -->
    <Modal :show="showCatForm" title="Add Category" @close="showCatForm=false">
      <form @submit.prevent="saveCategory" class="space-y-4">
        <div><label class="label">Name *</label><input v-model="catForm.name" class="input" required /></div>
        <div><label class="label">Description</label><textarea v-model="catForm.description" rows="2" class="input resize-none" /></div>
        <div><label class="label">Color</label><input v-model="catForm.color" type="color" class="w-full h-9 rounded-lg border border-gray-200 dark:border-gray-700 cursor-pointer" /></div>
        <div class="flex justify-end gap-2">
          <button type="button" @click="showCatForm=false" class="btn-secondary btn-sm">Cancel</button>
          <button type="submit" class="btn-primary btn-sm">Save Category</button>
        </div>
      </form>
    </Modal>
  </AppLayout>
</template>
<script setup lang="ts">
import { ref, reactive } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import { Search, Plus, FileText, CheckCircle, Edit, HelpCircle, FolderOpen, Trash2 } from 'lucide-vue-next';
import { useDebounceFn } from '@vueuse/core';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import StatCard from '@/Components/Dashboard/StatCard.vue';
import ArticleStatusBadge from '@/Components/KB/ArticleStatusBadge.vue';
import Modal from '@/Components/UI/Modal.vue';
import EmptyState from '@/Components/UI/EmptyState.vue';
import Pagination from '@/Components/Shared/Pagination.vue';
import { formatTime } from '@/Utils/format';
import { useToast } from '@/Composables/useToast';
const props = defineProps<{ articles: any; categories: any[]; stats: any; filters: any; faqs?: any[] }>();
const { toast } = useToast();
const tab = ref('Articles');
const search = ref(props.filters.search ?? '');
const statusFilter = ref(props.filters.status ?? '');
const catFilter = ref(props.filters.category_id ?? '');
const showFaqForm = ref(false); const showCatForm = ref(false);
const faqForm = reactive({ question:'', answer:'' });
const catForm = reactive({ name:'', description:'', color:'#6366f1' });
const debSearch = useDebounceFn(() => applyFilters(), 400);
function applyFilters() { router.get(route('tenant.kb.index'), { search: search.value||undefined, status: statusFilter.value||undefined, category_id: catFilter.value||undefined }, { preserveState: true }); }
async function deleteArticle(id: number) { if (confirm('Delete this article?')) { await axios.delete(route('tenant.kb.articles.destroy', id)); router.reload(); toast.success('Article deleted'); } }
async function saveFaq() { await axios.post(route('tenant.kb.faqs.store'), faqForm); showFaqForm.value = false; router.reload(); toast.success('FAQ saved'); }
async function saveCategory() { await axios.post(route('tenant.kb.categories.store'), catForm); showCatForm.value = false; router.reload(); toast.success('Category saved'); }
</script>
