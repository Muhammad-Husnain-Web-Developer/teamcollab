<?php

namespace Tests\Feature\Chat;

use App\Models\Conversation;
use App\Models\Customer;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ChatTest extends TestCase
{
    use RefreshDatabase;

    protected User $agent;
    protected Customer $customer;

    protected function setUp(): void
    {
        parent::setUp();
        $this->agent    = User::factory()->create();
        $this->agent->assignRole('agent');
        $this->customer = Customer::factory()->create();
    }

    public function test_agent_can_view_conversations(): void
    {
        Conversation::factory()->count(3)->create(['customer_id' => $this->customer->id]);

        $this->actingAs($this->agent)
            ->get(route('tenant.conversations.index'))
            ->assertOk()
            ->assertInertia(fn ($page) => $page->component('Chat/Index')->has('conversations'));
    }

    public function test_agent_can_view_single_conversation(): void
    {
        $conv = Conversation::factory()->create(['customer_id' => $this->customer->id]);

        $this->actingAs($this->agent)
            ->get(route('tenant.conversations.show', $conv->id))
            ->assertOk()
            ->assertInertia(fn ($page) => $page->component('Chat/Show')->has('conversation'));
    }

    public function test_agent_can_send_message(): void
    {
        $conv = Conversation::factory()->create([
            'customer_id' => $this->customer->id,
            'type'        => 'human',
            'assigned_to' => $this->agent->id,
        ]);

        $this->actingAs($this->agent)
            ->postJson(route('tenant.conversations.messages.send', $conv->id), [
                'content'     => 'Hello, how can I help you?',
                'is_internal' => false,
            ])
            ->assertOk()
            ->assertJsonStructure(['success', 'message']);

        $this->assertDatabaseHas('messages', [
            'conversation_id' => $conv->id,
            'content'         => 'Hello, how can I help you?',
            'sender_id'       => $this->agent->id,
        ]);
    }

    public function test_agent_can_resolve_conversation(): void
    {
        $conv = Conversation::factory()->open()->create([
            'customer_id' => $this->customer->id,
            'assigned_to' => $this->agent->id,
        ]);

        $this->actingAs($this->agent)
            ->postJson(route('tenant.conversations.resolve', $conv->id))
            ->assertOk()
            ->assertJson(['success' => true]);

        $this->assertDatabaseHas('conversations', ['id' => $conv->id, 'status' => 'resolved']);
    }

    public function test_agent_can_assign_conversation(): void
    {
        $conv     = Conversation::factory()->open()->create(['customer_id' => $this->customer->id]);
        $newAgent = User::factory()->create();
        $newAgent->assignRole('agent');

        $this->actingAs($this->agent)
            ->postJson(route('tenant.conversations.assign', $conv->id), ['agent_id' => $newAgent->id])
            ->assertOk()
            ->assertJson(['success' => true]);

        $this->assertDatabaseHas('conversations', ['id' => $conv->id, 'assigned_to' => $newAgent->id]);
    }

    public function test_unauthenticated_user_cannot_access_conversations(): void
    {
        $this->get(route('tenant.conversations.index'))->assertRedirect(route('login'));
    }
}
