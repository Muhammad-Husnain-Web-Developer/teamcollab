<?php

namespace Database\Factories;

use App\Models\TicketCategory;
use Illuminate\Database\Eloquent\Factories\Factory;

class TicketCategoryFactory extends Factory
{
    protected $model = TicketCategory::class;

    public function definition(): array
    {
        return [
            'name'        => fake()->words(2, true),
            'color'       => fake()->hexColor(),
            'description' => fake()->sentence(),
            'is_active'   => true,
        ];
    }
}
