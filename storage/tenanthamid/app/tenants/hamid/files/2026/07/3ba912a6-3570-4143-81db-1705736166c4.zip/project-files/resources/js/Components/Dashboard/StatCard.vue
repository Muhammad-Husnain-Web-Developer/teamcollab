<template>
    <div class="card p-5 relative overflow-hidden group hover:shadow-md transition-shadow duration-200">
        <div class="flex items-start justify-between">
            <div>
                <p class="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide">{{ title }}</p>
                <p class="mt-1.5 text-2xl font-bold text-gray-900 dark:text-white">{{ value }}</p>
                <p v-if="trend" class="mt-1 text-xs" :class="trendColor">{{ trend }}</p>
            </div>
            <div class="p-2.5 rounded-xl flex-shrink-0" :class="bgColor">
                <component :is="icon" class="w-5 h-5" :class="iconColor" />
            </div>
        </div>
        <div v-if="total" class="mt-3">
            <div class="flex justify-between text-xs text-gray-500 dark:text-gray-400 mb-1">
                <span>{{ value }} / {{ total }}</span>
                <span>{{ Math.round(Number(value) / Number(total) * 100) }}%</span>
            </div>
            <div class="h-1 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                <div class="h-full rounded-full transition-all duration-700" :class="progressColor"
                     :style="{ width: Math.round(Number(value) / Number(total) * 100) + '%' }" />
            </div>
        </div>
        <!-- Decorative background -->
        <div class="absolute -right-4 -bottom-4 w-20 h-20 rounded-full opacity-5 group-hover:opacity-10 transition-opacity"
             :class="decorColor" />
    </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';

const props = defineProps<{
    title: string;
    value: string | number;
    total?: string | number;
    icon: any;
    color: 'indigo' | 'amber' | 'emerald' | 'violet' | 'red' | 'blue';
    trend?: string;
}>();

const colorMap: Record<string, { bg: string; icon: string; progress: string; decor: string; trend: string }> = {
    indigo: { bg: 'bg-indigo-50 dark:bg-indigo-900/20', icon: 'text-indigo-600 dark:text-indigo-400', progress: 'bg-indigo-500', decor: 'bg-indigo-500', trend: 'text-indigo-600 dark:text-indigo-400' },
    amber:  { bg: 'bg-amber-50 dark:bg-amber-900/20',   icon: 'text-amber-600 dark:text-amber-400',   progress: 'bg-amber-500',  decor: 'bg-amber-500',  trend: 'text-amber-600 dark:text-amber-400'  },
    emerald:{ bg: 'bg-emerald-50 dark:bg-emerald-900/20',icon: 'text-emerald-600 dark:text-emerald-400',progress: 'bg-emerald-500',decor: 'bg-emerald-500',trend: 'text-emerald-600 dark:text-emerald-400'},
    violet: { bg: 'bg-violet-50 dark:bg-violet-900/20', icon: 'text-violet-600 dark:text-violet-400', progress: 'bg-violet-500', decor: 'bg-violet-500', trend: 'text-violet-600 dark:text-violet-400' },
    red:    { bg: 'bg-red-50 dark:bg-red-900/20',       icon: 'text-red-600 dark:text-red-400',       progress: 'bg-red-500',    decor: 'bg-red-500',    trend: 'text-red-600 dark:text-red-400'      },
    blue:   { bg: 'bg-blue-50 dark:bg-blue-900/20',     icon: 'text-blue-600 dark:text-blue-400',     progress: 'bg-blue-500',   decor: 'bg-blue-500',   trend: 'text-blue-600 dark:text-blue-400'   },
};

const bgColor = computed(() => colorMap[props.color].bg);
const iconColor = computed(() => colorMap[props.color].icon);
const progressColor = computed(() => colorMap[props.color].progress);
const decorColor = computed(() => colorMap[props.color].decor);
const trendColor = computed(() => colorMap[props.color].trend);
</script>
