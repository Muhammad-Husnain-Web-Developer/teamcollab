<template>
  <div class="min-h-screen bg-gradient-to-br from-brand-50 via-white to-violet-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 flex items-center justify-center p-4">
    <div class="w-full max-w-sm">
      <div class="text-center mb-8">
        <div class="w-12 h-12 bg-gradient-to-br from-brand-500 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-4"><Zap class="w-6 h-6 text-white"/></div>
        <h1 class="text-xl font-bold text-gray-900 dark:text-white">Forgot your password?</h1>
        <p class="text-sm text-gray-500 mt-1">Enter your email and we'll send you a reset link.</p>
      </div>
      <div class="card card-body shadow-xl">
        <div v-if="status" class="mb-4 p-3 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 text-sm rounded-lg">{{ status }}</div>
        <form @submit.prevent="submit" class="space-y-4">
          <div>
            <label class="label">Email</label>
            <input v-model="form.email" type="email" class="input" required placeholder="you@company.com"/>
            <p v-if="form.errors.email" class="text-xs text-red-500 mt-1">{{ form.errors.email }}</p>
          </div>
          <button type="submit" :disabled="form.processing" class="btn-primary w-full justify-center">
            <Spinner v-if="form.processing" size="sm"/>
            Send Reset Link
          </button>
        </form>
        <div class="mt-4 text-center">
          <Link :href="route('login')" class="text-sm text-brand-600 hover:underline">Back to login</Link>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { Link, useForm } from '@inertiajs/vue3';
import { Zap } from 'lucide-vue-next';
import Spinner from '@/Components/UI/Spinner.vue';
defineProps<{ status?: string }>();
const form = useForm({ email: '' });
function submit() { form.post(route('password.email')); }
</script>
