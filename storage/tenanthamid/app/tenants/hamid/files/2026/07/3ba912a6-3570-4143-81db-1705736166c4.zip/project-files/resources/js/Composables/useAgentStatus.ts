import { ref } from 'vue';
import axios from 'axios';
import { useToast } from './useToast';

const currentStatus = ref<string>('offline');
const { toast } = useToast();

export function useAgentStatus() {
    async function updateStatus(status: string) {
        try {
            await axios.post(route('tenant.team.status'), { status });
            currentStatus.value = status;
        } catch {
            toast.error('Failed to update status');
        }
    }

    return { currentStatus, updateStatus };
}
