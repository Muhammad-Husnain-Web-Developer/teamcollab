<?php

namespace Database\Factories;

use App\Models\Customer;
use App\Models\Ticket;
use Illuminate\Database\Eloquent\Factories\Factory;

class TicketFactory extends Factory
{
    protected $model = Ticket::class;

    public function definition(): array
    {
        $status   = fake()->randomElement(['open', 'in_progress', 'resolved', 'waiting']);
        $priority = fake()->randomElement(['low', 'normal', 'normal', 'high', 'urgent']);
        $created  = fake()->dateTimeBetween('-30 days', 'now');

        return [
            'ticket_number' => 'TKT-' . str_pad((string) fake()->unique()->numberBetween(1, 99999), 6, '0', STR_PAD_LEFT),
            'subject'       => fake()->sentence(6),
            'description'   => fake()->paragraphs(2, true),
            'customer_id'   => Customer::factory(),
            'status'        => $status,
            'priority'      => $priority,
            'created_at'    => $created,
            'resolved_at'   => in_array($status, ['resolved', 'closed']) ? fake()->dateTimeBetween($created, 'now') : null,
        ];
    }

    public function open(): static
    {
        return $this->state(fn () => ['status' => 'open', 'resolved_at' => null]);
    }

    public function urgent(): static
    {
        return $this->state(fn () => ['priority' => 'urgent']);
    }
}
