<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Http\Requests\Chat\SendMessageRequest;
use App\Models\Conversation;
use App\Models\Customer;
use App\Models\User;
use App\Services\AI\AIService;
use App\Services\Chat\ChatService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class ConversationController extends Controller
{
    public function __construct(
        private readonly ChatService $chatService,
        private readonly AIService $aiService,
    ) {}

    public function index(Request $request): Response
    {
        $conversations = Conversation::with(['customer', 'lastMessage', 'assignedTo'])
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->when($request->type, fn($q, $t) => $q->where('type', $t))
            ->when($request->search, fn($q, $s) => $q->whereHas('customer', fn($cq) => $cq->where('name', 'LIKE', "%{$s}%")->orWhere('email', 'LIKE', "%{$s}%")))
            ->when($request->assigned_to === 'me', fn($q) => $q->where('assigned_to', auth()->id()))
            ->when($request->priority, fn($q, $p) => $q->where('priority', $p))
            ->orderByDesc('last_activity_at')
            ->paginate(20)
            ->withQueryString();

        $stats = $this->chatService->getStats();
        $agents = User::role(['agent', 'manager'])->where('is_active', true)->get(['id', 'name', 'status', 'avatar']);

        return Inertia::render('Chat/Index', [
            'conversations' => $conversations,
            'stats' => $stats,
            'agents' => $agents,
            'filters' => $request->only(['status', 'type', 'search', 'assigned_to', 'priority']),
        ]);
    }

    public function show(Conversation $conversation): Response
    {
        $conversation->loadMissing([
            'customer.notes',
            'customer.tickets',
            'assignedTo',
            'aiConversation',
        ]);

        $messages = $conversation->messages()
            ->with('sender')
            ->orderBy('created_at', 'asc')
            ->paginate(50);

        $agents = User::role(['agent', 'manager'])->where('is_active', true)->get(['id', 'name', 'status']);
        $suggestions = [];

        if ($conversation->type === 'human' && auth()->check()) {
            try {
                $suggestions = $this->aiService->generateSmartSuggestions($conversation);
            } catch (\Exception) {
                // Non-critical, continue without suggestions
            }
        }

        return Inertia::render('Chat/Show', [
            'conversation' => $conversation,
            'messages' => $messages,
            'agents' => $agents,
            'suggestions' => $suggestions,
        ]);
    }

    public function sendMessage(SendMessageRequest $request, Conversation $conversation): JsonResponse
    {
        $user = auth()->user();
        $message = $this->chatService->sendAgentMessage(
            $conversation,
            $user,
            $request->content,
            $request->boolean('is_internal'),
            $request->attachments ?? [],
        );

        return response()->json([
            'success' => true,
            'message' => $message->load('sender'),
        ]);
    }

    public function assign(Request $request, Conversation $conversation): JsonResponse
    {
        $request->validate(['agent_id' => 'nullable|exists:users,id']);

        $agent = $request->agent_id ? User::find($request->agent_id) : null;
        $this->chatService->assignConversation($conversation, $agent);

        return response()->json(['success' => true, 'conversation' => $conversation->fresh()]);
    }

    public function transfer(Request $request, Conversation $conversation): JsonResponse
    {
        $request->validate(['agent_id' => 'required|exists:users,id']);

        $toAgent = User::findOrFail($request->agent_id);
        $fromAgent = $conversation->assignedTo ?? auth()->user();
        $this->chatService->transferConversation($conversation, $fromAgent, $toAgent);

        return response()->json(['success' => true]);
    }

    public function resolve(Conversation $conversation): JsonResponse
    {
        $this->chatService->resolveConversation($conversation, auth()->user());
        return response()->json(['success' => true]);
    }

    public function escalate(Request $request, Conversation $conversation): JsonResponse
    {
        $this->chatService->escalateToHuman($conversation, $request->agent_id);
        return response()->json(['success' => true]);
    }

    public function typing(Request $request, Conversation $conversation): JsonResponse
    {
        $this->chatService->handleTyping($conversation, auth()->user(), $request->boolean('is_typing'));
        return response()->json(['success' => true]);
    }

    public function addReaction(Request $request, Conversation $conversation, int $messageId): JsonResponse
    {
        $request->validate(['emoji' => 'required|string|max:10']);

        $message = $conversation->messages()->findOrFail($messageId);
        $message->addReaction($request->emoji, auth()->id());

        return response()->json(['success' => true, 'reactions' => $message->fresh()->reactions]);
    }

    public function suggestions(Conversation $conversation): JsonResponse
    {
        $suggestions = $this->aiService->generateSmartSuggestions($conversation);
        return response()->json(['suggestions' => $suggestions]);
    }

    public function summarize(Conversation $conversation): JsonResponse
    {
        $summary = $this->aiService->summarizeConversation($conversation);
        return response()->json(['summary' => $summary]);
    }
}
