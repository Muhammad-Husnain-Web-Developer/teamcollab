# 🤖 AI Support SaaS Platform

A complete, production-ready **enterprise AI Customer Support SaaS Platform** built with Laravel 11, Vue 3, Inertia.js, and powered by multiple AI providers (Gemini, OpenAI, Claude, Ollama).

---

## ✨ Features

### 🏢 Multi-Tenancy
- Complete tenant isolation (separate databases per tenant)
- Wildcard subdomain routing (`tenant1.yourdomain.com`)
- Per-tenant branding (logo, colors, favicon)
- Plan-based feature gating

### 💬 Live Chat
- Real-time messaging via Laravel Reverb (WebSockets)
- Typing indicators & seen/delivered status
- Message reactions (emoji)
- File, image, audio & PDF sharing
- Internal notes (agent-only)
- Chat assignment & transfer
- Priority & label system

### 🤖 AI Engine
- **Google Gemini** (default, free tier available)
- **OpenAI GPT-4o**
- **Anthropic Claude**
- **Ollama** (local, free)
- Switch providers with one click
- RAG-like knowledge base search
- Auto escalation to human agents
- Smart reply suggestions
- Conversation summarization

### 🎫 Ticketing
- Auto-generated ticket numbers
- Priority levels (Low → Critical)
- SLA tracking
- Escalation system
- Internal notes
- Category management

### 📚 Knowledge Base
- Rich-text article editor
- Categories & FAQs
- AI-powered search
- Article analytics (views, helpful ratings)
- RAG integration for AI responses

### 👥 Team Management
- Roles: Tenant Owner, Manager, Agent
- Granular permissions (Spatie)
- Agent availability status (Online/Busy/Away/Offline)
- Performance metrics

### 📊 Analytics
- Real-time dashboard
- Conversation trends
- Agent performance
- Ticket statistics
- Customer satisfaction ratings

### 💳 Subscriptions (Stripe)
- Free / Starter / Professional / Enterprise plans
- Trial periods
- Monthly & yearly billing
- Stripe Customer Portal
- Webhook handling

### 🔐 Security
- CSRF & XSS protection
- SQL injection prevention
- Rate limiting
- Role-based authorization
- Audit logs (Spatie Activity Log)
- Session security

---

## 🛠 Tech Stack

| Layer        | Technology                          |
|--------------|-------------------------------------|
| Backend      | Laravel 11, PHP 8.3                 |
| Frontend     | Vue 3, Inertia.js, TypeScript, Vite |
| Styling      | Tailwind CSS 3, Custom Design System|
| Database     | MySQL 8.0 (per-tenant)              |
| Cache/Queue  | Redis + Laravel Horizon             |
| WebSockets   | Laravel Reverb                      |
| Multi-tenancy| Stancl Tenancy 3                    |
| Permissions  | Spatie Laravel Permission           |
| Payments     | Stripe (Laravel Cashier)            |
| AI           | Gemini / OpenAI / Claude / Ollama   |
| State        | Pinia                               |
| Icons        | Lucide Vue Next                     |

---

## 📁 Project Structure

```
ai-support-saas/
├── app/
│   ├── Events/              # Real-time events (MessageSent, etc.)
│   ├── Http/Controllers/
│   │   ├── Admin/           # Super admin controllers
│   │   ├── Api/             # Public widget API
│   │   └── Tenant/          # All tenant controllers
│   ├── Jobs/                # Queue jobs (ProcessAiResponse)
│   ├── Models/              # All Eloquent models
│   ├── Notifications/       # Email & push notifications
│   ├── Providers/           # AppServiceProvider, TenancyServiceProvider
│   └── Services/
│       ├── AI/              # AIService + all providers
│       └── Chat/            # ChatService
├── config/
│   ├── ai.php               # AI provider configuration
│   ├── plans.php            # Subscription plan features
│   └── tenancy.php          # Multi-tenancy config
├── database/
│   ├── factories/           # Model factories for testing
│   ├── migrations/
│   │   ├── central/         # Central DB migrations
│   │   └── tenant/          # Per-tenant DB migrations
│   └── seeders/             # Seeders for initial data
├── resources/
│   ├── css/app.css          # Global styles + design system
│   └── js/
│       ├── Components/      # 25+ Vue components
│       ├── Composables/     # useToast, useAgentStatus, useRealtime
│       ├── Layouts/         # AppLayout
│       ├── Pages/           # 18 Inertia pages
│       └── Utils/           # format.ts helpers
├── routes/
│   ├── api.php              # API routes
│   ├── auth.php             # Auth routes
│   ├── tenant.php           # Tenant-scoped routes
│   └── web.php              # Central web routes
├── tests/
│   ├── Feature/             # Auth, Chat, Ticket, KB tests
│   └── Unit/                # Service unit tests
├── nginx/                   # Production Nginx config
├── supervisor/              # Supervisor config
├── INSTALL.md               # Installation guide
└── DEPLOY.md                # Production deployment guide
```

---

## 🚀 Quick Start

```bash
git clone https://github.com/your-org/ai-support-saas.git
cd ai-support-saas
composer install
npm install
cp .env.example .env
php artisan key:generate
# Edit .env with your database/API keys
php artisan migrate --path=database/migrations/central
php artisan db:seed --class=SuperAdminSeeder
npm run dev
php artisan reverb:start &
php artisan horizon &
```

See [INSTALL.md](INSTALL.md) for complete guide.

---

## 🧪 Running Tests

```bash
# Run all tests
php artisan test

# Run specific suite
php artisan test --testsuite=Feature
php artisan test --testsuite=Unit

# With coverage
php artisan test --coverage
```

---

## 🌐 Demo Credentials

After seeding, login at `http://demo.localhost`:
- **Email:** `owner@example.com`
- **Password:** `password`

---

## 📝 License

Proprietary. All rights reserved.
