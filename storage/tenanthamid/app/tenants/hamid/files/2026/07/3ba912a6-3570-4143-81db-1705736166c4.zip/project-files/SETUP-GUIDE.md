# AI Support SaaS — Complete Setup Guide
# ========================================
# Yeh guide step-by-step batati hai kaise project chalayein

## REQUIREMENTS (Pehle yeh install karein)
# ─────────────────────────────────────────
# PHP 8.2+     → https://www.php.net/downloads
# Composer 2+  → https://getcomposer.org
# Node.js 18+  → https://nodejs.org
# MySQL 8+     → https://dev.mysql.com/downloads/  (ya XAMPP)
# Redis        → https://redis.io  (optional for local)


## STEP 1: New Laravel Project Banao
# ────────────────────────────────────
composer create-project laravel/laravel ai-support
cd ai-support


## STEP 2: Is ZIP ki saari files copy karo Laravel project mein
# ──────────────────────────────────────────────────────────────
# ZIP extract karo, phir andar jo folders/files hain woh Laravel project mein
# same location pe copy karo. For example:
#   config/ai.php          → ai-support/config/ai.php
#   app/Models/*.php       → ai-support/app/Models/
#   resources/js/Pages/    → ai-support/resources/js/Pages/
# etc.


## STEP 3: Composer Packages Install Karo
# ─────────────────────────────────────────
composer require inertiajs/inertia-laravel tightenco/ziggy
composer require stancl/tenancy spatie/laravel-permission spatie/laravel-activitylog
composer require laravel/horizon laravel/reverb laravel/sanctum
composer require guzzlehttp/guzzle predis/predis

composer require --dev pestphp/pest pestphp/pest-plugin-laravel


## STEP 4: Breeze (Vue + Inertia + TypeScript) Install Karo
# ──────────────────────────────────────────────────────────
composer require laravel/breeze --dev
php artisan breeze:install vue --typescript --ssr no


## STEP 5: Reverb + Horizon Install Karo
# ────────────────────────────────────────
php artisan reverb:install
php artisan horizon:install


## STEP 6: Permission tables publish karo
# ─────────────────────────────────────────
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"


## STEP 7: NPM Packages Install Karo
# ─────────────────────────────────────
npm install
npm install pinia @vueuse/core lucide-vue-next date-fns
npm install --save-dev @tailwindcss/forms @tailwindcss/typography


## STEP 8: .env File Setup Karo
# ──────────────────────────────
cp .env.example .env
php artisan key:generate

# Ab .env file open karo aur yeh values set karo:
# ─────────────────────────────────────────────────
APP_URL=http://localhost:8000
CENTRAL_DOMAIN=localhost
CENTRAL_DOMAINS=localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ai_support_central
DB_USERNAME=root
DB_PASSWORD=your_password

# Agar Redis nahi hai, yeh use karo (local dev ke liye):
CACHE_STORE=file
SESSION_DRIVER=file
QUEUE_CONNECTION=sync
BROADCAST_CONNECTION=log

# Agar Redis hai:
# CACHE_STORE=redis
# SESSION_DRIVER=redis
# QUEUE_CONNECTION=redis
# BROADCAST_CONNECTION=reverb

# AI Key (Free - https://aistudio.google.com/apikey)
AI_DEFAULT_PROVIDER=gemini
GEMINI_API_KEY=your_gemini_key_here

# Reverb
REVERB_APP_ID=ai-support
REVERB_APP_KEY=my-app-key
REVERB_APP_SECRET=my-app-secret
REVERB_HOST=localhost
REVERB_PORT=8080
REVERB_SCHEME=http
VITE_REVERB_APP_KEY="${REVERB_APP_KEY}"
VITE_REVERB_HOST="${REVERB_HOST}"
VITE_REVERB_PORT="${REVERB_PORT}"
VITE_REVERB_SCHEME="${REVERB_SCHEME}"


## STEP 9: MySQL Database Banao
# ──────────────────────────────
# MySQL mein login karo:
mysql -u root -p

# Yeh commands chalao:
# CREATE DATABASE ai_support_central CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
# EXIT;


## STEP 10: bootstrap/app.php Update Karo
# ─────────────────────────────────────────
# is ZIP ki bootstrap/app.php se replace karo Laravel wali file se


## STEP 11: Migrations Chalao
# ─────────────────────────────
# Central migrations (main database)
php artisan migrate --path=database/migrations/central

# NOTE: Tenant migrations automatically chalti hain jab tenant banta hai


## STEP 12: Pehla Tenant Banao
# ──────────────────────────────
php artisan tinker

# Tinker mein yeh paste karo:
# ───────────────────────────
use App\Models\Tenant;
use Illuminate\Support\Str;

$tenant = Tenant::create([
    'id'    => Str::uuid()->toString(),
    'name'  => 'My Company',
    'slug'  => 'demo',
    'email' => 'admin@mycompany.com',
    'plan'  => 'professional',
    'is_active' => true,
    'primary_color' => '#6366f1',
]);

$tenant->domains()->create(['domain' => 'localhost']);

tenancy()->initialize($tenant);

Artisan::call('migrate', [
    '--path'  => 'database/migrations/tenant',
    '--force' => true,
]);

Artisan::call('db:seed', [
    '--class' => 'TenantDatabaseSeeder',
    '--force' => true,
]);

tenancy()->end();

echo "Done! Login: owner@example.com / password\n";
exit;


## STEP 13: Storage Link Banao
# ─────────────────────────────
php artisan storage:link


## STEP 14: Frontend Build Karo
# ──────────────────────────────
# Production build:
npm run build

# Ya development (hot reload):
npm run dev


## STEP 15: App Chalao
# ─────────────────────
# Terminal 1 - Laravel server:
php artisan serve

# Terminal 2 - Queue worker (agar QUEUE_CONNECTION=sync nahi hai):
php artisan queue:work

# Terminal 3 - Reverb WebSocket (real-time ke liye):
php artisan reverb:start

# Terminal 4 - Frontend dev (agar npm run dev use kar rahe ho):
npm run dev


## LOGIN
# ───────
# URL:      http://localhost:8000
# Email:    owner@example.com
# Password: password


## ARTISAN COMMANDS (Extra)
# ──────────────────────────
# Naya tenant banao:
php artisan tenant:create "Company Name" "admin@company.com" "company.localhost"

# Cache clear:
php artisan optimize:clear

# Tests chalao:
php artisan test


## PRODUCTION DEPLOYMENT
# ──────────────────────
# Dekho: DEPLOY.md file
