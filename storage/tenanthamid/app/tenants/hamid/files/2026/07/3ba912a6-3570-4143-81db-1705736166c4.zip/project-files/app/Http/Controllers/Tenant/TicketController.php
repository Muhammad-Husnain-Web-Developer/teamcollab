<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\Ticket;
use App\Models\TicketCategory;
use App\Models\TicketReply;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class TicketController extends Controller
{
    public function index(Request $request): Response
    {
        $tickets = Ticket::with(['customer', 'assignedTo', 'category'])
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->when($request->priority, fn($q, $p) => $q->where('priority', $p))
            ->when($request->category_id, fn($q, $c) => $q->where('category_id', $c))
            ->when($request->assigned_to === 'me', fn($q) => $q->where('assigned_to', auth()->id()))
            ->when($request->search, fn($q, $s) => $q->where(function ($sq) use ($s) {
                $sq->where('ticket_number', 'LIKE', "%{$s}%")
                    ->orWhere('subject', 'LIKE', "%{$s}%")
                    ->orWhereHas('customer', fn($cq) => $cq->where('name', 'LIKE', "%{$s}%"));
            }))
            ->orderByDesc('created_at')
            ->paginate(20)
            ->withQueryString();

        $categories = TicketCategory::where('is_active', true)->get();
        $agents = User::role(['agent', 'manager'])->where('is_active', true)->get(['id', 'name']);

        $stats = [
            'open' => Ticket::where('status', 'open')->count(),
            'in_progress' => Ticket::where('status', 'in_progress')->count(),
            'waiting' => Ticket::where('status', 'waiting')->count(),
            'resolved' => Ticket::where('status', 'resolved')->count(),
            'overdue' => Ticket::whereNotNull('due_at')->where('due_at', '<', now())->whereNotIn('status', ['resolved', 'closed'])->count(),
        ];

        return Inertia::render('Tickets/Index', [
            'tickets' => $tickets,
            'categories' => $categories,
            'agents' => $agents,
            'stats' => $stats,
            'filters' => $request->only(['status', 'priority', 'category_id', 'assigned_to', 'search']),
        ]);
    }

    public function show(Ticket $ticket): Response
    {
        $ticket->loadMissing(['customer', 'assignedTo', 'category', 'conversation.lastMessage', 'escalations.escalatedBy', 'escalations.escalatedTo']);

        $replies = $ticket->replies()->with('user', 'customer')->orderBy('created_at')->get();
        $agents = User::role(['agent', 'manager'])->where('is_active', true)->get(['id', 'name']);

        return Inertia::render('Tickets/Show', [
            'ticket' => $ticket,
            'replies' => $replies,
            'agents' => $agents,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'subject' => 'required|string|max:255',
            'description' => 'required|string',
            'customer_id' => 'required|exists:customers,id',
            'category_id' => 'nullable|exists:ticket_categories,id',
            'priority' => 'required|in:low,normal,high,urgent,critical',
            'assigned_to' => 'nullable|exists:users,id',
            'due_at' => 'nullable|date|after:now',
            'tags' => 'nullable|array',
        ]);

        $ticket = Ticket::create($validated);

        return response()->json(['success' => true, 'ticket' => $ticket->load(['customer', 'category'])], 201);
    }

    public function update(Request $request, Ticket $ticket): JsonResponse
    {
        $validated = $request->validate([
            'subject' => 'sometimes|string|max:255',
            'description' => 'sometimes|string',
            'status' => 'sometimes|in:open,in_progress,waiting,resolved,closed',
            'priority' => 'sometimes|in:low,normal,high,urgent,critical',
            'category_id' => 'nullable|exists:ticket_categories,id',
            'assigned_to' => 'nullable|exists:users,id',
            'due_at' => 'nullable|date',
            'tags' => 'nullable|array',
        ]);

        // Track status changes
        if (isset($validated['status'])) {
            if (in_array($validated['status'], ['resolved', 'closed']) && ! $ticket->resolved_at) {
                $validated['resolved_at'] = now();
                $validated['resolution_time'] = $ticket->calculateResolutionTime();
            }
        }

        $ticket->update($validated);

        return response()->json(['success' => true, 'ticket' => $ticket->fresh()->load(['customer', 'assignedTo', 'category'])]);
    }

    public function reply(Request $request, Ticket $ticket): JsonResponse
    {
        $validated = $request->validate([
            'content' => 'required|string',
            'is_internal' => 'boolean',
            'attachments' => 'nullable|array',
        ]);

        $reply = $ticket->replies()->create([
            ...$validated,
            'user_id' => auth()->id(),
        ]);

        if (! $ticket->first_response_at) {
            $ticket->update([
                'first_response_at' => now(),
                'response_time' => $ticket->calculateResponseTime(),
            ]);
        }

        if ($ticket->status === 'open') {
            $ticket->update(['status' => 'in_progress']);
        }

        return response()->json(['success' => true, 'reply' => $reply->load('user')], 201);
    }

    public function escalate(Request $request, Ticket $ticket): JsonResponse
    {
        $validated = $request->validate([
            'reason' => 'required|string|max:500',
            'escalated_to' => 'nullable|exists:users,id',
            'notes' => 'nullable|string',
        ]);

        $ticket->escalations()->create([
            ...$validated,
            'escalated_by' => auth()->id(),
        ]);

        if ($validated['escalated_to']) {
            $ticket->update(['assigned_to' => $validated['escalated_to']]);
        }

        return response()->json(['success' => true]);
    }

    public function destroy(Ticket $ticket): JsonResponse
    {
        $ticket->delete();
        return response()->json(['success' => true]);
    }
}
