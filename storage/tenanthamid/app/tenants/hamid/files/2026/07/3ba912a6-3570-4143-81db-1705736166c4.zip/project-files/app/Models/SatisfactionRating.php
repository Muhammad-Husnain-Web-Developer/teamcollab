<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class SatisfactionRating extends Model {
    protected $fillable = ['conversation_id','ticket_id','customer_id','rating','comment'];
    public function conversation(): BelongsTo { return $this->belongsTo(Conversation::class); }
    public function ticket(): BelongsTo { return $this->belongsTo(Ticket::class); }
    public function customer(): BelongsTo { return $this->belongsTo(Customer::class); }
}
