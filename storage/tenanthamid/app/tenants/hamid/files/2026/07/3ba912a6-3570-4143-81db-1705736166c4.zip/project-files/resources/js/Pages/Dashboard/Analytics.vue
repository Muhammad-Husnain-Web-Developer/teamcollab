<template>
  <AppLayout>
    <template #header>
      <div class="flex items-center gap-3">
        <h1 class="text-sm font-semibold text-gray-900 dark:text-white">Analytics</h1>
        <select v-model="period" @change="changePeriod" class="input w-32 text-xs">
          <option value="7">Last 7 days</option>
          <option value="30">Last 30 days</option>
          <option value="90">Last 90 days</option>
        </select>
      </div>
    </template>
    <div class="p-6 space-y-5">
      <!-- Conversation trend -->
      <div class="card">
        <div class="card-header"><h3 class="text-sm font-semibold text-gray-900 dark:text-white">Conversations Over Time</h3></div>
        <div class="card-body"><ConversationChart :data="conversations_by_day"/></div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <!-- Tickets by status -->
        <div class="card">
          <div class="card-header"><h3 class="text-sm font-semibold text-gray-900 dark:text-white">Tickets by Status</h3></div>
          <div class="card-body space-y-3">
            <div v-for="item in tickets_by_status" :key="item.status" class="flex items-center gap-3">
              <span class="w-20 text-xs text-gray-500 capitalize">{{ item.status.replace('_',' ') }}</span>
              <div class="flex-1 h-2.5 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                <div class="h-full rounded-full transition-all duration-700" :class="ticketStatusColor(item.status)"
                     :style="{ width: (item.count / maxTickets * 100) + '%' }"/>
              </div>
              <span class="text-sm font-semibold text-gray-800 dark:text-gray-200 w-8 text-right">{{ item.count }}</span>
            </div>
          </div>
        </div>

        <!-- Satisfaction trend -->
        <div class="card">
          <div class="card-header"><h3 class="text-sm font-semibold text-gray-900 dark:text-white">Customer Satisfaction</h3></div>
          <div class="card-body">
            <ConversationChart :data="satisfaction_trend.map(s => ({ date: s.date, total: s.avg_rating * 20 }))" />
            <div class="flex justify-between text-xs text-gray-500 mt-2 px-1">
              <span>Avg over period</span>
              <span class="font-semibold text-amber-500">
                ★ {{ (satisfaction_trend.reduce((a,s) => a + s.avg_rating, 0) / Math.max(satisfaction_trend.length, 1)).toFixed(1) }}/5
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Agent performance -->
      <div class="card">
        <div class="card-header"><h3 class="text-sm font-semibold text-gray-900 dark:text-white">Agent Performance</h3></div>
        <div class="table-wrapper">
          <table class="table">
            <thead><tr><th>Agent</th><th>Total Tickets</th><th>Resolved</th><th>Resolution Rate</th></tr></thead>
            <tbody>
              <tr v-for="a in agent_performance" :key="a.id">
                <td>
                  <div class="flex items-center gap-2">
                    <img :src="`https://ui-avatars.com/api/?name=${a.name}&background=6366f1&color=fff&size=28`" class="w-7 h-7 rounded-full"/>
                    <span class="text-sm font-medium text-gray-900 dark:text-white">{{ a.name }}</span>
                  </div>
                </td>
                <td class="text-sm text-center">{{ a.total_tickets }}</td>
                <td class="text-sm text-center text-emerald-600">{{ a.resolved_tickets }}</td>
                <td>
                  <div class="flex items-center gap-2">
                    <div class="flex-1 h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                      <div class="h-full bg-emerald-500 rounded-full"
                           :style="{ width: (a.resolved_tickets / Math.max(a.total_tickets,1) * 100) + '%' }"/>
                    </div>
                    <span class="text-xs font-medium text-gray-600 dark:text-gray-400 w-10">
                      {{ ((a.resolved_tickets / Math.max(a.total_tickets,1)) * 100).toFixed(0) }}%
                    </span>
                  </div>
                </td>
              </tr>
              <tr v-if="!agent_performance.length"><td colspan="4"><EmptyState :icon="BarChart3" title="No performance data yet"/></td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </AppLayout>
</template>
<script setup lang="ts">
import { ref, computed } from 'vue';
import { router } from '@inertiajs/vue3';
import { BarChart3 } from 'lucide-vue-next';
import AppLayout from '@/Layouts/AppLayout.vue';
import ConversationChart from '@/Components/Dashboard/ConversationChart.vue';
import EmptyState from '@/Components/UI/EmptyState.vue';
const props = defineProps<{ period: string; conversations_by_day: any[]; tickets_by_status: any[]; agent_performance: any[]; satisfaction_trend: any[] }>();
const period = ref(props.period);
const maxTickets = computed(() => Math.max(...props.tickets_by_status.map(t => t.count), 1));
function changePeriod() { router.get(route('tenant.analytics'), { period: period.value }, { preserveState: true }); }
function ticketStatusColor(status: string) {
  return { open:'bg-blue-500', in_progress:'bg-yellow-500', waiting:'bg-orange-500', resolved:'bg-emerald-500', closed:'bg-gray-400' }[status] ?? 'bg-gray-400';
}
</script>
