<template>
  <div class="min-h-screen bg-gradient-to-br from-brand-50 via-white to-violet-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 flex items-center justify-center p-4">
    <div class="w-full max-w-md">
      <div class="text-center mb-8">
        <div class="w-12 h-12 bg-gradient-to-br from-brand-500 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-brand-200">
          <Zap class="w-6 h-6 text-white" />
        </div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Create your workspace</h1>
        <p class="text-sm text-gray-500 mt-1">Start your 14-day free trial</p>
      </div>
      <div class="card card-body shadow-xl shadow-gray-100 dark:shadow-gray-900/50">
        <form @submit.prevent="submit" class="space-y-4">
          <div>
            <label class="label">Full Name</label>
            <input v-model="form.name" class="input" placeholder="John Smith" required autocomplete="name" />
            <p v-if="form.errors.name" class="text-xs text-red-500 mt-1">{{ form.errors.name }}</p>
          </div>
          <div>
            <label class="label">Work Email</label>
            <input v-model="form.email" type="email" class="input" placeholder="john@company.com" required autocomplete="email" />
            <p v-if="form.errors.email" class="text-xs text-red-500 mt-1">{{ form.errors.email }}</p>
          </div>
          <div>
            <label class="label">Password</label>
            <input v-model="form.password" type="password" class="input" placeholder="At least 8 characters" required autocomplete="new-password" />
            <p v-if="form.errors.password" class="text-xs text-red-500 mt-1">{{ form.errors.password }}</p>
          </div>
          <div>
            <label class="label">Confirm Password</label>
            <input v-model="form.password_confirmation" type="password" class="input" placeholder="••••••••" required />
          </div>
          <button type="submit" :disabled="form.processing" class="btn-primary w-full justify-center py-2.5">
            <Spinner v-if="form.processing" size="sm" />
            Create Account
          </button>
        </form>
        <div class="mt-4 text-center">
          <p class="text-sm text-gray-500">
            Already have an account? <Link :href="route('login')" class="text-brand-600 font-medium hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
      <p class="text-xs text-center text-gray-400 mt-4">By registering, you agree to our Terms of Service and Privacy Policy.</p>
    </div>
  </div>
</template>
<script setup lang="ts">
import { Link, useForm } from '@inertiajs/vue3';
import { Zap } from 'lucide-vue-next';
import Spinner from '@/Components/UI/Spinner.vue';
const form = useForm({ name:'', email:'', password:'', password_confirmation:'' });
function submit() { form.post(route('register')); }
</script>
