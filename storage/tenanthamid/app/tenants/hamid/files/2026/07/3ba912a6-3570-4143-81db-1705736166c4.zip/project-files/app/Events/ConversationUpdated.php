<?php

namespace App\Events;

use App\Models\Conversation;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ConversationUpdated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public readonly Conversation $conversation) {}

    public function broadcastOn(): array
    {
        return [
            new Channel('conversations'),
            new Channel('agent.' . ($this->conversation->assigned_to ?? 'unassigned')),
        ];
    }

    public function broadcastAs(): string
    {
        return 'conversation.updated';
    }

    public function broadcastWith(): array
    {
        return [
            'id' => $this->conversation->id,
            'uuid' => $this->conversation->uuid,
            'status' => $this->conversation->status,
            'type' => $this->conversation->type,
            'priority' => $this->conversation->priority,
            'assigned_to' => $this->conversation->assigned_to,
            'last_activity_at' => $this->conversation->last_activity_at?->toISOString(),
        ];
    }
}
