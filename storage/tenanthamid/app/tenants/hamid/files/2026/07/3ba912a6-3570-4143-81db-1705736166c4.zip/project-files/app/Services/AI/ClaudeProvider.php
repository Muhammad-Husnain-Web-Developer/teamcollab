<?php

namespace App\Services\AI;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ClaudeProvider implements AIProviderInterface
{
    private string $apiKey;
    private string $model;
    private int $maxTokens;
    private float $temperature;

    public function __construct(array $config)
    {
        $this->apiKey = $config['api_key'] ?? '';
        $this->model = $config['model'] ?? 'claude-3-5-sonnet-20241022';
        $this->maxTokens = $config['max_tokens'] ?? 2048;
        $this->temperature = $config['temperature'] ?? 0.7;
    }

    public function generateResponse(array $messages, ?string $systemPrompt = null, array $options = []): AIResponse
    {
        $formattedMessages = [];
        foreach ($messages as $message) {
            $formattedMessages[] = [
                'role' => $message['role'],
                'content' => $message['content'],
            ];
        }

        $payload = [
            'model' => $options['model'] ?? $this->model,
            'max_tokens' => $options['max_tokens'] ?? $this->maxTokens,
            'messages' => $formattedMessages,
            'temperature' => $options['temperature'] ?? $this->temperature,
        ];

        if ($systemPrompt) {
            $payload['system'] = $systemPrompt;
        }

        try {
            $response = Http::withHeaders([
                'x-api-key' => $this->apiKey,
                'anthropic-version' => '2023-06-01',
                'Content-Type' => 'application/json',
            ])
                ->timeout(30)
                ->post('https://api.anthropic.com/v1/messages', $payload);

            if ($response->failed()) {
                Log::error('Claude API error', ['status' => $response->status(), 'body' => $response->body()]);
                throw new \RuntimeException("Claude API error: " . $response->body());
            }

            $data = $response->json();
            $content = $data['content'][0]['text'] ?? '';
            $usage = $data['usage'] ?? [];

            $shouldEscalate = str_contains($content, '[ESCALATE]');

            return new AIResponse(
                content: $content,
                provider: 'claude',
                model: $this->model,
                promptTokens: $usage['input_tokens'] ?? 0,
                completionTokens: $usage['output_tokens'] ?? 0,
                confidenceScore: $shouldEscalate ? 0.3 : 0.9,
                shouldEscalate: $shouldEscalate,
                meta: ['stop_reason' => $data['stop_reason'] ?? ''],
            );
        } catch (\Exception $e) {
            Log::error('Claude provider error', ['error' => $e->getMessage()]);
            throw $e;
        }
    }

    public function complete(string $prompt, array $options = []): AIResponse
    {
        return $this->generateResponse([
            ['role' => 'user', 'content' => $prompt],
        ], null, $options);
    }

    public function isAvailable(): bool
    {
        return ! empty($this->apiKey);
    }

    public function getName(): string
    {
        return 'claude';
    }

    public function getModel(): string
    {
        return $this->model;
    }
}
