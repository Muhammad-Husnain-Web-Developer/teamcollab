<template>
  <div class="flex flex-col items-center justify-center py-16 px-4 text-center">
    <div class="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
      <component :is="icon" class="w-8 h-8 text-gray-400" />
    </div>
    <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300">{{ title }}</h3>
    <p class="text-sm text-gray-400 mt-1 max-w-xs">{{ description }}</p>
    <div v-if="$slots.action" class="mt-4"><slot name="action" /></div>
  </div>
</template>
<script setup lang="ts">
defineProps<{ icon: any; title: string; description?: string }>();
</script>
