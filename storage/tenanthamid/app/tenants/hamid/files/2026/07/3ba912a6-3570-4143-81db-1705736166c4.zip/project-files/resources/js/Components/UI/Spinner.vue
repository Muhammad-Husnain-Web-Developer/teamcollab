<template>
  <div :class="['inline-block rounded-full border-2 border-current border-t-transparent animate-spin', sizeClass]" />
</template>
<script setup lang="ts">
import { computed } from 'vue';
const props = defineProps<{ size?: 'sm'|'md'|'lg' }>();
const sizeClass = computed(() => ({ sm:'w-4 h-4', md:'w-6 h-6', lg:'w-8 h-8' }[props.size ?? 'md']));
</script>
