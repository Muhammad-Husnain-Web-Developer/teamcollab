<template>
    <AppLayout>
        <template #header>
            <h1 class="text-sm font-semibold text-gray-900 dark:text-white">Dashboard</h1>
        </template>

        <div class="p-6 space-y-6">
            <!-- Stats Grid -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard
                    title="Open Conversations"
                    :value="stats.conversations.open"
                    :total="stats.conversations.total"
                    :icon="MessageSquare"
                    color="indigo"
                    :trend="'+12%'"
                />
                <StatCard
                    title="Open Tickets"
                    :value="stats.tickets.open"
                    :total="stats.tickets.total"
                    :icon="Ticket"
                    color="amber"
                    :trend="'-5%'"
                />
                <StatCard
                    title="Total Customers"
                    :value="stats.customers.total"
                    :icon="Users"
                    color="emerald"
                    :trend="`+${stats.customers.new_this_month} this month`"
                />
                <StatCard
                    title="Avg Response Time"
                    :value="formatDuration(stats.response_time.average)"
                    :icon="Clock"
                    color="violet"
                    :trend="`${formatDuration(stats.response_time.this_week)} this week`"
                />
            </div>

            <!-- Charts row -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <!-- Conversation trend -->
                <div class="lg:col-span-2 card">
                    <div class="card-header flex items-center justify-between">
                        <h3 class="text-sm font-semibold text-gray-900 dark:text-white">Conversation Trend</h3>
                        <span class="text-xs text-gray-500">Last 7 days</span>
                    </div>
                    <div class="card-body">
                        <ConversationChart :data="conversation_trend" />
                    </div>
                </div>

                <!-- AI vs Human -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-sm font-semibold text-gray-900 dark:text-white">AI vs Human</h3>
                    </div>
                    <div class="card-body">
                        <div class="space-y-4">
                            <div>
                                <div class="flex justify-between text-xs text-gray-600 dark:text-gray-400 mb-1.5">
                                    <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-violet-500" />AI Handled</span>
                                    <span class="font-semibold">{{ stats.conversations.ai_handled }}</span>
                                </div>
                                <div class="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                                    <div class="h-full bg-gradient-to-r from-violet-500 to-indigo-500 rounded-full transition-all duration-700"
                                         :style="{ width: aiPercent + '%' }" />
                                </div>
                            </div>
                            <div>
                                <div class="flex justify-between text-xs text-gray-600 dark:text-gray-400 mb-1.5">
                                    <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-emerald-500" />Human Handled</span>
                                    <span class="font-semibold">{{ stats.conversations.human_handled }}</span>
                                </div>
                                <div class="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                                    <div class="h-full bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full transition-all duration-700"
                                         :style="{ width: humanPercent + '%' }" />
                                </div>
                            </div>
                            <div class="pt-2 border-t border-gray-100 dark:border-gray-800">
                                <div class="flex justify-between text-xs">
                                    <span class="text-gray-500">Customer Satisfaction</span>
                                    <span class="font-semibold text-gray-900 dark:text-white">
                                        {{ stats.satisfaction.average.toFixed(1) }}/5
                                    </span>
                                </div>
                                <div class="flex gap-0.5 mt-2">
                                    <template v-for="i in 5" :key="i">
                                        <div class="flex-1 h-1.5 rounded-full"
                                             :class="i <= Math.round(stats.satisfaction.average) ? 'bg-amber-400' : 'bg-gray-200 dark:bg-gray-700'" />
                                    </template>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bottom row -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <!-- Top agents -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-sm font-semibold text-gray-900 dark:text-white">Top Agents This Week</h3>
                    </div>
                    <div class="divide-y divide-gray-100 dark:divide-gray-800">
                        <div v-for="(agent, i) in top_agents" :key="agent.id"
                             class="flex items-center gap-3 px-6 py-3">
                            <span class="text-xs font-bold text-gray-400 w-4">{{ i + 1 }}</span>
                            <img :src="agent.avatar_url ?? `https://ui-avatars.com/api/?name=${agent.name}&background=6366f1&color=fff`"
                                 class="w-7 h-7 rounded-full object-cover" :alt="agent.name" />
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-medium text-gray-900 dark:text-white truncate">{{ agent.name }}</p>
                                <p class="text-xs text-gray-500">{{ agent.active_conversations }} active</p>
                            </div>
                            <span class="text-sm font-semibold text-brand-600 dark:text-brand-400">
                                {{ agent.resolved_tickets }} resolved
                            </span>
                        </div>
                        <div v-if="!top_agents.length" class="px-6 py-8 text-center text-sm text-gray-400">
                            No agent data yet
                        </div>
                    </div>
                </div>

                <!-- Recent conversations -->
                <div class="card">
                    <div class="card-header flex items-center justify-between">
                        <h3 class="text-sm font-semibold text-gray-900 dark:text-white">Recent Conversations</h3>
                        <Link :href="route('tenant.conversations.index')" class="text-xs text-brand-600 dark:text-brand-400 hover:underline">
                            View all
                        </Link>
                    </div>
                    <div class="divide-y divide-gray-100 dark:divide-gray-800">
                        <div v-for="conv in recent_conversations" :key="conv.id"
                             class="px-6 py-3 hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors cursor-pointer"
                             @click="router.visit(route('tenant.conversations.show', conv.id))">
                            <div class="flex items-center gap-3">
                                <img :src="conv.customer?.avatar_url" class="w-7 h-7 rounded-full" :alt="conv.customer?.name" />
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-2">
                                        <p class="text-sm font-medium text-gray-900 dark:text-white truncate">{{ conv.customer?.name }}</p>
                                        <ConvTypeBadge :type="conv.type" />
                                    </div>
                                    <p class="text-xs text-gray-500 truncate mt-0.5">{{ conv.last_message?.content ?? 'No messages yet' }}</p>
                                </div>
                                <span class="text-xs text-gray-400 flex-shrink-0">{{ formatTime(conv.last_activity_at) }}</span>
                            </div>
                        </div>
                        <div v-if="!recent_conversations.length" class="px-6 py-8 text-center text-sm text-gray-400">
                            No conversations yet
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </AppLayout>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import { MessageSquare, Ticket, Users, Clock } from 'lucide-vue-next';
import AppLayout from '@/Layouts/AppLayout.vue';
import StatCard from '@/Components/Dashboard/StatCard.vue';
import ConversationChart from '@/Components/Dashboard/ConversationChart.vue';
import ConvTypeBadge from '@/Components/Chat/ConvTypeBadge.vue';
import { formatDuration, formatTime } from '@/Utils/format';

const props = defineProps<{
    stats: any;
    conversation_trend: any[];
    top_agents: any[];
    recent_conversations: any[];
}>();

const total = computed(() => props.stats.conversations.ai_handled + props.stats.conversations.human_handled || 1);
const aiPercent = computed(() => Math.round(props.stats.conversations.ai_handled / total.value * 100));
const humanPercent = computed(() => Math.round(props.stats.conversations.human_handled / total.value * 100));
</script>
