<template>
    <AppLayout>
        <template #header>
            <div class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                <span class="font-semibold text-gray-900 dark:text-white">Conversations</span>
            </div>
        </template>

        <div class="flex h-full">
            <!-- Sidebar list -->
            <div class="w-80 flex-shrink-0 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 flex flex-col">
                <!-- Header & filters -->
                <div class="p-4 border-b border-gray-100 dark:border-gray-800 space-y-3">
                    <div class="flex items-center justify-between">
                        <h2 class="text-sm font-semibold text-gray-900 dark:text-white">
                            All Conversations
                            <span class="ml-2 text-xs font-normal text-gray-400">{{ conversations.total }}</span>
                        </h2>
                        <button class="btn-primary btn-sm">
                            <Plus class="w-3.5 h-3.5" />
                            New
                        </button>
                    </div>
                    <!-- Search -->
                    <div class="relative">
                        <Search class="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                        <input v-model="search" @input="debouncedSearch"
                               placeholder="Search conversations..."
                               class="input pl-9 py-1.5 text-xs" />
                    </div>
                    <!-- Quick filters -->
                    <div class="flex gap-1 overflow-x-auto pb-0.5">
                        <FilterChip v-for="f in statusFilters" :key="f.value"
                                    :label="f.label"
                                    :active="currentStatus === f.value"
                                    @click="setFilter('status', f.value)" />
                    </div>
                </div>

                <!-- List -->
                <div class="flex-1 overflow-y-auto">
                    <ConversationListItem
                        v-for="conv in conversations.data"
                        :key="conv.id"
                        :conversation="conv"
                        :active="activeId === conv.id"
                        @click="openConversation(conv)"
                    />
                    <div v-if="!conversations.data.length" class="flex flex-col items-center justify-center py-16 text-gray-400">
                        <MessageSquare class="w-10 h-10 mb-2 opacity-40" />
                        <p class="text-sm">No conversations found</p>
                    </div>
                </div>

                <!-- Pagination -->
                <div v-if="conversations.last_page > 1" class="p-3 border-t border-gray-100 dark:border-gray-800 flex justify-between text-xs text-gray-500">
                    <button @click="goPage(conversations.current_page - 1)" :disabled="conversations.current_page === 1" class="btn-ghost btn-sm">
                        <ChevronLeft class="w-3.5 h-3.5" />
                    </button>
                    <span>{{ conversations.current_page }} / {{ conversations.last_page }}</span>
                    <button @click="goPage(conversations.current_page + 1)" :disabled="conversations.current_page === conversations.last_page" class="btn-ghost btn-sm">
                        <ChevronRight class="w-3.5 h-3.5" />
                    </button>
                </div>
            </div>

            <!-- Empty state when no conversation selected -->
            <div class="flex-1 flex items-center justify-center bg-gray-50 dark:bg-gray-950">
                <div class="text-center">
                    <div class="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
                        <MessageSquare class="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 class="text-sm font-medium text-gray-600 dark:text-gray-400">Select a conversation</h3>
                    <p class="text-xs text-gray-400 mt-1">Choose a conversation from the list to view messages</p>
                </div>
            </div>
        </div>
    </AppLayout>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { router } from '@inertiajs/vue3';
import { MessageSquare, Plus, Search, ChevronLeft, ChevronRight } from 'lucide-vue-next';
import { useDebounceFn } from '@vueuse/core';
import AppLayout from '@/Layouts/AppLayout.vue';
import ConversationListItem from '@/Components/Chat/ConversationListItem.vue';
import FilterChip from '@/Components/UI/FilterChip.vue';

defineProps<{
    conversations: any;
    stats: any;
    agents: any[];
    filters: any;
}>();

const search = ref('');
const activeId = ref<number | null>(null);
const currentStatus = ref('');

const statusFilters = [
    { label: 'All', value: '' },
    { label: 'Open', value: 'open' },
    { label: 'Waiting', value: 'waiting' },
    { label: 'Resolved', value: 'resolved' },
];

const debouncedSearch = useDebounceFn(() => {
    router.get(route('tenant.conversations.index'), { search: search.value }, { preserveState: true });
}, 400);

function setFilter(key: string, value: string) {
    currentStatus.value = value;
    router.get(route('tenant.conversations.index'), { [key]: value || undefined }, { preserveState: true });
}

function openConversation(conv: any) {
    activeId.value = conv.id;
    router.visit(route('tenant.conversations.show', conv.id));
}

function goPage(page: number) {
    router.get(route('tenant.conversations.index'), { page }, { preserveState: true });
}
</script>
