<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

class Customer extends Model
{
    use HasFactory, SoftDeletes, LogsActivity;

    protected $fillable = [
        'name',
        'email',
        'phone',
        'avatar',
        'company',
        'location',
        'timezone',
        'language',
        'status',
        'source',
        'custom_attributes',
        'tags',
        'notes',
        'external_id',
        'last_seen_at',
    ];

    protected $casts = [
        'custom_attributes' => 'array',
        'tags' => 'array',
        'last_seen_at' => 'datetime',
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'email', 'status'])
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs();
    }

    public function conversations(): HasMany
    {
        return $this->hasMany(Conversation::class);
    }

    public function tickets(): HasMany
    {
        return $this->hasMany(Ticket::class);
    }

    public function notes(): HasMany
    {
        return $this->hasMany(CustomerNote::class);
    }

    public function satisfactionRatings(): HasMany
    {
        return $this->hasMany(SatisfactionRating::class);
    }

    public function getAvatarUrlAttribute(): string
    {
        if ($this->avatar) {
            return asset('storage/' . $this->avatar);
        }
        $name = urlencode($this->name);
        return "https://ui-avatars.com/api/?name={$name}&background=10b981&color=fff&size=128";
    }

    public function getActiveConversationAttribute(): ?Conversation
    {
        return $this->conversations()->where('status', 'open')->latest()->first();
    }

    public function getTotalConversationsAttribute(): int
    {
        return $this->conversations()->count();
    }

    public function getTotalTicketsAttribute(): int
    {
        return $this->tickets()->count();
    }
}
